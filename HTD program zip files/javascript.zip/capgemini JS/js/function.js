//global variables
var a=100;
var b=200;
console.log(a+b);
console.log(a*b);


//Anonymous function
 var x=function(){
 console.log('Hello from anonymous fuction');
 }
  x(); //call the function using va name

//Naming function
function add(a,b){
    console.log(a+b);
}
add(10,20);//call the fun using function name

//immediately inviked function Expression
(function(x,y){
console.log('IIFE is being executed');
console.log('the value is',x*y);
})(12,21);

//understanding return keyword
function division(a,b){
    return a/b;
}
console.log(division(1221,7));
