var laptop=new Object();
laptop.brand='Lenovo';
laptop.ram='4GB';
laptop.processor='core i5';
laptop.price=35000;

console.log(laptop);

console.log(Object.keys(laptop));
console.log(Object.length)