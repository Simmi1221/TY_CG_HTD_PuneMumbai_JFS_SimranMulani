function test(cb){
    console.log('test function started');
    cb();
    console.log('test function ended');
    setTimeout(function(){
        console.log("10 seconds done");
    },10000);
}

var i=1;
setInterval(function(){
    console.log(i);
    i++;
},2000);

test(function(){
console.log('callback function is being executed');
});

setTimeout(function(){
    console.log("3 seconds done");
},3000);