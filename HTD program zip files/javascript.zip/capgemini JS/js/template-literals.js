var myString=`Javascript is 
scripting language whereas java is programming language.I is light weight language.`
console.log(myString);

var name='Simran';
var role='CR';
var batch='Pune';
console.log(`I am ${name} and I am ${role} of ${batch} batch`);

console.log(`the sum of 1234 and 4321 is ${1234+4321}`);