localStorage.setItem('name','Simmu');
console.log(localStorage.getItem('name'));

console.log(localStorage.length);

console.log(localStorage.clear());

localStorage.setItem('name','Simmu');
console.log(localStorage.getItem('name'));

sessionStorage.setItem('name','simarn');
console.log(sessionStorage.getItem('name'));