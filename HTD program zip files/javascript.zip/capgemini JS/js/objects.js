
var student={
    name:'Vajid Mulani',
    age:12,
    std:'8th',
    school:'KBPVP',
    phoneNum:'8805503486'
};

console.log(student.name);
console.log(student);

student.phoneNum='9359467657';
console.log(student.phoneNum);
student.selectedCourse='RTS';
console.log(student);
