let myString='Capgemini trainees are raelly intelligent';

console.log(myString.indexOf('are'));//19

console.log(myString.includes('train'));//true
console.log(myString.includes('trainer'));//false

let reversedString=myString.split();
console.log(reversedString);
let splittedString=myString.split('').reverse();
console.log(splittedString);
let combinedString=myString.split('').reverse().join('');
console.log(combinedString);


console.log(myString.charAt(2));//p

console.log(myString.charCodeAt(2));//112