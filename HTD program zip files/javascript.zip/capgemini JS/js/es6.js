let person={
    name:'Anushka',
    age:30
};

let dept={
    dname:'E&TC',
    bno:102
};
let student={
    ...person,...dept,
    UID:1234,
    per:55.55
};
console.log(student);

//for arrays
let puneMumbai=['Akash','Aishwarya'];
let noida=['Karthik','Manali'];
let banglore=['Shahid','Yasmin'];
let bhuvaneshwar=['Kaushik','Nisha'];

let CRs=[
    ...puneMumbai,
    ...noida,
    ...banglore,
    ...bhuvaneshwar,
    'subrat'
];
console.log(CRs);
//re-structuring
let[cr1,cr2,cr3,cr4]=CRs;
console.log(cr1);
console.log(cr2);
console.log(cr3);
console.log(cr4);
