//alert('Are you sure want to proceed');

//var inputFromUser=confirm('Are yo really good??');
//console.log(inputFromUser);--->true

//var username=prompt('Please enter your name');
//console.log(username);

console.log(12345);
document.write('Good morning guys')