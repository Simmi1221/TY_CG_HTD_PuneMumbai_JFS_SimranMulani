//prompt('please write your name');
var myName;
console.log(typeof myName);

var myName=null;
console.log(typeof myName);

var a=123455;
console.log(typeof a);
a='simran';
console.log(typeof a);

var areYouGood=true;
console.log(typeof areYouGood)

