// var x=[123,'abc',true,{name:'Salman khan'}];
// console.log(x[0]);

// for(var i=0;i<=x.length;i++){
//     console.log(x[i]);
// }

var colors=['yellow','red','green','white'];
console.log(colors);
colors.pop();
console.log(colors);
colors.push('violet','indigo');
console.log(colors);
colors.shift();
console.log(colors);
colors.unshift('Purple','Black');
console.log(colors);
colors.splice(2,2,);
console.log(colors);
colors.splice(2,0,'green','white');
console.log(colors);

//using forEach() method
colors.forEach(function(value,index,array){
console.log(value,index,array);
})

var num=[1,2,3,4,5];
console.log(num);
num.forEach(function(value,index,array){
console.log(value*3,index,array);
})

//using filter() method
var myArray=[97,56,100,230,140,490];
console.log(myArray);
var newArray=myArray.filter(function(value){
return value>100;
});
console.log(newArray);

//using indexOf() method
var x=[1,2,3,4,2,2,3,4,5,2,3,4];
console.log(x);
console.log(x.indexOf(4));

//filter method for unique value
var filteredarray=x.filter(function(value,index,array){
    return array.indexOf(value)===index;
});
console.log(filteredarray);

//diff between == and ===
if(123=='123'){
    console.log('true')
}else{
    console.log('false')
}
if(123==='123'){
    console.log('true')
}else{
    console.log('false')
}

//for of loop
for(var x of myArray){
    console.log(x);
}

//for in loop ( for arrays)
for(var index in myArray){
    console.log('the value of index ',index,'is',myArray[index]);
}
//for in loop (for sobjects)
var movie={
name:'Paisa vassol',
actor:'Balaiah',
actress:'shreya',
director:'Puri Jagannath'
};

for(var key in movie){
    console.log(key,'is',movie[key]);
}