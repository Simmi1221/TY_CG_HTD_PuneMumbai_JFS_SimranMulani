//fat arrow function 
let add=(a,b)=>{
    console.log('the sum is',a+b);
}
add(10,20);

//fat arrow with only one argument
let printAge=age=>{
    console.log('the age is',age);
}
printAge(21);

//fat arrow function with only return statement
let product=(a,b)=>a*b;
 console.log('the product is', product(12,21));
