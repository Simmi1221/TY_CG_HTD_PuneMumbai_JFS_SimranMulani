"use strict";
exports.__esModule = true;
var Circle = /** @class */ (function () {
    function Circle() {
    }
    Circle.prototype.circumference = function (r) {
        return 2 * 3.142 * r;
    };
    Circle.prototype.areaOfCircle = function (r) {
        return 3.142 * r * r;
    };
    return Circle;
}());
exports.Circle = Circle;
