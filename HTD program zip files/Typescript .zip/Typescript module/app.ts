
import  {Circle} from './circle';
import {Rectangle} from './rectangle';

let circle=new Circle();
let rectangle=new Rectangle();

console.log(circle.areaOfCircle(10));
console.log(rectangle.areaOfRectangle(10,20));





