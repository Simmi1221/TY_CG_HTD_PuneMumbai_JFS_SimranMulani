export class Circle {
    circumference(r:number):number{
        return 2*3.142*r;
    }
    areaOfCircle(r:number):number{
        return 3.142*r*r;
    }
}