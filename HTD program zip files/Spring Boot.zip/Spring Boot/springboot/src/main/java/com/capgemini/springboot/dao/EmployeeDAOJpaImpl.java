package com.capgemini.springboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springboot.beans.EmployeeInfo;

@Repository
public class EmployeeDAOJpaImpl implements EmployeeDAO {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public EmployeeInfo getEmployee(int empId) {

		EntityManager em = emf.createEntityManager();
		EmployeeInfo empInfo = em.find(EmployeeInfo.class, empId);
		em.close();

		return empInfo;
	}// end of getEmployee()

	@Override
	public EmployeeInfo authenticate(int empId, String pwd) {

		EntityManager em = emf.createEntityManager();
		String jpql = "from EmployeeInfo where empId=:empId and password=:pwd";
		Query query = em.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("pwd", pwd);

		EmployeeInfo empInfo = null;
		try {
			empInfo = (EmployeeInfo) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return empInfo;
	}// end of authenticate()

	@Override
	public boolean addEmployee(EmployeeInfo empInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isAdded=false;
		try {
			tran.begin();
			em.persist(empInfo);
			tran.commit();
			isAdded=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
         em.close();
		return isAdded;
	}// end of addEmployee

	@Override
	public boolean updateEmployee(EmployeeInfo empInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isUpdated=false;
			EmployeeInfo empInfo1=em.find(EmployeeInfo.class, empInfo.getEmpId());
			if(empInfo1!=null) {
				if(empInfo.getEmpName()!=null) {
					empInfo1.setEmpName(empInfo.getEmpName());
				}if(empInfo.getAge()!=0) {
					empInfo1.setAge(empInfo.getAge());
				}if(empInfo.getDesignation()!=null) {
					empInfo1.setDesignation(empInfo.getDesignation());
				}if(empInfo.getGender()!=null) {
					empInfo1.setGender(empInfo.getGender());
				}if(empInfo.getMobile()!=0) {
					empInfo1.setMobile(empInfo.getMobile());
				}if(empInfo.getSalary()!=0) {
					empInfo1.setSalary(empInfo.getSalary());
				}
			}
			try {
			tran.begin();
			em.persist(empInfo1);
			tran.commit();
			isUpdated=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
         em.close();
		
		return isUpdated;
	}
	
	@Override
	public boolean deleteEmployee(int empId) {
		
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			EmployeeInfo employeeInfoBean= entityManager.find(EmployeeInfo.class, empId);
			entityManager.remove(employeeInfoBean);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}// End of deleteEmployee()

	@Override
	public List<EmployeeInfo> getAllEmployees() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfo";
		Query query = manager.createQuery(jpql);
		
		List<EmployeeInfo> employeesList = null;
		try {
			employeesList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return employeesList;
		
	}// End of getAllEmployees()

}// end of class
