package com.capgemini.springboot.dao;

import java.util.List;

import com.capgemini.springboot.beans.EmployeeInfo;

public interface EmployeeDAO {

	public EmployeeInfo getEmployee(int empId);
	public EmployeeInfo authenticate(int empId, String pwd);
	public boolean  addEmployee(EmployeeInfo empInfo);
	public boolean updateEmployee(EmployeeInfo empInfo);
	public boolean deleteEmployee(int empId);
	public List<EmployeeInfo> getAllEmployees();
	

}// end of class
