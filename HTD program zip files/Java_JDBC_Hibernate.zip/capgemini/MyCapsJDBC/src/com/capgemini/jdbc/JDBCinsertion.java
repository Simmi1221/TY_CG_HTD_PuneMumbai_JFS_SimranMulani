package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCinsertion {

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt=null;
		

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded.............");
			System.out.println("********************************");

			// Get the connection
			String dbURL = "jdbc:mysql://localhost:3306/capg_db?user=J2EE&password=tiger";
			DriverManager.getConnection(dbURL);
			conn = DriverManager.getConnection(dbURL);
			System.out.println("connection established..........");
			System.out.println("***************");

			// Issue SQL queries via connection
			String query = "insert into users_info values(2019010,'Peter Parker', 'p.parker@avengers.com','peter')";
			stmt = conn.createStatement();
			int count=stmt.executeUpdate(query);
			
			//process the result
			if(count>0) {
				System.out.println("Data inserted");
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
