package com.capgemini.jdbc;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class EvolvedJDBCRetrival {

	public static void main(String[] args) {

		FileReader reader = null;
		Properties prop = null;

		try {
			reader = new FileReader("db.propeties");
			prop = new Properties();
			prop.load(reader);
			Class.forName(prop.getProperty("driverClass"));
			System.out.println("Driver loaded");
			System.out.println("***************************");

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), (prop.getProperty("user")),
				(prop.getProperty("password")));
				Statement stmt = conn.createStatement();
				ResultSet res = stmt.executeQuery(prop.getProperty("query"))) {

			while (res.next()) {
				System.out.println("userid is" + res.getInt(1));
				System.out.println("username is " + res.getString(2));
				System.out.println("email is " + res.getString(3));
				System.out.println("********************************``````` ");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
