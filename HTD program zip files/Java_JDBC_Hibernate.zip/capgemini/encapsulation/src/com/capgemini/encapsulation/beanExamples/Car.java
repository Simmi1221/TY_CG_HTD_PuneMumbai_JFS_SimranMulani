package com.capgemini.encapsulation.beanExamples;

public class Car {
	//immutable class in which we should not have to add setter methods, if we add then it will become mutable class
	private int cost;
	private String name;
	public Car(int cost, String name) {
		this.cost = cost;
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public String getName() {
		return name;
	}
	
	
	
	

}
