package com.capgemini.encapsulation.beanExamples;

public class TestA {

	public static void main(String[] args) {

		Student s=new Student();
		s.setId(01);
		s.setName("dimple");
		s.setHeight(5.8);
		
	
		
		DataBase db=new DataBase();
		db.receive(s);
		
		
		
		
		
	}

}
