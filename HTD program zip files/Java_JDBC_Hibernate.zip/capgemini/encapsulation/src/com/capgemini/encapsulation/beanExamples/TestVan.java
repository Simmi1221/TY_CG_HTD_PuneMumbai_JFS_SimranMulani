package com.capgemini.encapsulation.beanExamples;

public class TestVan {

	public static void main(String[] args) {

		Van r=Van.getVan();
		System.out.println(r);
		
		Van s=Van.getVan();
		System.out.println(s);
		
		Van t=Van.getVan();
		System.out.println(t);
	}

}
