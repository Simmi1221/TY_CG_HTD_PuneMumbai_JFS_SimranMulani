
package com.capgemini.hba.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hba.bean.UserBean;

public class UserDAOJDBCImpl implements UserDAO {

	Connection conn = null;
	UserBean user = null;
	String dbUrl = "jdbc:mysql://localhost:3306/Hotel_DB?user=root&password=tiger";
	Integer res=null;
	Scanner sc=new Scanner(System.in);

	public UserDAOJDBCImpl() {
		try {
			// Load the driver

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded........");
			System.out.println("*************************");

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public List<UserBean> getAllInfo() {

		try (Connection conn = DriverManager.getConnection(dbUrl); Statement stmt = conn.createStatement()) {
			String query = "select * from Hotel_Bill";
			try (ResultSet res = stmt.executeQuery(query)) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getDouble(3));
					System.out.println("---------------------");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public UserBean getOrderFromUser(int itemCode) {
		String query = "select * from Hotel_Bill where item_Code=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, itemCode);
			try (ResultSet res = pstmt.executeQuery()) {
				
				if (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getDouble(3));
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public UserBean addFoodItem(int itemCode, String foodName, double price) {
		String query="insert into Hotel_Bill values(?,?,?)";
		try(Connection conn=DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt=conn.prepareStatement(query)){
			pstmt.setInt(1,itemCode);
			pstmt.setString(2, foodName);
			pstmt.setDouble(3,price);
			Integer res=pstmt.executeUpdate();
			if(res>0) {
				System.out.println("Food item inserted");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public UserBean removeFoodItem(int itemCode) {
		String query="delete from Hotel_Bill where Item_Code=?";
		try(Connection conn=DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt=conn.prepareStatement(query)){
			pstmt.setInt(1,itemCode);
			Integer res=pstmt.executeUpdate();
			if(res>0) {
				System.out.println("Food item removed");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	@Override
	public UserBean operateFood(int item,double price) {
		String query="update Hotel_Bill set Price=? where Item_Code=?";
		try(Connection conn=DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt=conn.prepareStatement(query)){
			pstmt.setDouble(1,price);
			pstmt.setInt(2,item);
			
			Integer res=pstmt.executeUpdate();
			if(res>0) {
				System.out.println("Food item updated");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public UserBean totalBill(int count) {
		double total=0;
		for(int i=1;i<=count;i++) {
		try {
			Connection conn=DriverManager.getConnection(dbUrl);
			String query="Select price from Hotel_bill where Item_Code=?";
			PreparedStatement pstmt=conn.prepareStatement(query);
			System.out.println("enter the item code");
			pstmt.setInt(1,Integer.parseInt(sc.nextLine()));
			ResultSet res=pstmt.executeQuery();
			
			if(res.next()) {
				total=res.getDouble(1)+total;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
		System.out.println("total bill is "+total);
		return null;
	}

	

}
