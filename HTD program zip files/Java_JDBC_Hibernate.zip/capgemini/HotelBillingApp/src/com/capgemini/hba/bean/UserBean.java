package com.capgemini.hba.bean;

import lombok.Data;

@Data
public class UserBean {
	private int itemCode;
	private String foodName;
	private double price;
	@Override
	public String toString() {
		return "UserBean [itemCode=" + itemCode + ", foodName=" + foodName + ", price=" + price + "]";
	}
}
