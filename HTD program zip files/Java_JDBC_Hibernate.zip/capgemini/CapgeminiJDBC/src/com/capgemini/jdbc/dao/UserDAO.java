package com.capgemini.jdbc.dao;

import java.util.List;

import com.capgemin.jdbc.beans.UserBean;

public interface UserDAO {
	
	public List<UserBean> getAllInfo();
	public UserBean getInfo(int userid);
	public UserBean userLogin(int userid,String password);

}
