package com.capgemini.jdbc.dao;

import java.util.List;

import com.capgemin.jdbc.beans.UserBean;
import com.capgemini.jdbc.factory.UserFactory;

public class getAllInfo {
	
	public static void main(String[] args) {
		
		UserDAO dao=UserFactory.getInstance();
		List<UserBean> userlist=dao.getAllInfo();
		if(userlist!=null) {
			for(UserBean user:userlist) {
			System.out.println(user);
		}
		}else {
			System.out.println("something went wrong...........");
		}
	
	}

}
