package com.capgemini.stringexp.one;

public class TestC {

	public static void main(String[] args) {
		int i=10;
		Integer a=new Integer(i);//boxing
		System.out.println(a);
		
		int j=20;
		Integer k=j;//auto-boxing
		System.out.println(k);

		Double d=new Double(2.44);
		double e= d.doubleValue();//Un boxing
		System.out.println(e);
		
		//Byte b=new Byte((byte) 0);
		//byte m=b;
	}

}
