package com.capgemini.modifiers.unclefamily;

import com.capgemini.modifiers.family.Father;

public class uncle {
	void use() {
		Father f=new Father();
		f.cycle();
	}

}
