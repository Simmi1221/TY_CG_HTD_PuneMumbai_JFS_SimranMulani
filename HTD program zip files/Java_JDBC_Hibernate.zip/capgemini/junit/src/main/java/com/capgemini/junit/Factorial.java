package com.capgemini.junit;

public class Factorial {

	public int fact(int a) {
		int fact = 0;
		if (a == 0) {
			return 1;
		} else {
			for (int i = 1; i <= a; i++) {
				fact = fact * i;
			}
			return fact;
		}
	}
	
	
}
