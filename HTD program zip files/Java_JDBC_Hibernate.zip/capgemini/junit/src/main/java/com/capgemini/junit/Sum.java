package com.capgemini.junit;

public class Sum {

	public int add(int a, int b) {
		return a + b;
	}

    public int add1(int a,int b,int c) {
    	return a+b+c;
    }
}
