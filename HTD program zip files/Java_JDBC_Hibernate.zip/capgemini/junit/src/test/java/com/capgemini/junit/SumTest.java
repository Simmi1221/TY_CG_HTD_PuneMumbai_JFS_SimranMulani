package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {

	@Test
	public void addTest() {
		Sum s=new Sum();
		int i=s.add(12, 21);
		assertEquals(33, i);
	}
	
	@Test
	public void add1Test() {
		Sum s=new Sum();
		int i=s.add1(12, 21,98);
		assertEquals(131, i);
	}

}
