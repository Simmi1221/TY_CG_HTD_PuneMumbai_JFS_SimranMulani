package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	Calculator calculator =null;
	
	@BeforeEach
	public void createObject() {
		 calculator =new Calculator();
	}

	@Test
	public void addTest() {
		int i = calculator.add(-12, 21);
		assertEquals(9, i);
	}

	@Test
	public void subTest() {
		int i = calculator.sub(-20, -10);
		assertEquals(-10, i);
	}

	@Test
	public void mulTest() {
		int i = calculator.mul(-5, 5);
		assertEquals(-25, i);
	}

	@Test
	public void divTest() {
		int i = calculator.div(30, 15);
		assertEquals(2, i);
	}

	@Test
	public void divTestForZero() {
		int i = calculator.div(30, 15);
		assertThrows(ArithmeticException.class, () -> calculator.div(10, 0));
	}

	@Test
	public void TestFactForNumber() {
		int i = calculator.fact(5);
		assertEquals(120, i);
	}

	@Test
	public void TestFactForZero() {
		int i = calculator.fact(0);
		assertEquals(1, i);
	}

	@Test
	public void TestFactForNegative() {
		int i = calculator.fact(-5);
		assertEquals(1, i);
	}

}
