package com.capgemini.junit;

import java.util.HashSet;
import java.util.Set;

public class Main {
	
	public static void main(String[] args) {
		 Set nums=new HashSet();
		 nums.add(5);
		 nums.add(4);
		 nums.add(3);
		 nums.add(null);
		 nums.add("s");
		 System.out.println(nums);
		 
		 Set nums1=new HashSet<String>();
		 nums1.add("s");
		 nums1.add(5);
		 System.out.println(nums1);
	}

}
