package com.capgemini.maps;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Set;

public class TestD {
	public static void main(String[] args) {

		LinkedHashMap<String, Integer> hm = new LinkedHashMap<String, Integer>();

		hm.put("Ondhu", 1);
		hm.put("Idhu", 5);
		hm.put("Hattu", 10);
		hm.put("Eredu", 2);

		System.out.println("**********Keys**************");

		Set<String> s = hm.keySet();
		for (String k : s) {
			System.out.println(k);

		}

		System.out.println("**********Values**************");

		Collection<Integer> i = hm.values();
		for (Integer j : i) {
			System.out.println(j);
		}

	}

}
