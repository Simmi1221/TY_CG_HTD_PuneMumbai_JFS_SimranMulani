package com.capgemini.sorting.setExample;

import java.util.HashSet;
import java.util.Iterator;

public class TestB {

	public static void main(String[] args) {

		HashSet<String> hs=new HashSet<String>();
		hs.add("Simran");
		hs.add("Nabila");
		hs.add("Dhanu");
		hs.add("Deepa");
		
		System.out.println("*****using for-each loop******");
		for(String r:hs) {
			System.out.println(r);
		}
		
		System.out.println("*****using iterator******");
		Iterator<String> it=hs.iterator();
		while(it.hasNext()) {
			String r=it.next();
			System.out.println(r);
		}
		
		
	}

}
