package com.capgemini.sorting.setExample;

import java.util.TreeSet;

public class TestE {
	public static void main(String[] args) {

		TreeSet ts = new TreeSet();
		ts.add(15);
		ts.add(20);
		ts.add(23);
		ts.add(43);

		System.out.println("*****using for-each loop******");
		for (Object r : ts) {
			System.out.println(r);
		}

	}
}
