package com.capgemini.sorting.setExample;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class TestD {
	public static void main(String[] args) {
		
		LinkedHashSet<Double> hs=new LinkedHashSet<Double>();
		hs.add(15.546);
		hs.add(34.65);
		hs.add(2.45);
		hs.add(65.8);
		
		System.out.println("*****using for-each loop******");
		for(Double r:hs) {
			System.out.println(r);
		}
		
		System.out.println("*****using iterator******");
		Iterator<Double> it=hs.iterator();
		while(it.hasNext()) {
			Double r=it.next();
			System.out.println(r);
		}

	}
	}
