package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class RetriveDemo {
	public static void main(String[] args) {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("Simran");
	EntityManager em=emf.createEntityManager();
	
	String jpql="from Movie";
	Query query=em.createQuery(jpql);
	List<Movie> list=query.getResultList();
	
	for(Movie li:list) {
		System.out.println(li.getId());
		System.out.println(li.getName());
		System.out.println(li.getRating());
		System.out.println("*********************");
	}
	
	
	}
}
