
public class TestE {

	public static void main(String[] args) {
		Facebook f=new Facebook();
		f.login(935946764, 1221);

	}

}
