
public class Marker {
	void write() {
		System.out.println("Marker is used to write");
	}
	void color() {
		System.out.println("Marker has a color");
	}
}
