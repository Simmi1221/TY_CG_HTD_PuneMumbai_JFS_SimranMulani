
public class Person {
int i=100;
Marker m=new Marker();
void walk() {
	System.out.println("Person can walk");
	
}
}
