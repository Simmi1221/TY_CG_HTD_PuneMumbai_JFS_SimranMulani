
public class TestA {

	public static void main(String[] args) {
		Person p=new Person();
		System.out.println(p.i);
		p.walk();
		p.m.color();
		p.m.write();

	}

}
