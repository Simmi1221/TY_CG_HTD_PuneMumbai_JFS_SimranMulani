package com.capgemini.maps1;

import java.util.ArrayList;

public class StudentTest {

	public static void main(String[] args) {

		Student s1=new Student(1,"Priya",56.38,'F');
		Student s2=new Student(2,"Riya",46.46,'F');
		Student s3=new Student(3,"Tiya",33.35,'F');
		Student s4=new Student(4,"Jiya",25.98,'F');
		Student s5=new Student(5,"Shyam",86.98,'M');
		Student s6=new Student(6,"Raju",76.11,'M');
		Student s7=new Student(7,"Monty",56.45,'M');
		Student s8=new Student(8,"Chotu",23.45,'M');
		
		ArrayList<Student> al=new ArrayList<Student>();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		al.add(s6);
		al.add(s7);
		al.add(s8);
		
		Helper h=new Helper();
		//h.displayAll(al);
		//h.displayPassed(al);
		//h.displayFailed(al);
		//h.displayPassedWithGender(al, 'M');
		//h.displayPassedWithGender(al, 'F');
		
		//h.displayFailedWithGender(al, 'M');
		//h.displayFailedWithGender(al, 'F');
		
		//h.topper(al);
		
	}

}
