package com.capgemini.exceptionhandling.createxception;

public class Test1 {
	public static void main(String[] args) {
		
		Validator v=new Validator();
		
		try {
			v.verify(2);
			System.out.println("Welcome to pub");
		}catch(InvalidAgeException  in) {
			System.err.println(in.getMessage());
		}
	}

}
