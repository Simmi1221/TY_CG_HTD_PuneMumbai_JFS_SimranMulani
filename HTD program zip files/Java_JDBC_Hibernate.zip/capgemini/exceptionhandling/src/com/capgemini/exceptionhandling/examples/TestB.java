package com.capgemini.exceptionhandling.examples;

public class TestB {
	public static void main(String[] args) {
		
		System.out.println("main started");
		
		try {
			System.out.println("Good morning");
			System.out.println("Have a nice day");
			System.out.println(10/2);
			System.out.println("Hi");
			System.out.println("Keep smiling");
		}catch(ArithmeticException e) {
			System.out.println("dont devide by zero");
		}
		System.out.println("main ended");
	}

}
