package com.capgemini.exceptionhandling.createxception;

public class InvalidAgeException extends RuntimeException {

	private String message="Invalid age to proceed";
	
	
	
	
	@Override
	public String getMessage() {
		
		return message;
	}
	
	/*@Override
	public String toString() {    either getMessage or toString method is used to override
		
		return message;
	}
	*/
}
