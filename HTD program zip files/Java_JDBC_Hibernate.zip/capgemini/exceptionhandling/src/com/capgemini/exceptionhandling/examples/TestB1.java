package com.capgemini.exceptionhandling.examples;

public class TestB1 {
public static void main(String[] args) {
		
		System.out.println("main started");
		
		try {
			System.out.println("Good morning");
			System.out.println("Have a nice day");
			System.out.println(10/0);// here exception occurs so it will not execute line belows it in try block
			System.out.println("Hi");
			System.out.println("Keep smiling");
		}catch(ArithmeticException e) {
			System.out.println("dont devide by zero");
		}
		System.out.println("main ended");
	}

}
