package com.capgemini.exceptionhandling.realexamples;

public class Test1 {
public static void main(String[] args) {
	System.out.println("main started");
	int[] a= {1,2,3};
	try {
		System.out.println(10/2);
		System.out.println(a[3]);
		
	}catch(ArithmeticException e) {
		e.printStackTrace();
	}catch(NullPointerException d) {
		d.printStackTrace();
	}

	
	
	System.out.println("main started");
}
}
