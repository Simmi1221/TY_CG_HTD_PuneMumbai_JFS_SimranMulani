package com.capgemini.exceptionhandling.createxception;

public class Test2 {
public static void main(String[] args) {
	
	Amount am=new Amount();
	
	try {
		am.check(45000);
		System.out.println("Amount is valid");
		
	}catch(InvalidLimitException e) {
		System.err.println(e.getMessage());
	}
}
}
