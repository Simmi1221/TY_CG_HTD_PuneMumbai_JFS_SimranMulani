package com.capgemini.exceptionhandling.realexamples;

public class BMS1 {
	public static void main(String[] args) {
		System.out.println("main started");
		PVR1 p = new PVR1();
		try {
			p.confirm1();
		} catch (ArithmeticException b) {
			System.out.println("Execution caught by main method");
		}
		System.out.println("main ended");
	}
}
