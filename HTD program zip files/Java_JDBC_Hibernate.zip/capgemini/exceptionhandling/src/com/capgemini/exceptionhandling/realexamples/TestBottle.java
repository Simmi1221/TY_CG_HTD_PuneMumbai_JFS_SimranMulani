package com.capgemini.exceptionhandling.realexamples;

public class TestBottle {
public static void main(String[] args) {
	
	Bottle b=new Bottle();
	
	try {
		b.open();
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
