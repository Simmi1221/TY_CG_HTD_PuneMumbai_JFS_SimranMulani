package com.capgemini.exceptionhandling.realexamples;

import java.io.File;
import java.io.IOException;

public class CompilerForceToHandleExc {
	public static void main(String[] args) {
		
		System.out.println("main started");
		
		File f=new File("capgemini.text");
		//File f=new File("R://capgemini.text");R drive is not available so exception occur in this case
		
		try {
			f.createNewFile();
			System.out.println("file created");
		} catch (IOException e) {
			System.out.println("Sorry not able to create file");
		}
		
		System.out.println("main ended");
		
		
		
	}

}
