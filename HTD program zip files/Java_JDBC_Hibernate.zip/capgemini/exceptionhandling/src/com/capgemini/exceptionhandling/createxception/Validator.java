package com.capgemini.exceptionhandling.createxception;

public class Validator {
	
	void verify(int age) {
		if(age<20) {
			throw new InvalidAgeException();
		}
	}

}
