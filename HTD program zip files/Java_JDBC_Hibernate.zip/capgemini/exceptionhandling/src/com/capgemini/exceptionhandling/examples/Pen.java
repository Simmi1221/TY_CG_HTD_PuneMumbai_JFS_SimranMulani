package com.capgemini.exceptionhandling.examples;

public class Pen {
	public static void main(String[] args) {

		System.out.println("main started");

		System.out.println(10 / 5);

		try {
			System.out.println(10 / 0);
		} catch (ArithmeticException e) {
			System.out.println("Please do not devide by zero");
		}

		System.out.println("main ended");
	}

}
