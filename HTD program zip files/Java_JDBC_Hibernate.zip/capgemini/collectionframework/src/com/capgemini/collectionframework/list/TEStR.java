package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Stack;

public class TEStR {

	public static void main(String[] args) {

		Stack s = new Stack();
		
		s.add(9.6);
		s.add('M');
		s.add("Priya");
		s.add(2);
		
		System.out.println("****************for loop***************");

		for (int i = 0; i < 4; i++) {
			Object r = s.get(i);
			System.out.println(r);
		}

		System.out.println("****************for-each loop***************");

		for (Object r : s) {
			System.out.println(r);
		}

		System.out.println("****************Iterator***************");

		Iterator it = s.iterator();

		while (it.hasNext()) {
			Object r = it.next();
			System.out.println(r);
		}

		System.out.println("****************ListIterator***************");

		ListIterator lit = s.listIterator();

		System.out.println("------------Forward");
		while (lit.hasNext()) {
			Object m = lit.next();
			System.out.println(m);
		}

		System.out.println("------------Backward");
		while (lit.hasPrevious()) {
			Object r = lit.previous();
			System.out.println(r);
		}



	}

}
