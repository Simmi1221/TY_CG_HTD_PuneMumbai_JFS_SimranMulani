package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestK {

	public static void main(String[] args) {

		ArrayList<Double> ald = new ArrayList<Double>();
		ald.add(2.1232);
		ald.add(23.45);
		ald.add(234.43);
		ald.add(5.44);

		for (Double r : ald) {
			System.out.println(r);
		}

	}

}
