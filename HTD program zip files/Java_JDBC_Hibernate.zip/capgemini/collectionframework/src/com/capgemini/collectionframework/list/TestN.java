package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class TestN {

	public static void main(String[] args) {

		LinkedList li = new LinkedList();

		li.add(10);
		li.add(1.234);
		li.add('h');
		li.add("jonny");

		System.out.println("****************for loop***************");

		for (int i = 0; i < 4; i++) {
			Object r = li.get(i);
			System.out.println(r);
		}

		System.out.println("****************for-each loop***************");

		for (Object r : li) {
			System.out.println(r);
		}

		System.out.println("****************Iterator***************");

		Iterator it = li.iterator();

		while (it.hasNext()) {
			Object r = it.next();
			System.out.println(r);
		}

		System.out.println("****************ListIterator***************");

		ListIterator lit = li.listIterator();

		System.out.println("------------Forward");
		while (lit.hasNext()) {
			Object s = lit.next();
			System.out.println(s);
		}

		System.out.println("------------Backward");
		while (lit.hasPrevious()) {
			Object r = lit.previous();
			System.out.println(r);
		}

	}

}
