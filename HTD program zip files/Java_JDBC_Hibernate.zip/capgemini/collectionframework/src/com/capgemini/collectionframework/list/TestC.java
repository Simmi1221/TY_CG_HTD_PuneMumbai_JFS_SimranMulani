package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;

public class TestC {

	public static void main(String[] args) {
		
		ArrayList al=new ArrayList();
		
		al.add(24);
		al.add("chinnu");
		al.add(2.9);
		al.add('F');
		
		Iterator it=al.iterator();
		Object r=it.next();
		Object s=it.next();	
		Object t=it.next();
		Object i=it.next();
		
		Object p=it.next();
		System.out.println(p);//NoSuchElementException occurs
		
		System.out.println(r);
		System.out.println(s);
		System.out.println(t);
		System.out.println(i);
		
	}

}
