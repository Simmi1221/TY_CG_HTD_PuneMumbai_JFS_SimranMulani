package com.capgemini.objectclass.methods;

public class TestA {

	public static void main(String[] args) {
		Object a = new Pen();
		int x = a.hashCode();
		System.out.println("address is " + x);

		Pen b = new Pen();
		System.out.println(b.hashCode());

	}

}
