package com.capgemini.objectclass.methods;

public class TestF {

	public static void main(String[] args) throws CloneNotSupportedException{
		Remote m=new Remote(1,"Philips");
		System.out.println("id is "+m.id);
		System.out.println("name is "+m.name);
		System.out.println("-------------------------");
		
		Object o=m.clone();
		Remote k=(Remote)o;
		System.out.println("id is "+k.id);
		System.out.println("name is "+k.name);
	}

}
 