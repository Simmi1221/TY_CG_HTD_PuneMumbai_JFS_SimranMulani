package com.capgemini.colllection.ALpassingToMethod;

public class Student {
	
	int id;
	String name;
	double percentage;
	
	
	public Student(int id, String name, double percentage) {
	
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	
	

}
