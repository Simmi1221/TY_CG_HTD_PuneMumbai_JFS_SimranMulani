package com.capgemini.colllection.ALpassingToMethod;

import java.util.ArrayList;
import java.util.Collections;

public class TestD {

	public static void main(String[] args) {

		ArrayList al=new ArrayList();
		
		al.add('B');
		al.add('E');
		al.add('T');
		al.add('A');
		
		System.out.println("Before---------->"+al);
		
		Collections.sort(al);
		
		System.out.println("After---------->"+al);
		
		Collections.shuffle(al);
		
		System.out.println("After---------->"+al);
		
		
		
	}

}
