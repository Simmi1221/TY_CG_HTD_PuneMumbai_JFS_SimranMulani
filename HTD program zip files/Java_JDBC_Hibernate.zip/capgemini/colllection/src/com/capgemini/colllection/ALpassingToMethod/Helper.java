package com.capgemini.colllection.ALpassingToMethod;

import java.util.ArrayList;
import java.util.Iterator;

public class Helper {

	void display(ArrayList<Student> k) {

		for (Student t : k) {
			System.out.println("id :" + t.id);
			System.out.println("name :" + t.name);
			System.out.println("percentage :" + t.percentage);
			System.out.println("-------------------------------------");
		}
	}

	void onlyPass(ArrayList<Student> k) {

		Iterator<Student> its = k.iterator();

		System.out.println("Only the passed student----------");

		while (its.hasNext()) {
			Student m = its.next();

			if (m.percentage >= 35) {
				System.out.println("id :" + m.id);
				System.out.println("name :" + m.name);
				System.out.println("percentage :" + m.percentage);
				System.out.println("-------------------------------------");

			}
		}

	}

	void distinction(ArrayList<Student> k) {

		Iterator<Student> its = k.iterator();

		System.out.println("Student who get Distinction-------");

		while (its.hasNext()) {
			Student m = its.next();

			if (m.percentage >= 75) {
				System.out.println("id :" + m.id);
				System.out.println("name :" + m.name);
				System.out.println("percentage :" + m.percentage);
				System.out.println("-------------------------------------");

			}

		}
	}

}
