package com.capgemini.flipcart.user;

public class Payment {

}
