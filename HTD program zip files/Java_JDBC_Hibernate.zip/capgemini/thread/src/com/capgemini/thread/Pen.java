package com.capgemini.thread;

public class Pen extends Thread {
	
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				sleep(1000);//wait(1000) we get same output
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
