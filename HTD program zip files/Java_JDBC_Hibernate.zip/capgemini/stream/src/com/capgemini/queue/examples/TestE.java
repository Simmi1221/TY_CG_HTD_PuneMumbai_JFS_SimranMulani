package com.capgemini.queue.examples;

import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class TestE {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> al=new ArrayList<Integer>();
		
		al.add(10);
		al.add(34);
		al.add(23);
		al.add(25);
		al.add(4);
		
		List<Integer> li= al.stream().filter(i->i%2==0).collect(Collectors.toList());
		
		for(Integer k:li) {
			System.out.println(k);
		}
	}

}
