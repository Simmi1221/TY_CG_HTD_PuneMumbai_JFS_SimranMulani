package com.capgemini.functioninterfaceExample;

import java.util.function.Function;

public class TestB {
	
	public static void main(String[] args) {
		
		Function <Integer,Integer> f=i->i*i;
		
		Integer j=f.apply(5);
		System.out.println("Result is "+j);
	}

}
