package com.capgemini.stream;

public class Employee {
	
	public int id;
	public String name;
	public double height;
	
	
	public Employee(int id, String name, double height) {
		this.id = id;
		this.name = name;
		this.height = height;
	}
	
	

}
