package com.capg.corejava.inheritance1;

public class InterfaceExample1 implements IntEx1 {

	@Override
	public void print() {
		System.out.println("Implemented print method of interface");
	}

	@Override
	public void display() {

		System.out.println("Implemented Display Method of Interface");
	}

	public static void main(String[] args) {
		
		IntEx1 ie=new InterfaceExample1();
		ie.print();
		ie.display();
		IntEx1.show();
		
		
	}

	@Override
	public void printNum() {
	System.out.println("12345");
	}
	}

