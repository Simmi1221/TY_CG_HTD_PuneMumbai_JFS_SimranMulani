package com.capg.corejava.inheritance;

public abstract class Test extends Demo implements InterfacesExample {

	public static void main(String[] args) {
		

	}

	@Override
	public void print() {
		
		
	}

}
