package com.capg.corejava.vikas;

public class Driver {

	void receive(Car c) {
		c.move();
	}
	
	
}
