package com.capg.corejava.methods;

public class FinalOverload2 extends FinalOverload1{
	final void method(int a, int b) {
		System.out.println("Subclass");
	}
 
	public static void main(String[] args) {
		
		FinalOverload2 obj=new FinalOverload2();
		obj.method(10);
		obj.method(10,20);

	}

}
