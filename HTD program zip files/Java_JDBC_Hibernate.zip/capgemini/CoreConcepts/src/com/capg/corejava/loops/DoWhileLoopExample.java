package com.capg.corejava.loops;

public class DoWhileLoopExample {

	public static void main(String[] args) {
		int i=10;
		do {
			System.out.println("i="+i);
			i++;
		}while(i<=20);
		System.out.println("Code Outside 1st do-while loop ");
		
		int j=21;
		do {
			System.out.println("j="+j);
			j++;
		}while(j<=20);
		System.out.println("Code Outside 2nd do-while loop ");
		

	}

}
