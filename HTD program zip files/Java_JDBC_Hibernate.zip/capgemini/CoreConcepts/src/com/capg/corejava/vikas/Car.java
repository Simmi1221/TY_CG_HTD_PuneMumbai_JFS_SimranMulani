package com.capg.corejava.vikas;

public class Car {
	
	void move()
	{
		System.out.println("I am a move() method");
	}
	
}
