package com.capg.corejava.vikas;

public class SBI implements ATM {

	@Override
	public void validateCard() {
		System.out.println(" Validating card from SBI DB");
		
		
	}

	@Override
	public void getInfo() {
		System.out.println(" Getting account holder info from SBI DB");
		
	}
	

}
