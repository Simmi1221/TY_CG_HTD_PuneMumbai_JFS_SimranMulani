package com.capg.corejava.vikas;

public class TestA {
	public static void main(String[] args) {
		Car i=new Car();
		Driver d=new Driver();
		d.receive(i);

	}

	

}
