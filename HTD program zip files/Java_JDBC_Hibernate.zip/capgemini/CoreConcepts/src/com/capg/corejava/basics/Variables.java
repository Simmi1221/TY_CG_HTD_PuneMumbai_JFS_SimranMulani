package com.capg.corejava.basics;

public class Variables 
{

	public static void main(String[] args)
	{
		byte b=127;       //declaration and initialization of byte
		//byte b=128;    it gives error 
		short s=101;     //declaration and initialization of short
		int i=20;        //declaration and initialization of int
		long l=2000l;    //declaration and initialization of long
		float f=10.2012345f;  //declaration and initialization of float
		double d=1000.253435464444;//declaration and initialization of double
		char ch='a';     //declaration and initialization of char
		boolean bo=true; //declaration and initialization of boolean
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(ch);
		System.out.println(bo);

	}

}
