package com.capg.corejava.vikas;

public interface Chips {
	void open();
	void eat();

}
