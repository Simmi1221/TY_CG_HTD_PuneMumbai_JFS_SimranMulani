package com.mpt1.gmail.dao;

import com.mpt1.gmail.beans.Account;
import com.mpt1.gmail.beans.Inbox;

public interface UserDAO {
	
	public Account verify(String email,String password);
	public Inbox compose(String mail,String message);
	public Inbox showInbox(String emailId);
	public Account registerYourAccount(String username,String password,String emailId);
	
	

}
