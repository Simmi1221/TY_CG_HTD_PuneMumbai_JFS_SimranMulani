package com.mpt1.gmail.factory;

import com.mpt1.gmail.dao.UserDAO;
import com.mpt1.gmail.dao.UserDAOJDBCImpl;

public class UserFactory {

	private UserFactory() {

	}

	public static UserDAO getInstance() {

		UserDAO dao = new UserDAOJDBCImpl();

		return dao;
	}
}
