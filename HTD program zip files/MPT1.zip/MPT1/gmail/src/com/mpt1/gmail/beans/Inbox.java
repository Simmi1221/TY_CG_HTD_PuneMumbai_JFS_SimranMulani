package com.mpt1.gmail.beans;

import lombok.Data;

@Data
public class Inbox {
	private int messageId;
	private int userId;
	private String message;
	
	@Override
	public String toString() {
		return "Inbox [messageId=" + messageId + ", userId=" + userId + ", message=" + message + "]";
	}
	
}
