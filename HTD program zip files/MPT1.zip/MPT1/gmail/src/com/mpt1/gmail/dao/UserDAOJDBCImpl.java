package com.mpt1.gmail.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mpt1.gmail.beans.Account;
import com.mpt1.gmail.beans.Inbox;

public class UserDAOJDBCImpl implements UserDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/Gmail?user=root&password=tiger";

	public UserDAOJDBCImpl() {
		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded........");
			System.out.println("*************************");

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public Account verify(String email, String password) {
		String query = "select User_ID from account where Email=? and Password=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, email);
			pstmt.setString(2, password);
			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println("proceed");
					System.out.println("select A to compose");
					System.out.println("select B to show inbox");
					System.out.println("select your option");
				} else {
					System.out.println("enter valid email and password");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Inbox compose(String mail, String message) {
		String query = "insert into inbox (Message) values(?) where User_Id=(select User_Id from Account where Email=?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, message);
			pstmt.setString(2, mail);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("message composed");
			} else {
				System.out.println("enter valid email ");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Inbox showInbox(String emailId) {
		String query = "select * from inbox where User_Id=(select User_Id from Account where Email=?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, emailId);
			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println(res);
				} else {
					System.out.println("enter valid email ");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Account registerYourAccount(String username, String password, String emailId) {
		String query = "insert into Account (User_Name,Password,Email) values (?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, emailId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("Account created");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
