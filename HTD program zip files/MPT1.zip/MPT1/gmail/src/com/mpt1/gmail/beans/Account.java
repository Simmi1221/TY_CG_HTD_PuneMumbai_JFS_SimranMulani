package com.mpt1.gmail.beans;

import lombok.Data;

@Data
public class Account {
	private int userId;
	private String userName;
	private String password;
	private String email;
	
	@Override
	public String toString() {
		return "Account [userId=" + userId + ", userName=" + userName + ", password=" + password + ", email=" + email
				+ "]";
	}

	
}
