package com.mpt1.gmail.controller;

import java.util.Scanner;

import com.mpt1.gmail.beans.Account;
import com.mpt1.gmail.beans.Inbox;
import com.mpt1.gmail.dao.UserDAO;
import com.mpt1.gmail.factory.UserFactory;

public class GmailMain {
	public static void main(String[] args) {

		UserDAO user = UserFactory.getInstance();
		Scanner sc = new Scanner(System.in);

		System.out.println("Press 1 to login");
		System.out.println("Press 2 to register");

		System.out.println("select your option");
		int choice = Integer.parseInt(sc.nextLine());

		switch (choice) {

		case 1:
			System.out.println("enter email");
			String email = sc.nextLine();
			System.out.println("enter password");
			String pass = sc.nextLine();

			Account account = user.verify(email, pass);

			String ch = sc.nextLine();
			switch (ch) {
			case "A":
				System.out.println("enter email");
				String email1 = sc.nextLine();
				System.out.println("enter message");
				String message = sc.nextLine();
				Inbox inbox = user.compose(email1, message);
				break;

			case "B":
				System.out.println("Enter emailid");
				String emailId = sc.nextLine();
				Inbox inbox1 = user.showInbox(emailId);
				break;
				
			default:
				System.out.println("select valid character option");
			}
			break;

		case 2:
			System.out.println("enter your usename");
			String username = sc.nextLine();
			System.out.println("enter your password");
			String password = sc.nextLine();
			System.out.println("enter your email");
			String emailId = sc.nextLine();
			Account account1 = user.registerYourAccount(username, password, emailId);
			break;

		default:
			System.out.println("select valid option");

		}

	}
}