package com.capgemin.medicalspringboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemin.medicalspringboot.beans.AdminInfoBean;
import com.capgemin.medicalspringboot.beans.AdminMsgBox;
import com.capgemin.medicalspringboot.beans.CartInfoBean;
import com.capgemin.medicalspringboot.beans.OrderInfoBean;
import com.capgemin.medicalspringboot.beans.ProductInfoBean;
import com.capgemin.medicalspringboot.beans.UserInfoBean;
import com.capgemin.medicalspringboot.beans.UserMsgBox;

@Repository
public class MedicalDAOImpl implements MedicalDAO {

	@PersistenceUnit
	private EntityManagerFactory emf;
	EntityManager em = null;
	EntityTransaction tran = null;

	@Override
	public int adminAuthenticate(String username, String password) {

		em = emf.createEntityManager();
		String jpql = "from AdminInfoBean where username=:uname and password=:pwd";
		Query query = em.createQuery(jpql);
		query.setParameter("uname", username);
		query.setParameter("pwd", password);
		int adminId = 0;
		AdminInfoBean adminInfoBean = null;
		try {
			adminInfoBean = (AdminInfoBean) query.getSingleResult();
			adminId = adminInfoBean.getAdminId();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return adminId;
	}

	@Override
	public boolean addProduct(ProductInfoBean productInfobean) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isAdded = false;
		try {
			tran.begin();
			em.persist(productInfobean);
			tran.commit();
			isAdded = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return isAdded;

	}

	@Override
	public boolean updateProduct(ProductInfoBean productInfoBean) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isUpdated = false;
		ProductInfoBean productInfo1 = em.find(ProductInfoBean.class, productInfoBean.getProdId());
		if (productInfo1 != null) {
			if (productInfoBean.getProdName() != null) {
				productInfo1.setProdName(productInfoBean.getProdName());
			}
			if (productInfoBean.getProdCategory() != null) {
				productInfo1.setProdCategory(productInfoBean.getProdCategory());
			}
			if (productInfoBean.getPrice() != 0) {
				productInfo1.setPrice(productInfoBean.getPrice());
			}
			if (productInfoBean.getQuantity() != 0) {
				productInfo1.setQuantity(productInfoBean.getQuantity());
			}
		}
		try {
			tran.begin();
			em.persist(productInfo1);
			tran.commit();
			isUpdated = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();

		return isUpdated;
	}

	@Override
	public boolean deleteProduct(int prodId) {
		EntityManager em = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			tran = em.getTransaction();
			tran.begin();
			ProductInfoBean productInfoBean1 = em.find(ProductInfoBean.class, prodId);
			em.remove(productInfoBean1);
			tran.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		em.close();
		return isDeleted;

	}

	@Override
	public List<ProductInfoBean> listOfProducts() {
		em = emf.createEntityManager();
		String jpql = "from ProductInfoBean";
		Query query = em.createQuery(jpql);

		List<ProductInfoBean> productsList = null;
		try {
			productsList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return productsList;
	}
	
	@Override
	public List<OrderInfoBean> generateReport() {
		em = emf.createEntityManager();
		String jpql = "from OrderInfoBean";
		Query query = em.createQuery(jpql);

		List<OrderInfoBean> orderedList = null;
		try {
			orderedList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return orderedList;
	}

	@Override
	public boolean userRegistration(UserInfoBean bean) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isRegistered = false;
		try {
			tran.begin();
			em.persist(bean);
			tran.commit();
			isRegistered = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return isRegistered;
	}

	@Override
	public int userAuthenticate(String username, String password) {
		int userId = 0;
		em = emf.createEntityManager();
		String jpql = "from UserInfoBean where username=:uname and password=:pwd";
		Query query = em.createQuery(jpql);
		query.setParameter("uname", username);
		query.setParameter("pwd", password);

		UserInfoBean userInfoBean = null;
		try {
			userInfoBean = (UserInfoBean) query.getSingleResult();
			userId = userInfoBean.getUserId();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userId;
	}

	@Override
	public List<UserInfoBean> listOfUser() {
		em = emf.createEntityManager();
		String jpql = "from UserInfoBean";
		Query query = em.createQuery(jpql);

		List<UserInfoBean> usersList = null;
		try {
			usersList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return usersList;
	}

	@Override
	public boolean deleteUser(int userId) {
		EntityManager em = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			tran = em.getTransaction();
			tran.begin();
			UserInfoBean userInfoBean1 = em.find(UserInfoBean.class, userId);
			em.remove(userInfoBean1);
			tran.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		em.close();
		return isDeleted;
	}
	
	@Override
	public boolean updateUserProfile(int userId, UserInfoBean userInfoBean) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isUpdated = false;
		UserInfoBean userInfoBean1 = em.find(UserInfoBean.class, userId);
		if (userInfoBean1 != null) {
			if (userInfoBean.getUsername() != null) {
				userInfoBean1.setUsername(userInfoBean.getUsername());
			}
			if (userInfoBean.getEmail() != null) {
				userInfoBean1.setEmail(userInfoBean.getEmail());
			}
			if (userInfoBean.getMobile() != 0) {
				userInfoBean1.setMobile(userInfoBean.getMobile());
			}
			if (userInfoBean.getPassword() != null) {
				userInfoBean1.setPassword(userInfoBean.getPassword());
			}
		}
		try {
			tran.begin();
			em.persist(userInfoBean1);
			tran.commit();
			isUpdated = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();

		return isUpdated;
	}

	@Override
	public boolean addToCart(int userId, int quantity, String productName) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isAdded = false;

		CartInfoBean cartInfoBean=new CartInfoBean();
		String jpql = "select p from ProductInfoBean p where prodName=:productName";
		Query query = em.createQuery(jpql);
		query.setParameter("productName", productName);
		List<ProductInfoBean> list = query.getResultList();
		for (ProductInfoBean li : list) {
			cartInfoBean.setUserId(userId);
			cartInfoBean.setProdId(li.getProdId());
			cartInfoBean.setSelectedProdName(li.getProdName());
			cartInfoBean.setProdCategory(li.getProdCategory());
			cartInfoBean.setPrice(li.getPrice());
			cartInfoBean.setQuantity(quantity);

			try {
				tran.begin();
				em.persist(cartInfoBean);
				tran.commit();
				isAdded = true;

			} catch (Exception e) {
				e.printStackTrace();
			}
			em.close();
		}
		return isAdded;
	}

	@Override
	public List<CartInfoBean> listOfSelectedProducts() {
		em = emf.createEntityManager();
		String jpql = "from CartInfoBean";
		Query query = em.createQuery(jpql);

		List<CartInfoBean> productsList = null;
		try {
			productsList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return productsList;
	}

	@Override
	public boolean deleteFromcart(int cartId) {
		EntityManager em = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			tran = em.getTransaction();
			tran.begin();
			CartInfoBean cartInfoBean = em.find(CartInfoBean.class, cartId);

			em.remove(cartInfoBean);
			tran.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		em.close();
		return isDeleted;
	}

	@Override
	public boolean placeOrder(int userId) {

		em = emf.createEntityManager();
		tran = em.getTransaction();

		String jpql = "from CartInfoBean where userId=:userId";
		Query query = em.createQuery(jpql);
		query.setParameter("userId", userId);
		boolean isOrdered = false;

		OrderInfoBean orderInfoBean = new OrderInfoBean();
		List<CartInfoBean> cartList = query.getResultList();
		for (CartInfoBean list : cartList) {
			int cartId = list.getCarId();
			int prodId = list.getProdId();
			String prodName = list.getSelectedProdName();
			String category = list.getProdCategory();
			double price = list.getPrice();
			int quantity = list.getQuantity();

			orderInfoBean.setCartId(cartId);
			orderInfoBean.setProdId(prodId);
			orderInfoBean.setProdName(prodName);
			orderInfoBean.setProdCategory(category);
			orderInfoBean.setPrice(price);
			orderInfoBean.setQuantity(quantity);
			orderInfoBean.setUserId(userId);

			tran.begin();
			em.persist(orderInfoBean);
			tran.commit();
		}

		isOrdered = true;
		em.close();
		return isOrdered;
	}
	
	@Override
	public double payment(int userId) {
		double bill = 0;
		em = emf.createEntityManager();
		String jpql = "select SUM(price*quantity) from CartInfoBean where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);
		List<Double> list = query.getResultList();
		for (Double li : list) {
			bill = li.doubleValue();
		}
		System.out.println(bill);
		return bill;
	}

	@Override
	public boolean ReplyToUser(int adminId, int userId, String message) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isSent = false;

		String jpql = "select u from AdminInfoBean u where adminId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", adminId);
		AdminInfoBean adminInfoBean = (AdminInfoBean) query.getSingleResult();
		String adminName = adminInfoBean.getUsername();

		UserMsgBox msgBox = new UserMsgBox();
		msgBox.setAdminId(adminId);
		msgBox.setAdminName(adminName);
		msgBox.setInbox(message);
		msgBox.setUserId(userId);

		try {
			tran.begin();
			em.persist(msgBox);
			tran.commit();
			isSent = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return isSent;
	}

	@Override
	public List<UserMsgBox> seeAllSentMessage(int adminId) {
		em = emf.createEntityManager();
		tran = em.getTransaction();

		String jpql = "from UserMsgBox where adminId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", adminId);
		List<UserMsgBox> messageList = null;
		try {

			messageList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return messageList;
	}

	@Override
	public boolean sendMessageToAdmin(int userId, String message) {

		em = emf.createEntityManager();
		tran = em.getTransaction();
		boolean isSent = false;

		String jpql = " from UserInfoBean  where userId=:userId";
		Query query = em.createQuery(jpql);
		query.setParameter("userId", userId);
		UserInfoBean userInfoBean = (UserInfoBean) query.getSingleResult();
		String userName = userInfoBean.getUsername();
		AdminMsgBox msgBox = new AdminMsgBox();
		msgBox.setUserId(userId);
		;
		msgBox.setUsername(userName);
		;
		msgBox.setInbox(message);

		tran.begin();
		em.persist(msgBox);
		isSent = true;
		tran.commit();

		em.close();
		return isSent;
	}

	@Override
	public List<AdminMsgBox> seeAllSentMessages(int userId) {
		em = emf.createEntityManager();
		tran = em.getTransaction();

		String jpql = "from AdminMsgBox where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);

		List<AdminMsgBox> messageList = null;
		try {

			messageList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return messageList;
	}


}
