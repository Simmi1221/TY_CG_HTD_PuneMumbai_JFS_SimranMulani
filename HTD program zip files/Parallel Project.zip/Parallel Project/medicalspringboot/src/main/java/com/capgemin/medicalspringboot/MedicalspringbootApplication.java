package com.capgemin.medicalspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalspringbootApplication.class, args);
	}

}
