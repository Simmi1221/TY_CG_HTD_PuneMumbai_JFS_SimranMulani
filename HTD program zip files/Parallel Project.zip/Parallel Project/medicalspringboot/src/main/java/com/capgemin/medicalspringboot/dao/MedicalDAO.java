package com.capgemin.medicalspringboot.dao;

import java.util.List;

import com.capgemin.medicalspringboot.beans.AdminMsgBox;
import com.capgemin.medicalspringboot.beans.CartInfoBean;
import com.capgemin.medicalspringboot.beans.OrderInfoBean;
import com.capgemin.medicalspringboot.beans.ProductInfoBean;
import com.capgemin.medicalspringboot.beans.UserInfoBean;
import com.capgemin.medicalspringboot.beans.UserMsgBox;

public interface MedicalDAO {

	public int adminAuthenticate(String username, String password);

	public boolean addProduct(ProductInfoBean productInfobean);

	public boolean updateProduct(ProductInfoBean productInfoBean);

	public boolean deleteProduct(int prodId);

	public List<ProductInfoBean> listOfProducts();

	public List<UserInfoBean> listOfUser();
	
	public boolean deleteUser(int userId);

	public boolean ReplyToUser(int adminId, int userId, String message);

	public List<UserMsgBox> seeAllSentMessage(int adminId);
	
	public List<OrderInfoBean> generateReport();
	

	public boolean userRegistration(UserInfoBean userInfoBean);

	public int userAuthenticate(String username, String password);

	public boolean updateUserProfile(int userId, UserInfoBean userInfoBean);

	public boolean addToCart(int userId, int quantity, String productName);

	public List<CartInfoBean> listOfSelectedProducts();

	public boolean deleteFromcart(int cartId);
	
	public boolean placeOrder(int userId);

	public double payment(int userId);

	public boolean sendMessageToAdmin(int userId, String message);

	public List<AdminMsgBox> seeAllSentMessages(int userId);

}
