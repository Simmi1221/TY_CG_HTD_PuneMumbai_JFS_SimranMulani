package com.capgemin.medicalspringboot.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cart_info")
public class CartInfoBean {

	@Id
	@Column
	private int carId;
	@Column
	private int prodId;
	@Column
	private String selectedProdName;
	@Column
	private String prodCategory;
	@Column
	private double price;
	@Column
	private int quantity;
	@Column
	private int userId;

	// Getters and Setters

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getSelectedProdName() {
		return selectedProdName;
	}

	public void setSelectedProdName(String selectedProdName) {
		this.selectedProdName = selectedProdName;
	}

	public String getProdCategory() {
		return prodCategory;
	}

	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
