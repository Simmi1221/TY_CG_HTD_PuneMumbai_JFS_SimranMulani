package com.capgemin.medicalspringboot.beans;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicalResponse {

	private int statusCode;
	private String message;
	private String description;
	private AdminInfoBean adminInfoBean;
	private List<AdminInfoBean> adminList;
	private UserInfoBean userInfoBean;
	private List<UserInfoBean> userList;
	private ProductInfoBean productInfoBean;
	private List<ProductInfoBean> productList;
	private CartInfoBean cartInfoBean;
	private List<CartInfoBean> cartList;
	private OrderInfoBean orderInfoBean;
	private List<OrderInfoBean> orderList;

	private AdminMsgBox adminMsgBox;
	private List<AdminMsgBox> msgList;
	private UserMsgBox userMsgBox;
	private List<UserMsgBox> messageList;

	// Getters and Setters

	public List<UserMsgBox> getMessageList() {
		return messageList;
	}

	public void setMessageList(List<UserMsgBox> messageList) {
		this.messageList = messageList;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AdminInfoBean getAdminInfoBean() {
		return adminInfoBean;
	}

	public void setAdminInfoBean(AdminInfoBean adminInfoBean) {
		this.adminInfoBean = adminInfoBean;
	}

	public List<AdminInfoBean> getAdminList() {
		return adminList;
	}

	public void setAdminList(List<AdminInfoBean> adminList) {
		this.adminList = adminList;
	}

	public UserInfoBean getUserInfoBean() {
		return userInfoBean;
	}

	public void setUserInfoBean(UserInfoBean userInfoBean) {
		this.userInfoBean = userInfoBean;
	}

	public List<UserInfoBean> getUserList() {
		return userList;
	}

	public void setUserList(List<UserInfoBean> userList) {
		this.userList = userList;
	}

	public ProductInfoBean getProductInfoBean() {
		return productInfoBean;
	}

	public void setProductInfoBean(ProductInfoBean productInfoBean) {
		this.productInfoBean = productInfoBean;
	}

	public List<ProductInfoBean> getProductList() {
		return productList;
	}

	public void setProductList(List<ProductInfoBean> productList) {
		this.productList = productList;
	}

	public CartInfoBean getCartInfoBean() {
		return cartInfoBean;
	}

	public void setCartInfoBean(CartInfoBean cartInfoBean) {
		this.cartInfoBean = cartInfoBean;
	}

	public List<CartInfoBean> getCartList() {
		return cartList;
	}

	public void setCartList(List<CartInfoBean> cartList) {
		this.cartList = cartList;
	}

	public OrderInfoBean getOrderInfoBean() {
		return orderInfoBean;
	}

	public void setOrderInfoBean(OrderInfoBean orderInfoBean) {
		this.orderInfoBean = orderInfoBean;
	}

	public List<OrderInfoBean> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderInfoBean> orderList) {
		this.orderList = orderList;
	}

	public AdminMsgBox getAdminMsgBox() {
		return adminMsgBox;
	}

	public void setAdminMsgBox(AdminMsgBox adminMsgBox) {
		this.adminMsgBox = adminMsgBox;
	}

	public List<AdminMsgBox> getMsgList() {
		return msgList;
	}

	public void setMsgList(List<AdminMsgBox> msgList) {
		this.msgList = msgList;
	}

	public UserMsgBox getUserMsgBox() {
		return userMsgBox;
	}

	public void setUserMsgBox(UserMsgBox userMsgBox) {
		this.userMsgBox = userMsgBox;
	}

}
