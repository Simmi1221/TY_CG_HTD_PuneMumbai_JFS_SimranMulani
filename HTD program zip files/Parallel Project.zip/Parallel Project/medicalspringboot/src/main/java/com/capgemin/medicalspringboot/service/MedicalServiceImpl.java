package com.capgemin.medicalspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemin.medicalspringboot.beans.AdminMsgBox;
import com.capgemin.medicalspringboot.beans.CartInfoBean;
import com.capgemin.medicalspringboot.beans.OrderInfoBean;
import com.capgemin.medicalspringboot.beans.ProductInfoBean;
import com.capgemin.medicalspringboot.beans.UserInfoBean;
import com.capgemin.medicalspringboot.beans.UserMsgBox;
import com.capgemin.medicalspringboot.dao.MedicalDAO;

@Service
public class MedicalServiceImpl implements MedicalService{

	@Autowired
	private MedicalDAO dao;
	
	@Override
	public int adminAuthenticate(String username, String password) {
		return dao.adminAuthenticate(username, password);
	}

	@Override
	public boolean addProduct(ProductInfoBean productInfobean) {
		return dao.addProduct(productInfobean);
	}

	@Override
	public boolean updateProduct(ProductInfoBean productInfoBean) {
		return dao.updateProduct(productInfoBean);
	}

	@Override
	public boolean deleteProduct(int prodId) {
		return dao.deleteProduct(prodId);
	}

	@Override
	public List<ProductInfoBean> listOfProducts() {
		return dao.listOfProducts();
	}

	@Override
	public boolean userRegistration(UserInfoBean bean) {
		return dao.userRegistration(bean);
	}

	@Override
	public int userAuthenticate(String username, String password) {
		return dao.userAuthenticate(username, password);
	}

	@Override
	public List<UserInfoBean> listOfUser() {
		return dao.listOfUser();
	}

	@Override
	public boolean deleteUser(int userId) {
		return dao.deleteUser(userId);
	}
	
	@Override
	public boolean updateUserProfile(int userId,UserInfoBean userInfoBean) {
		return dao.updateUserProfile(userId,userInfoBean);
	}
	
	@Override
	public boolean addToCart(int userId, int quantity, String productName) {
		return dao.addToCart(userId, quantity, productName);
	}
	
	@Override
	public List<CartInfoBean> listOfSelectedProducts() {
		return dao.listOfSelectedProducts();
	}

	
	@Override
	public boolean deleteFromcart(int cartId) {
		return dao.deleteFromcart(cartId);
	}

	
	@Override
	public double payment(int userId) {
		return dao.payment(userId);
	}

	@Override
	public List<UserMsgBox> seeAllSentMessage(int adminId) {
		return dao.seeAllSentMessage(adminId);
	}

	@Override
	public List<AdminMsgBox> seeAllSentMessages(int userId) {
		return dao.seeAllSentMessages(userId);
	}

	@Override
	public boolean ReplyToUser(int adminId,int userId, String message) {
		return dao.ReplyToUser(adminId,userId, message);
	}

	@Override
	public boolean sendMessageToAdmin(int userId, String message) {
		return dao.sendMessageToAdmin(userId, message);
	}

	@Override
	public List<OrderInfoBean> generateReport() {
		return dao.generateReport();
	}

	@Override
	public boolean placeOrder(int userId) {
		return dao.placeOrder(userId);
	}

}
