package com.capgemin.medicalspringboot.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemin.medicalspringboot.beans.AdminMsgBox;
import com.capgemin.medicalspringboot.beans.CartInfoBean;
import com.capgemin.medicalspringboot.beans.MedicalResponse;
import com.capgemin.medicalspringboot.beans.UserInfoBean;
import com.capgemin.medicalspringboot.service.MedicalService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserRestController {

	@Autowired(required = true)
	private MedicalService service;

	int userId = 0;

	@GetMapping("/loginAsUser")
	public MedicalResponse loginAsUser(String username, String password) {

		userId = service.userAuthenticate(username, password);
		MedicalResponse response = new MedicalResponse();

		if (userId != 0) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User login successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to found user!!!");
		}
		return response;
	}// end of loginAsUser()
	
	@PutMapping("/registration")
	public MedicalResponse registration(@RequestBody UserInfoBean bean) {
		
		boolean isAdded=service.userRegistration(bean);
		MedicalResponse response=new MedicalResponse();
		
		if(isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User registered successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to register !!!");
		}
		return response ;
	}// end of registration()
	
	@PostMapping("/updateUserProfile")
	public MedicalResponse updateUserProfile(@RequestBody UserInfoBean userInfoBean) {
		boolean isUpdated = service.updateUserProfile(userId, userInfoBean);
		MedicalResponse response = new MedicalResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Your profile updated successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to update your profile!!!");
		}

		return response;
	}// end of updateUserProfile()

	@GetMapping("/displayCart")
	public MedicalResponse listOfSelectedProducts(HttpSession session) {

		List<CartInfoBean> cartList = service.listOfSelectedProducts();
		MedicalResponse response = new MedicalResponse();
		if (cartList != null && !cartList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Products found.....");
			response.setCartList(cartList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
		}
		return response;
	}// End of listOfProducts()

	@PutMapping("/addToCart")
	public MedicalResponse addToCart( String productName, int quantity) {

		boolean isAdded = service.addToCart(userId, quantity, productName);
		MedicalResponse response = new MedicalResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product added successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to add Product!!!");
		}

		return response;
	}

	@DeleteMapping("/deleteFromCart")
	public MedicalResponse deleteProduct(int cartId) {
		boolean isDeleted = service.deleteFromcart(cartId);
		MedicalResponse response = new MedicalResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product deleted from cart successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete the Product!!!");
		}
		return response;
	}// End of deleteProduct()

	@PutMapping("/placeOrder")
	public MedicalResponse placeOrder() {

		boolean isOrdered = service.placeOrder(userId);
		//double bill = service.payment(userId);
		MedicalResponse response = new MedicalResponse();

		if (isOrdered ) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Your order is confirmed.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable place the ordert!!!");
		}
		return response;
	}//end of placeOrder()
	
	@GetMapping("/payment")
	public MedicalResponse payment() {

		double bill = service.payment(userId);
		MedicalResponse response = new MedicalResponse();

		if (bill!=0) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Your bill is Rs."+bill);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable!!!");
		}
		return response;
	}//end of placeOrder()

	@PutMapping("/sendMessageToAdmin")
	public MedicalResponse sendMsgToAdmin(String message) {

		boolean isSent = service.sendMessageToAdmin(userId, message);
		MedicalResponse response = new MedicalResponse();
		if (isSent) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Message sent to admin successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to send the message!!!");
		}

		return response;
	}

	@GetMapping("/seeAllSentMessages")
	public MedicalResponse outboxOfUser() {

		List<AdminMsgBox> messageList = service.seeAllSentMessages(userId);
		MedicalResponse response = new MedicalResponse();

		if (messageList != null && !messageList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Messages found successfully.....");
			response.setMsgList(messageList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to found the message!!!");
		}
		return response;
	}// End of outBoxOfUser()
}
