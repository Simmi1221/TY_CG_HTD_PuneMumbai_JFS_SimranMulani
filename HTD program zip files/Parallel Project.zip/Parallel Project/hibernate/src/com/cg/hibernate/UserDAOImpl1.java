package com.cg.hibernate;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.jpawithhibernate.dto.Admin;
import com.cg.jpawithhibernate.dto.Admin_MsgBox;
import com.cg.jpawithhibernate.dto.Cart;
import com.cg.jpawithhibernate.dto.Product;
import com.cg.jpawithhibernate.dto.User;
import com.cg.jpawithhibernate.dto.User_MsgBox;

public class UserDAOImpl1 implements UserDAO1 {

	
	Scanner sc = new Scanner(System.in);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenceUnit");;
	EntityManager em = null;
	EntityTransaction tran = null;

	public void registerAdmin() {

		Admin admin = new Admin();

		System.out.println("Enter your username");
		String username = sc.nextLine();
		System.out.println("Enter your email");
		String email = sc.nextLine();
		System.out.println("Enter your mobile number");
		String mobile = sc.nextLine();
		System.out.println("Enter your password");
		String password = sc.nextLine();

		admin.setUsername(username);
		admin.setEmail(email);
		admin.setMobile(mobile);
		admin.setPassword(password);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(admin);
		tran.commit();
		em.close();

	}

	@Override
	public int loginAdmin(String email, String password) {

		em = emf.createEntityManager();
		String jpql = "select a from Admin a where email=:email and password=:password";
		Query query = em.createQuery(jpql);
		query.setParameter("email", email);
		query.setParameter("password", password);

		List<Admin> list = query.getResultList();

		for (Admin li : list) {
			int adminId = li.getAdminId();
			System.out.println("******************************");
			System.out.println("Welcome " + li.getUsername());
			System.out.println("******************************");
			return adminId;
		}
		return 0;
	}

	@Override
	public void addMedicines() {

		em = emf.createEntityManager();
		tran = em.getTransaction();

		Product product = new Product();

		System.out.println("Enter your medName");
		String medName = sc.nextLine();
		System.out.println("Enter your medCategory");
		String medCategory = sc.nextLine();
		System.out.println("Enter your price ");
		double price = Double.parseDouble(sc.nextLine());
		System.out.println("Enter your quantity");
		int quantity = Integer.parseInt(sc.nextLine());

		product.setMedName(medName);
		product.setMedCategory(medCategory);
		product.setPrice(price);
		product.setQuantity(quantity);

		tran.begin();
		em.persist(product);
		tran.commit();
		em.close();
	}

	@Override
	public void updateMedicines() {
		System.out.println("Enter count, how many medicines you want to update?");
		int count = Integer.parseInt(sc.nextLine());

		em = emf.createEntityManager();
		tran = em.getTransaction();

		for (int i = 1; i <= count; i++) {
			System.out.println("Enter medicine id which you want to update");
			int medId = Integer.parseInt(sc.nextLine());
			System.out.println("Enter medicine name to upadate");
			String medName = sc.nextLine();
			System.out.println("Enter price to update");
			double price = Double.parseDouble(sc.nextLine());
			System.out.println("Enter quantity to upadte");
			int quantity = Integer.parseInt(sc.nextLine());
			String jpql = "update Product set medName=:name,price=:pr,quantity=:quant where medId=:mid";
			tran.begin();
			Query query = em.createQuery(jpql);
			query.setParameter("name", medName);
			query.setParameter("pr", price);
			query.setParameter("quant", quantity);
			query.setParameter("mid", medId);

			Integer res = query.executeUpdate();
			tran.commit();
		}
		em.close();
	}

	@Override
	public void deleteMedicine() {

		System.out.println("Enter how many medicines/products ypu want to delete");
		int count = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= count; i++) {
			System.out.println("Enter medicine id which you want to delete");
			int medId = Integer.parseInt(sc.nextLine());
			em = emf.createEntityManager();
			tran = em.getTransaction();
			String jpql = "delete from Product where medId=:mid";
			tran.begin();
			Query query = em.createQuery(jpql);
			query.setParameter("mid", medId);
			query.executeUpdate();
			System.out.println("Deleted medicine/product successfully");
			tran.commit();
			em.close();

		}
	}

	@Override
	public void seeAllUsers() {

		em = emf.createEntityManager();
		String jpql = "from User";
		Query query = em.createQuery(jpql);

		List<User> list = query.getResultList();
		for (User li : list) {
			System.out.println("User Id      :" + li.getUserId());
			System.out.println("User name    :" + li.getUsername());
			System.out.println("Email id     :" + li.getEmail());
			System.out.println("Mobile Number:" + li.getMobileNum());
			System.out.println("--------------------------------------");
		}
		em.close();
	}

	@Override
	public void deleteUser(int userId) {

		em = emf.createEntityManager();
		tran = em.getTransaction();

		tran.begin();
		User user = em.find(User.class, userId);
		em.remove(user);
		tran.commit();
		em.close();
	}

	@Override
	public void ReplyToUser(int adminId) {
		System.out.println("Enter your name");
		String adminName = sc.nextLine();
		System.out.println("Enter your issue/message");
		String message = sc.nextLine();

		User_MsgBox msgBox = new User_MsgBox();
		msgBox.setAdminId(adminId);
		msgBox.setAdminName(adminName);
		msgBox.setInbox(message);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(msgBox);
		tran.commit();
		em.close();
	}

	@Override
	public void seeAllSentMessage(int adminId) {
		em = emf.createEntityManager();
		String jpql = "select m from User_MsgBox m where adminId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", adminId);

		List<User_MsgBox> list = query.getResultList();
		for (User_MsgBox li : list) {
			System.out.println("Message id :" + li.getMsgId());
			System.out.println("Message     :" + li.getInbox());
			System.out.println("---------------------------");
		}
		em.close();
	}

	@Override
	public void registerUser() {

		User user = new User();

		System.out.println("Enter your username");
		String username = sc.nextLine();
		System.out.println("Enter your email");
		String email = sc.nextLine();
		System.out.println("Enter your mobile number");
		String mobile =sc.nextLine();
		System.out.println("Enter your password");
		String password = sc.nextLine();

		user.setUsername(username);
		user.setEmail(email);
		user.setMobileNum(mobile);
		user.setPassword(password);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(user);
		tran.commit();
		em.close();
	}

	@Override
	public int loginUser(String email, String password) {
		em = emf.createEntityManager();
		String jpql = "select u from User u where email=:email and password=:password";
		Query query = em.createQuery(jpql);
		query.setParameter("email", email);
		query.setParameter("password", password);

		List<User> list = query.getResultList();

		for (User li : list) {
			int userId = li.getUserId();
			System.out.println("******************************");
			System.out.println("Welcome " + li.getUsername());
			System.out.println("******************************");
			return userId;
		}
		return 0;

	}

	@Override
	public void seeAllProducts() {

		em = emf.createEntityManager();
		String jpql = "from Product";
		Query query = em.createQuery(jpql);

		List<Product> list = query.getResultList();
		for (Product li : list) {
			System.out.println("Medicine Id      :" + li.getMedId());
			System.out.println("Medicine Name    :" + li.getMedName());
			System.out.println("Medicine Category:" + li.getMedCategory());
			System.out.println("Medicine Price   :" + li.getPrice());
			System.out.println("Medicine Quantity:" + li.getQuantity());
			System.out.println("---------------------------------------");
		}
		em.close();
	}

	@Override
	public void updateProfile(int userId) {
		em = emf.createEntityManager();
		tran = em.getTransaction();
		System.out.println("Enter User Name");
		String username = sc.nextLine();
		System.out.println("Enter mobile number");
		long mobile = Long.parseLong(sc.nextLine());
		System.out.println("enter email address");
		String email = sc.nextLine();
		System.out.println("password");
		String password = sc.nextLine();

		String jpql = "update User set username=:uname,email=:mail,mobileNum=:mob,password=:pwd where userId=:id ";
		tran.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("uname", username);
		query.setParameter("mail", email);
		query.setParameter("mob", mobile);
		query.setParameter("pwd", password);
		query.setParameter("id", userId);

		int res = query.executeUpdate();
		tran.commit();
		em.close();

	}

	@Override
	public void addToCart(int userId) {

		em = emf.createEntityManager();
		tran = em.getTransaction();

		System.out.println("Enter medicine/product name which you want to add in cart");
		String medName = sc.nextLine();
		System.out.println("Enter quantity of medicines/products that you want");
		int quant = Integer.parseInt(sc.nextLine());

		String jpql = "select p from Product p where medName=:name";
		Query query = em.createQuery(jpql);
		query.setParameter("name", medName);
		List<Product> list = query.getResultList();
		for (Product li : list) {
			int id = li.getMedId();
			String category = li.getMedCategory();
			String name = li.getMedName();
			double price = li.getPrice();

			Cart cart = new Cart();
			cart.setMedId(id);
			cart.setSelectedMedName(name);
			cart.setCategory(category);
			cart.setPrice(price);
			cart.setQuantity(quant);
			cart.setUserId(userId);

			tran.begin();
			em.persist(cart);
			tran.commit();
			System.out.println("Selected medicine is added into cart");
			em.close();
		}
	}

	@Override
	public void deleteFromCart(int userId) {
		System.out.println("Enter how many medicines/products ypu want to delete");
		int count = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= count; i++) {
			System.out.println("Enter cart id of mediciine/product which you want to delete");
			int cartId = Integer.parseInt(sc.nextLine());
			em = emf.createEntityManager();
			tran = em.getTransaction();
			String jpql = "delete from Cart where cartId=:cid";
			tran.begin();
			Query query = em.createQuery(jpql);
			query.setParameter("cid", cartId);
			query.executeUpdate();
			System.out.println("Deleted medicine/product from cart ");
			tran.commit();
			em.close();

		}

	}

	@Override
	public void payment(int userId) {
		String jpql = "select SUM(quantity*price) from Cart  where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);
		List<Double> list = query.getResultList();
		for (Double li : list) {
			double bill = li.doubleValue();
			System.out.println(bill);
		}

	}

	@Override
	public void sendMessageToAdmin(int userId) {
		System.out.println("Enter your name");
		String username = sc.nextLine();
		System.out.println("Enter your issue/message");
		String message = sc.nextLine();

		Admin_MsgBox msgBox = new Admin_MsgBox();
		msgBox.setUserId(userId);
		msgBox.setUsername(username);
		msgBox.setInbox(message);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(msgBox);
		tran.commit();
		em.close();

	}

	@Override
	public void seeAllSentMessages(int userId) {
		em = emf.createEntityManager();
		String jpql = "select m from Admin_MsgBox m where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);

		List<Admin_MsgBox> list = query.getResultList();
		for (Admin_MsgBox li : list) {
			System.out.println("Message id:" + li.getMsgId());
			System.out.println("Message   :" + li.getInbox());
		}
		em.close();
	}

}
