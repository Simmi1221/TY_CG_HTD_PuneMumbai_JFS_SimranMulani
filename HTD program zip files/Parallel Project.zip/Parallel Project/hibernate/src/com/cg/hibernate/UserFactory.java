package com.cg.hibernate;

import com.cg.jpawithhibernate.dao.UserDAO1;
import com.cg.jpawithhibernate.dao.UserDAOImpl1;

public class UserFactory {
	
	private UserFactory() {
		
	}
	
	public static UserDAO1 getInstan() {
		UserDAO1 dao=new UserDAOImpl1();
		return dao;
	}

}
