package com.cg.hibernate;

public interface UserDAO1 {

	public void registerAdmin();

	public int loginAdmin(String email, String password);

	public void addMedicines();

	public void updateMedicines();

	public void deleteMedicine();

	public void seeAllUsers();

	public void deleteUser(int userId);

	public void ReplyToUser(int adminId);

	public void seeAllSentMessage(int adminId);

	public void registerUser();

	public int loginUser(String email, String password);

	public void seeAllProducts();

	public void updateProfile(int userId);

	public void addToCart(int userId);

	public void deleteFromCart(int userId);

	public void payment(int userId);

	public void sendMessageToAdmin(int userId);

	public void seeAllSentMessages(int userId);

}
