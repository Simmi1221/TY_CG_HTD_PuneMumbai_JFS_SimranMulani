package com.cg.jpawithhibernate.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Cart {
	@Id
	@Column
	private int cartId;
	@Column
	private String selectedMedName;
	@Column
	private double price;
	@Column
	private int quantity;
	@Column
	private String category;
	@Column
	private int userId;
	@Column
	private int medId;
	
	//Getters and Setters
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getMedId() {
		return medId;
	}
	public void setMedId(int medId) {
		this.medId = medId;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public String getSelectedMedName() {
		return selectedMedName;
	}
	public void setSelectedMedName(String selectedMedName) {
		this.selectedMedName = selectedMedName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}//end of class
