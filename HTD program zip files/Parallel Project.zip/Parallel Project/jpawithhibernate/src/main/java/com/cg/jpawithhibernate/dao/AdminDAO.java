package com.cg.jpawithhibernate.dao;

public interface AdminDAO {
	
	public void registerAdmin(String username, String email, String mobileNum,String  password);

	public int loginAdmin(String email, String password);

	public void addMedicines();

	public void updateMedicines();

	public void deleteMedicine();

	public void seeAllUsers();

	public void deleteUser();

	public void ReplyToUser(int adminId);

	public void seeAllSentMessage(int adminId);


}
