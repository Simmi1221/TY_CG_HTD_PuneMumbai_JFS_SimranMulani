package com.cg.jpawithhibernate.factory;

import com.cg.jpawithhibernate.dao.AdminDAO;
import com.cg.jpawithhibernate.dao.AdminDAOImpl;
import com.cg.jpawithhibernate.dao.UserDAO;
import com.cg.jpawithhibernate.dao.UserDAOImpl;
import com.cg.jpawithhibernate.validation.AdminUserValidation;
import com.cg.jpawithhibernate.validation.AdminUserValidationImpl;
import com.cg.jpawithhibernate.validation.CustomValidation;
import com.cg.jpawithhibernate.validation.CustomValidationImpl;

public class MedicalFactory {

	private void MedicalFactory() {
	}

	public static AdminDAO getAdminInstance() {
		AdminDAO dao = new AdminDAOImpl();
		return dao;
	}

	public static UserDAO getUserInstance() {
		UserDAO dao = new UserDAOImpl();
		return dao;
	}

	public static AdminUserValidation getValidation() {
		AdminUserValidation dao = new AdminUserValidationImpl();
		return dao;
	}

	public static CustomValidation getCustomValidation() {
		CustomValidation dao = new CustomValidationImpl();
		return dao;
	}

}
