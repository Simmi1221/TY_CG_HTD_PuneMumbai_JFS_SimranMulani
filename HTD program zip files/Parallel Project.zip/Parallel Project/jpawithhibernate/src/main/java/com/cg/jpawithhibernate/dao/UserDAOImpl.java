package com.cg.jpawithhibernate.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.jpawithhibernate.dto.AdminMsgBox;
import com.cg.jpawithhibernate.dto.Cart;
import com.cg.jpawithhibernate.dto.Product;
import com.cg.jpawithhibernate.dto.User;
import com.cg.jpawithhibernate.factory.MedicalFactory;
import com.cg.jpawithhibernate.validation.AdminUserValidationImpl;
import com.cg.jpawithhibernate.validation.CustomValidation;

public class UserDAOImpl implements UserDAO {

	Scanner sc = new Scanner(System.in);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenceUnit");;
	EntityManager em = null;
	EntityTransaction tran = null;
	CustomValidation val2 = MedicalFactory.getCustomValidation();
	AdminUserValidationImpl val = new AdminUserValidationImpl();

	@Override
	public void registerUser(String username, String email, String mobileNum, String password) {

		User user = new User();
		user.setUsername(username);
		user.setEmail(email);
		user.setMobileNum(mobileNum);
		user.setPassword(password);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(user);
		tran.commit();
		em.close();
	}

	@Override
	public int loginUser(String email, String password) {

		int userId = 0;
		try {

			em = emf.createEntityManager();
			String jpql = "from User where email=:email and password=:password";
			Query query = em.createQuery(jpql);
			query.setParameter("email", email);
			query.setParameter("password", password);

			List<User> list = query.getResultList();

			for (User li : list) {
				userId = li.getUserId();
				System.out.println("******************************");
				System.out.println("Welcome " + li.getUsername());
				System.out.println("******************************");
				return userId;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userId;

	}

	@Override
	public void seeAllProducts() {

		em = emf.createEntityManager();
		String jpql = "from Product";
		Query query = em.createQuery(jpql);

		List<Product> list = query.getResultList();
		for (Product li : list) {
			System.out.println("Medicine Id      :" + li.getProductId());
			System.out.println("Medicine Name    :" + li.getProductName());
			System.out.println("Medicine Category:" + li.getCategory());
			System.out.println("Medicine Price   :" + li.getPrice());
			System.out.println("Medicine Quantity:" + li.getQuantity());
			System.out.println("---------------------------------------");
		}
		em.close();
	}

	@Override
	public void updateProfile(int userId) {

		System.out.println("Enter 1 to update the username");
		System.out.println("Enter 2 to update the email");
		System.out.println("Enter 3 to update the mobile number");
		System.out.println("Enter 4 to update the password");
		System.out.println("enter your choice................");
		String choice = sc.nextLine();
		switch (choice) {

		case "1":
			while (true) {
				System.out.println("Enter username to update");
				String username = sc.nextLine();
				if (val.usernameValidation(username)) {

					em = emf.createEntityManager();
					tran = em.getTransaction();
					String jpql = "update User set username=:uname where userId=:id ";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("uname", username);
					query.setParameter("id", userId);
					query.executeUpdate();
					tran.commit();
					System.out.println("Your profile updated successfully....");
					System.out.println("------------------------------------------");
					em.close();
					break;
				} else {
					System.err.println("Enter your full name!!!");
				}
			}

			break;

		case "2":
			boolean check = false;
			do {
				System.out.println("Enter email to update");
				String email = sc.nextLine();
				if (val.emailValidation(email)) {
					boolean isValid = val2.emailValidationForUser(email);
					System.out.println(isValid);
					if (!isValid) {

						em = emf.createEntityManager();
						tran = em.getTransaction();
						String jpql = "update User set email=:email where userId=:id ";
						tran.begin();
						Query query = em.createQuery(jpql);
						query.setParameter("email", email);
						query.setParameter("id", userId);
						query.executeUpdate();
						tran.commit();
						System.out.println("Your profile updated successfully....");
						System.out.println("------------------------------------------");
						em.close();
						check=true;
						break;

					} else {
						System.err.println("Entered email is already exist!!!");
						break;
					}
				} else {
					System.err.println("Enter valid email id!!!");
				}
			} while (!check);

			break;

		case "3":
			while (true) {
				System.out.println("Enter mobile number to update");
				String mobileNum = sc.nextLine();
				if (val.mobileNumValidation(mobileNum)) {

					em = emf.createEntityManager();
					tran = em.getTransaction();
					String jpql = "update User set mobileNum=:mobileNum where userId=:id ";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("mobileNum", mobileNum);
					query.setParameter("id", userId);
					query.executeUpdate();
					tran.commit();
					System.out.println("Your profile updated successfully....");
					System.out.println("------------------------------------------");
					em.close();
					break;

				} else {
					System.err.println("Enter valid 10 digit mobile number !!!");
				}
			}

			break;

		case "4":
			while (true) {
				System.out.println("Enter password to update");
				String password = sc.nextLine();
				if (val.passwordvalidation(password)) {

					em = emf.createEntityManager();
					tran = em.getTransaction();
					String jpql = "update User set password=:password where userId=:id ";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("password", password);
					query.setParameter("id", userId);
					query.executeUpdate();
					tran.commit();
					System.out.println("Your profile updated successfully....");
					System.out.println("------------------------------------------");
					em.close();
					break;

				} else {
					System.err.println("Enter valid password to update!!!");
				}
			}

			break;

		default:
			System.err.println("Enter only number between 1 to 4");

		}
	}

	@Override
	public void dispayCart(int userId) {
		em = emf.createEntityManager();
		String jpql = "from Cart";
		Query query = em.createQuery(jpql);

		List<Cart> list = query.getResultList();
		for (Cart li : list) {
			System.out.println("Product Id      :" + li.getCartId());
			System.out.println("Product Name    :" + li.getUserId());
			System.out.println("Product Category:" + li.getProductId());
			System.out.println("Product Name    :" + li.getProductName());
			System.out.println("Product Category:" + li.getCategory());
			System.out.println("Product Price   :" + li.getPrice());
			System.out.println("Product Quantity:" + li.getQuantity());
			System.out.println("---------------------------------------");
		}
		em.close();

	}

	@Override
	public void addToCart(int userId) {

		boolean check = false;
		do {

			em = emf.createEntityManager();
			tran = em.getTransaction();

			System.out.println("Enter medicine/product name which you want to add in cart");
			String productName = sc.nextLine();
			if (val2.checkProductName(productName)) {
				if (!val2.checkProductNameForCart(productName, userId)) {

					try {

						System.out.println("Enter quantity of medicines/products that you want");
						int quant = Integer.parseInt(sc.nextLine());
						if (val2.quantityValidation(quant, productName)) {

							String jpql = " from Product where productName=:name";
							Query query = em.createQuery(jpql);
							query.setParameter("name", productName);
							List<Product> list = query.getResultList();
							for (Product li : list) {
								int id = li.getProductId();
								String category = li.getCategory();
								String name = li.getProductName();
								double price = li.getPrice();

								Cart cart = new Cart();
								cart.setProductId(id);
								cart.setProductName(name);
								cart.setCategory(category);
								cart.setPrice(price);
								cart.setQuantity(quant);
								cart.setUserId(userId);

								tran.begin();
								em.persist(cart);
								tran.commit();
								System.out.println("Selected medicine is added into cart");
								em.close();
								check = true;
								break;
							}
						} else {
							System.err.println("Product out of stock!!!");
						}

					} catch (NumberFormatException e) {
						System.err.println("Enter number only!!!");
					}
				} else {
					System.err.println("Entered product name is already present in cart!!!");
				}

			} else {
				System.err.println("Product does not exist!!!");
			}

		} while (!check);
	}

	@Override
	public void deleteFromCart(int userId) {

		while (true) {
			try {

				System.out.println("Enter cart id of mediciine/product which you want to delete");
				int cartId = Integer.parseInt(sc.nextLine());
				if (val2.checkCartId(cartId, userId)) {

					em = emf.createEntityManager();
					tran = em.getTransaction();
					String jpql = "delete from Cart where cartId=:cid";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("cid", cartId);
					query.executeUpdate();
					System.out.println("Deleted medicine/product from cart ");
					tran.commit();
					em.close();
					break;
				} else {
					System.err.println("Entered cart id does not exist!!!");
				}
			} catch (NumberFormatException e) {
				System.err.println("Enter number only !!!");
			}
		}
	}

	@Override
	public void payment(int userId) {
		String jpql = "select SUM(quantity*price) from Cart  where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);
		List<Double> list = query.getResultList();
		for (Double li : list) {
			double bill = li.doubleValue();
			System.out.println(bill);
		}

	}

	@Override
	public void sendMessageToAdmin(int userId) {
		System.out.println("Enter your name");
		String username = sc.nextLine();
		System.out.println("Enter your issue/message");
		String message = sc.nextLine();

		AdminMsgBox msgBox = new AdminMsgBox();
		msgBox.setUserId(userId);
		msgBox.setUsername(username);
		msgBox.setInbox(message);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(msgBox);
		tran.commit();
		em.close();

	}

	@Override
	public void seeAllSentMessages(int userId) {
		em = emf.createEntityManager();
		String jpql = " from AdminMsgBox  where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);

		List<AdminMsgBox> list = query.getResultList();
		for (AdminMsgBox li : list) {
			System.out.println("Message id:" + li.getMsgId());
			System.out.println("Message   :" + li.getInbox());
		}
		em.close();
	}

}
