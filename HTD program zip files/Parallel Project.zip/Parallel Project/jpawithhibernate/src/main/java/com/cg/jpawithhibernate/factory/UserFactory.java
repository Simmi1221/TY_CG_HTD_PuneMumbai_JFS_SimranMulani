package com.cg.jpawithhibernate.factory;

import com.cg.jpawithhibernate.dao.UserDAO;
import com.cg.jpawithhibernate.dao.UserDAOImpl;

public class UserFactory {
	
	private UserFactory() {
		
	}
	
	public static UserDAO getInstan() {
		UserDAO dao=new UserDAOImpl();
		return dao;
	}

}
