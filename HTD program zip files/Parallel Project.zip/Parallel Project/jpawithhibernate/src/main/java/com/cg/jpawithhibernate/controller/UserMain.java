package com.cg.jpawithhibernate.controller;

import java.util.Scanner;

import com.cg.jpawithhibernate.dao.UserDAO;
import com.cg.jpawithhibernate.factory.UserFactory;

public class UserMain {

	public static void main(String[] args) {

		UserDAO dao = UserFactory.getInstan();
		Scanner sc = new Scanner(System.in);

		System.out.println("Press 1 to login as admin");
		System.out.println("Press 2 to login as user");
		System.out.println("Enter your choice........");
		int choice = Integer.parseInt(sc.nextLine());

		switch (choice) {
		case 1:
			System.out.println("Press R to register ad admin");
			System.out.println("Press L to login if you are already registerd");
			System.out.println("Enter your choice.....");
			String choice1 = sc.nextLine();
			switch (choice1) {

			case "R":
				dao.registerAdmin();

			case "L":
				System.out.println("Enter your email Id");
				String email = sc.nextLine();
				System.out.println("Enter your password");
				String password = sc.nextLine();
				int adminId = dao.loginAdmin(email, password);
				if (adminId > 0) {

					System.out.println("Press A to aee all medicines/products");
					System.out.println("Press B to add the medicines/products");
					System.out.println("Press C to update the medicines/products");
					System.out.println("Press D to delete the medicines/products");
					System.out.println("Press E to see all users");
					System.out.println("Press F to delete the user");
					System.out.println("Press G to see users issues/messages");
					System.out.println("Press H to send reply to user");
					System.out.println("Enter correct choice...........");
					String choice2 = sc.nextLine();

					switch (choice2) {

					case "A":
						dao.seeAllProducts();

					case "B":
						dao.addMedicines();

					case "C":
						System.out.println("if you want to update the medicine press Y");
						String choice3 = sc.nextLine();
						if (choice3.equals("Y")) {
							dao.updateMedicines();
						}

					case "D":
						System.out.println("If you want to delete the medicine press Y");
						String choice4 = sc.nextLine();
						if (choice4.equals("Y")) {
							dao.deleteMedicine();
						}

					case "E":
						dao.seeAllUsers();

					case "F":
						System.out.println("If you want to delete user press Y");
						String choice5 = sc.nextLine();
						if (choice5.equals("Y")) {
							System.out.println("Enter userId which you want to remove from database");
							int userId = Integer.parseInt(sc.nextLine());
							dao.deleteUser(userId);
							System.out.println("User deleted successfully.......");
						}

					case "G":
						System.out.println("If you want to see all users issues/messages press Y");
						String choice6 = sc.nextLine();
						if (choice6.equals("Y")) {
							dao.seeAllSentMessage(adminId);
						}

					case "H":
						System.out.println("If you want to reply to users issue/message press Y ");
						String choice7 = sc.nextLine();
						if (choice7.equals("Y")) {
							dao.ReplyToUser(adminId);
							System.out.println("message sent");
						}

						break;

					default:
						System.out.println("Enter correct choice......");
					}
				} else {
					System.out.println("Please, enter correct login credentials!!!");
				}
				break;

			default:
				System.out.println("Enter correct choice............");
			}
			break;

		case 2:
			System.out.println("user");
			System.out.println("Press R to register ad admin");
			System.out.println("Press L to login if you are already registerd");
			System.out.println("Enter your choice.....");
			String choice2 = sc.nextLine();

			switch (choice2) {

			case "R":
				dao.registerUser();

			case "L":
				System.out.println("Login Here!!!!!");
				System.out.println("Enter your email Id");
				String email = sc.nextLine();
				System.out.println("Enter your password");
				String password = sc.nextLine();
				int userId = dao.loginUser(email, password);
				System.out.println(userId);
				if (userId > 0) {
					System.out.println("Press A to see all products");
					System.out.println("Press B to add to cart");
					System.out.println("Press C to delete from cart");
					System.out.println("Press D to payment");
					System.out.println("Press E to update your profile ");
					System.out.println("Press F to see inbox");
					System.out.println("Press G to send message to admin");
					System.out.println("Enter correct choice...........");
					String choice3 = sc.nextLine();

					switch (choice3) {

					case "A":
						dao.seeAllProducts();

					case "B":
						System.out.println("If you want to add the product into cart press Y");
						String choice5 = sc.nextLine();
						if (choice5.equals("Y")) {
							dao.addToCart(userId);
						}

					case "C":
						System.out.println("If you want to delete product/medicine from cart press Y");
						String choice6 = sc.nextLine();
						if (choice6.equals("Y")) {
							dao.deleteFromCart(userId);
						}

					case "D":
						System.out.println("If you want to buy all selected product ,to see bill press Y");
						String choice7 = sc.nextLine();
						if (choice7.equals("Y")) {
							dao.payment(userId);
						}

					case "E":
						System.out.println("If you want to update your profile press Y");
						String choice4 = sc.nextLine();
						if (choice4.equals("Y")) {
							dao.updateProfile(userId);
							System.out.println("Your profile updated successfully....");
						}

					case "F":
						System.out.println("If you want to see your inbox press Y");
						String choice8 = sc.nextLine();
						if (choice8.equals("Y")) {
							dao.seeAllSentMessages(userId);
						}

					case "G":
						System.out.println("If you want to send  any message regarding order to admin press Y ");
						String choice9 = sc.nextLine();
						if (choice9.equals("Y")) {
							dao.sendMessageToAdmin(userId);
							System.out.println("message sent");
						}

						break;

					default:
						System.out.println("Enter correct choice");
					}
				} else {
					System.out.println("Enter correct Login credentials");
				}
			}

			break;
		default:
			System.out.println("Enter correct choice............");
		}
		sc.close();
	}

}
