package com.cg.jpawithhibernate.controller;

import java.util.Scanner;

import com.cg.jpawithhibernate.dao.UserDAO;
import com.cg.jpawithhibernate.factory.MedicalFactory;

public class UserMain {

	public static void userContent(int userId) {

		System.out.println("***************************8");
		Scanner sc = new Scanner(System.in);
		UserDAO dao1 = MedicalFactory.getUserInstance();

		while (true) {
			System.out.println("###########");

			System.out.println("Press 1 to see all medicines/products");
			System.out.println("Press 2 to see all cart items");
			System.out.println("Press 3 to add the medicines/products into cart");
			System.out.println("Press 4 to delete the medicine/product from cart");
			System.out.println("Press 5 to update your profile");
			System.out.println("Press 6 to see all messages");
			System.out.println("Press 7 to send message to admin");
			System.out.println("Press 8 to exit");
			System.out.println("Enter correct choice.....");
			String choice = sc.nextLine();

			switch (choice) {

			case "1":
				dao1.seeAllProducts();
				break;

			case "2":
				dao1.dispayCart(userId);
				break;

			case "3":
				dao1.addToCart(userId);
				break;

			case "4":
				dao1.deleteFromCart(userId);
				break;

			case "5":
				dao1.updateProfile(userId);
				break;

			case "6":
				dao1.seeAllSentMessages(userId);
				break;

			case "7":
				dao1.sendMessageToAdmin(userId);
				break;

			case "8":
				sc.close();
				System.exit(0);
				break;

			default:
				System.err.println("Enter number between 1 to 8 only");

			}

		}
	}

}
