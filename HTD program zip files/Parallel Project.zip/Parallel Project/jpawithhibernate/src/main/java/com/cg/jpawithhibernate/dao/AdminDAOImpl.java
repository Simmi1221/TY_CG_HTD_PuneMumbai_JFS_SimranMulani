package com.cg.jpawithhibernate.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.jpawithhibernate.dto.Admin;
import com.cg.jpawithhibernate.dto.Product;
import com.cg.jpawithhibernate.dto.User;
import com.cg.jpawithhibernate.dto.UserMsgBox;
import com.cg.jpawithhibernate.factory.MedicalFactory;
import com.cg.jpawithhibernate.validation.CustomValidation;

public class AdminDAOImpl implements AdminDAO {

	Scanner sc = new Scanner(System.in);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenceUnit");;
	EntityManager em = null;
	EntityTransaction tran = null;
	CustomValidation val2 = MedicalFactory.getCustomValidation();

	public void registerAdmin(String username, String email, String mobileNum, String password) {

		Admin admin = new Admin();

		admin.setUsername(username);
		admin.setEmail(email);
		admin.setMobile(mobileNum);
		admin.setPassword(password);

		em = emf.createEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(admin);
		tran.commit();
		System.out.println("Registered successfully...");
		em.close();

	}

	@Override
	public int loginAdmin(String email, String password) {

		em = emf.createEntityManager();
		String jpql = "select a from Admin a where email=:email and password=:password";
		Query query = em.createQuery(jpql);
		query.setParameter("email", email);
		query.setParameter("password", password);

		List<Admin> list = query.getResultList();

		for (Admin li : list) {
			int adminId = li.getAdminId();
			System.out.println("******************************");
			System.out.println("Welcome " + li.getUsername());
			System.out.println("******************************");
			return adminId;
		}
		return 0;
	}

	@Override
	public void addMedicines() {

		Product product = new Product();
		while (true) {
			em = emf.createEntityManager();
			tran = em.getTransaction();
			System.out.println("Enter medicine name");
			String productName = sc.nextLine();
			if (!val2.checkProductName(productName)) {
				System.out.println("Enter medicine Category");
				String category = sc.nextLine();
				try {
					System.out.println("Enter price ");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("Enter quantity");
					int quantity = Integer.parseInt(sc.nextLine());
					product.setProductName(productName);
					product.setCategory(category);
					product.setPrice(price);
					product.setQuantity(quantity);

					tran.begin();
					em.persist(product);
					System.out.println("Product added successfully");
					tran.commit();
					em.close();
					break;
				} catch (NumberFormatException e) {
					System.err.println("Enter number only!!!");
				}

			} else {
				System.err.println("Entered product name is already exist!!!");
			}
		}

	}

	@Override
	public void updateMedicines() {

		em = emf.createEntityManager();
		tran = em.getTransaction();
		while (true) {
			try {
				System.out.println("Enter medicine id which you want to update");
				int productId = Integer.parseInt(sc.nextLine());
				if (val2.checkProductId(productId)) {
					System.out.println("Enter medicine name to upadate");
					String productName = sc.nextLine();

					System.out.println("Enter price to update");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("Enter quantity to upadte");
					int quantity = Integer.parseInt(sc.nextLine());
					String jpql = "update Product set productName=:name,price=:pr,quantity=:quant where productId=:pid";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("name", productName);
					query.setParameter("pr", price);
					query.setParameter("quant", quantity);
					query.setParameter("pid", productId);

					Integer res = query.executeUpdate();
					tran.commit();
					em.close();
					break;
				} else {
					System.err.println("Entered product id does not exist!!!");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter number only!!!");
			}

		}
	}

	@Override
	public void deleteMedicine() {

		while (true) {
			try {
				System.out.println("Enter product id which you want to delete");
				int productId = Integer.parseInt(sc.nextLine());
				if (val2.checkProductId(productId)) {
					em = emf.createEntityManager();
					tran = em.getTransaction();
					String jpql = "delete from Product where productId=:pid";
					tran.begin();
					Query query = em.createQuery(jpql);
					query.setParameter("pid", productId);
					query.executeUpdate();
					System.out.println("Deleted medicine/product successfully");
					tran.commit();
					em.close();
					break;
				} else {
					System.err.println("Entered product id does not exist!!!");
				}
			} catch (NumberFormatException e) {

				System.err.println("Entere number only!!!");
			}

		}

	}

	@Override
	public void seeAllUsers() {

		em = emf.createEntityManager();
		String jpql = "from User";
		Query query = em.createQuery(jpql);

		List<User> list = query.getResultList();
		for (User li : list) {
			System.out.println("User Id      :" + li.getUserId());
			System.out.println("User name    :" + li.getUsername());
			System.out.println("Email id     :" + li.getEmail());
			System.out.println("Mobile Number:" + li.getMobileNum());
			System.out.println("--------------------------------------");
		}
		em.close();
	}

	@Override
	public void deleteUser() {

		while (true) {
			try {
				System.out.println("Enter userId which you want to delete");
				int userId = Integer.parseInt(sc.nextLine());
				if (val2.checkUserId(userId)) {

					em = emf.createEntityManager();
					tran = em.getTransaction();

					tran.begin();
					User user = em.find(User.class, userId);
					em.remove(user);
					System.out.println("User deleted successfully");
					System.out.println("--------------------------------------------");
					tran.commit();
					em.close();
					break;

				} else {
					System.err.println("Entered user id does not exist!!!");
				}
			} catch (NumberFormatException e) {

				System.err.println("Enter number only!!!");
			}

		}
	}

	@Override
	public void ReplyToUser(int adminId) {

		while (true) {
			try {

				System.out.println("Enter user Id ");
				int userId = Integer.parseInt(sc.nextLine());
				if (val2.checkUserId(userId)) {
					System.out.println("Enter your name");
					String adminName = sc.nextLine();
					System.out.println("Enter your issue/message");
					String message = sc.nextLine();

					UserMsgBox msgBox = new UserMsgBox();
					msgBox.setAdminId(adminId);
					msgBox.setAdminName(adminName);
					msgBox.setInbox(message);
					msgBox.setUserId(userId);

					em = emf.createEntityManager();
					tran = em.getTransaction();
					tran.begin();
					em.persist(msgBox);
					tran.commit();
					System.out.println("Message sent..........");
					em.close();
					break;
				} else {
					System.err.println("Entered userId does not not exist");
				}
			} catch (NumberFormatException e) {

				System.err.println("Enter only number!!!");
			}
			
		}
	}

	@Override
	public void seeAllSentMessage(int adminId) {
		em = emf.createEntityManager();

		String jpql = "from UserMsgBox  where adminId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", adminId);

		List<UserMsgBox> list = query.getResultList();
		for (UserMsgBox li : list) {
			System.out.println("Message id :" + li.getMsgId());
			System.out.println("Admin name:" + li.getAdminName());
			System.out.println("Message     :" + li.getInbox());
			System.out.println("---------------------------");
		}
		em.close();
	}

}
