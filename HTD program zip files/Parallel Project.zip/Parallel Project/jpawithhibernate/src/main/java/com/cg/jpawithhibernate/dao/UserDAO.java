package com.cg.jpawithhibernate.dao;

public interface UserDAO {
	
	public void registerUser(String username,String  email,String mobileNum, String password);

	public int loginUser(String email, String password);

	public void seeAllProducts();

	public void updateProfile(int userId);
	
	public void dispayCart(int userId);

	public void addToCart(int userId);

	public void deleteFromCart(int userId);

	public void payment(int userId);

	public void sendMessageToAdmin(int userId);

	public void seeAllSentMessages(int userId);


}
