package com.cg.jpawithhibernate.validation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.jpawithhibernate.dto.Admin;
import com.cg.jpawithhibernate.dto.Cart;
import com.cg.jpawithhibernate.dto.Product;
import com.cg.jpawithhibernate.dto.User;

public class CustomValidationImpl implements CustomValidation {

	Scanner sc = new Scanner(System.in);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenceUnit");;
	EntityManager em = null;
	EntityTransaction tran = null;

	@Override
	public boolean emailValidationForAdmin(String email) {

		em = emf.createEntityManager();
		String jpql = " from Admin";
		Query query = em.createQuery(jpql);
		List<Admin> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Admin li : list) {
				if (email.equalsIgnoreCase(li.getEmail())) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

	@Override
	public boolean emailValidationForUser(String email) {

		em = emf.createEntityManager();
		String jpql = " from User";
		Query query = em.createQuery(jpql);
		List<User> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (User li : list) {
				if (email.equalsIgnoreCase(li.getEmail())) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;

	}

	@Override
	public boolean checkProductName(String productName) {

		em = emf.createEntityManager();
		String jpql = " from Product";
		Query query = em.createQuery(jpql);
		List<Product> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Product li : list) {
				if (productName.equalsIgnoreCase(li.getProductName())) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

	@Override
	public boolean checkProductNameForCart(String productName, int userId) {

		em = emf.createEntityManager();
		String jpql = " from Cart";
		Query query = em.createQuery(jpql);
		List<Cart> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Cart li : list) {
				if (productName.equalsIgnoreCase(li.getProductName()) && userId == li.getUserId()) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

	@Override
	public boolean checkProductId(int productId) {

		em = emf.createEntityManager();
		String jpql = " from Product";
		Query query = em.createQuery(jpql);
		List<Product> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Product li : list) {
				if (productId == li.getProductId()) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;

	}

	@Override
	public boolean checkUserId(int userId) {

		em = emf.createEntityManager();
		String jpql = " from User";
		Query query = em.createQuery(jpql);
		List<User> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (User li : list) {
				if (userId == li.getUserId()) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

	@Override
	public boolean checkCartId(int cartId, int userId) {
		em = emf.createEntityManager();
		String jpql = " from Cart where userId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", userId);
		List<Cart> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Cart li : list) {
				if (cartId == li.getCartId()) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

	@Override
	public boolean quantityValidation(int quantity, String productName) {

		em = emf.createEntityManager();
		String jpql = " from Product where productName=:name";
		Query query = em.createQuery(jpql);
		query.setParameter("name", productName);
		List<Product> list = null;
		boolean valid = false;
		try {
			list = query.getResultList();
			for (Product li : list) {
				if (quantity <= li.getQuantity()) {
					valid = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return valid;
	}

}
