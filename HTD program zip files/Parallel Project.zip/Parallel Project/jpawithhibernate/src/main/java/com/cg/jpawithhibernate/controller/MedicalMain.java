package com.cg.jpawithhibernate.controller;

import java.util.Scanner;

import com.cg.jpawithhibernate.dao.AdminDAO;
import com.cg.jpawithhibernate.dao.UserDAO;
import com.cg.jpawithhibernate.dto.User;
import com.cg.jpawithhibernate.factory.MedicalFactory;
import com.cg.jpawithhibernate.validation.AdminUserValidation;
import com.cg.jpawithhibernate.validation.CustomValidation;

public class MedicalMain {

	public static void main(String[] args) {

		AdminDAO dao = MedicalFactory.getAdminInstance();
		UserDAO dao1 = MedicalFactory.getUserInstance();
		AdminUserValidation val = MedicalFactory.getValidation();
		CustomValidation val2 = MedicalFactory.getCustomValidation();
		Scanner sc = new Scanner(System.in);

		System.out.println("********Welcome to medical Store********");
		while (true) {

			System.out.println("Press 0 for visitor");
			System.out.println("Press 1 to login as admin");
			System.out.println("Press 2 to login as user");
			System.out.println("Press 3 to exit");
			System.out.println("Enter your choice.........");
			String choice = sc.nextLine();
			switch (choice) {

			case "0":
				dao1.seeAllProducts();
				break;

			case "1":
				System.out.println("Press R to registration");
				System.out.println("Press L to login if you are already registered");
				System.out.println("enter your choice.............");
				String choice1 = sc.nextLine();
				switch (choice1) {

				case "R":
					User user = new User();

					while (true) {
						System.out.println("Enter your full name");
						String username = sc.nextLine();
						if (val.usernameValidation(username)) {
							user.setUsername(username);
							System.out.println("Enter you email id");
							String email = sc.nextLine();
							if (val.emailValidation(email)) {
								boolean isValid = val2.emailValidationForAdmin(email);
								if (!isValid) {
									user.setEmail(email);
									System.out.println("Enter mobile number");
									String mobileNum = sc.nextLine();
									if (val.mobileNumValidation(mobileNum)) {
										user.setMobileNum(mobileNum);
										System.out.println("Create password");
										String password = sc.nextLine();
										if (val.passwordvalidation(password)) {
											user.setPassword(password);
											dao.registerAdmin(username, email, mobileNum, password);
											break;
										} else {
											System.err.println("Enter atleast 8 character or atmost 15 character!!!");
										}

									} else {
										System.err.println("Enter valid mobile number!!!");
									}

								} else {
									System.err.println("Email Id already exist!!!");
								}

							} else {
								System.err.println("Enter valid email id:It should like abc@xyz.com!!!");
							}
						} else {
							System.err.println("Enter your full name!!!");
						}
					}

				case "L":
					System.out.println("Login Here!!!");
					System.out.println("Enter email id");
					String email2 = sc.nextLine();
					boolean isValid = val2.emailValidationForAdmin(email2);
					if (isValid) {
						System.out.println("Enter password");
						String password2 = sc.nextLine();
						int adminId = dao.loginAdmin(email2, password2);
						if (adminId > 0) {
							AdminMain.adminContent(adminId);
						} else {
							System.err.println("Please, enter correct password!!!");
						}

					} else {
						System.err.println("Entered email id does not exist!!!");
					}

				default:
					System.err.println("Please, enter letter R or L only");
					break;
				}

			case "2":
				System.out.println("Press R to registration");
				System.out.println("Press L to login if you are already registered");
				System.out.println("enter your choice.............");
				String choice2 = sc.nextLine();
				switch (choice2) {

				case "R":
					User user = new User();
					while (true) {
						System.out.println("Enter your full name");
						String username1 = sc.nextLine();
						if (val.usernameValidation(username1)) {
							user.setUsername(username1);
							System.out.println("Enter you email id");
							String email1 = sc.nextLine();
							if (val.emailValidation(email1)) {
								if (val.emailValidation(email1)) {
									boolean isValid = val2.emailValidationForUser(email1);
									if (!isValid) {
										user.setEmail(email1);
										System.out.println("Enter mobile number");
										String mobileNum1 = sc.nextLine();
										if (val.mobileNumValidation(mobileNum1)) {
											user.setMobileNum(mobileNum1);
											System.out.println("Create password");
											String password1 = sc.nextLine();
											if (val.passwordvalidation(password1)) {
												user.setPassword(password1);
												dao1.registerUser(username1, email1, mobileNum1, password1);
												break;

											} else {
												System.err
														.println("Enter atleast 8 character or atmost 15 character!!!");
											}

										} else {
											System.err.println("Enter valid mobile number!!!");
										}

									} else {
										System.err.println("Email Id already exist!!!");
									}

								} else {
									System.err.println("Enter valid email id:It should like abc@xyz.com!!!");
								}

							} else {
								System.err.println("Enter your full name!!!");
							}

						}
					}

				case "L":
					System.out.println("Login Here!!!");
					System.out.println("Enter email id");
					String email2 = sc.nextLine();
					boolean isValid = val2.emailValidationForUser(email2);
					if (isValid) {
						System.out.println("Enter password");
						String password2 = sc.nextLine();
						int userId = dao1.loginUser(email2, password2);
						System.out.println(userId);
						if (userId > 0) {
							System.out.println("--------------");
							UserMain.userContent(userId);
						} else {
							System.err.println("Please, enter correct password!!!");
						}

					} else {
						System.err.println("Entered email id does not exist!!!Please register first!!!");
					}
					break;

				default:
					System.err.println("Please, enter letter R or L only");
				}

				break;

			case "3":
				sc.close();
				System.exit(0);

			default:
				System.err.println("Enter number between 0 to 3");

			}
		}

	}
}
