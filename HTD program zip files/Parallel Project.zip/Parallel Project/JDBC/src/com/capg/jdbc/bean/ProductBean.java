package com.capg.jdbc.bean;


public class ProductBean {
	
	private int medId;
	private String medName;
	private String medCategory;
	private double medPrice;
	private int quantity;
	public int getMedId() {
		return medId;
	}
	public void setMedId(int medId) {
		this.medId = medId;
	}
	public String getMedName() {
		return medName;
	}
	public void setMedName(String medName) {
		this.medName = medName;
	}
	public String getMedCategory() {
		return medCategory;
	}
	public void setMedCategory(String medCategory) {
		this.medCategory = medCategory;
	}
	public double getMedPrice() {
		return medPrice;
	}
	public void setMedPrice(double medPrice) {
		this.medPrice = medPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	

	
}
