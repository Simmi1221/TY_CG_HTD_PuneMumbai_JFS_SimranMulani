package com.capg.jdbc.validation;

public interface CustomValidation {
	
	public boolean emailValidationForAdmin(String email); 
	public boolean emailValidationForUser(String email);
	public boolean checkProductName(String productName);
	public boolean checkProductId(int productId);
	public boolean checkUserId(int userId);
	
	public boolean quantityValidation(int quantity, String productName);
	public boolean checkCartId(int cartId,int userId);

}
