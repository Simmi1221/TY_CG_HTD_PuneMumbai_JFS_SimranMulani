package com.capg.jdbc.controller;

import java.util.Scanner;

import com.capg.jdbc.bean.UserBean;
import com.capg.jdbc.dao.AdminDAO;
import com.capg.jdbc.dao.UserDAO;
import com.capg.jdbc.factory.MedicalFactory;
import com.capg.jdbc.validation.AdminUserValidation;

public class MedicalMain {

	public static void main(String[] args) {

		while (true) {
			AdminDAO dao = MedicalFactory.getAdminInstance();
			UserDAO dao1 = MedicalFactory.getUserInstance();
			AdminUserValidation val = MedicalFactory.getValidation();
			Scanner sc = new Scanner(System.in);

			System.out.println("********Welcome to medical Store********");
			System.out.println("Press 0 for visitor");
			System.out.println("Press 1 to login as admin");
			System.out.println("Press 2 to login as user");
			System.out.println("Enter your choice.........");
			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {

			case 0:
				
				break;

			case 1:
				System.out.println("Login Here!!!");
				System.out.println("Enter email id");
				String email = sc.nextLine();
				System.out.println("Enter password");
				String password = sc.nextLine();
				int adminId = dao.loginAsAdmin(email, password);
				if (adminId > 0) {
					AdminMain.adminContent(adminId);
				} else {
					System.out.println("Please, enter correct login credentials...");
				}
				break;

			case 2:
				System.out.println("Press R to registration");
			    System.out.println("Press L to login if you are already registered");  
			    System.out.println("enter your choice.............");
			    String choice1=sc.nextLine();
			    switch(choice1) {
			    
			    case "R":
			    	UserBean user = new UserBean();

					System.out.println("Create username");
					String username1 = sc.nextLine();
					if (val.usernameValidation(username1)) {
						user.setUsername(username1);
					} else {
						System.out.println("enter valid username");
						System.exit(0);
					}
					System.out.println("Enter you email id");
					String email1 = sc.nextLine();
					if (val.emailValidation(email1)) {
						user.setEmail(email1);
					} else {
						System.out.println("enter valid email id");
						System.exit(0);
					}
					System.out.println("Enter mobile number");
					String mobileNum = sc.nextLine();
					if (val.mobileNumValidation(mobileNum)) {
						user.setMobileNum(mobileNum);
					} else {
						System.out.println("enter valid mobile number");
						System.exit(0);
					}
					System.out.println("Create password");
					String password1 = sc.nextLine();
					if (val.passwordvalidation(password1)) {
						user.setPassword(password1);
					} else {
						System.out.println("enter valid password");
					}
			    	dao1.registerUser(username1, email1, mobileNum, password1);
			    	
			    case "L":
			    	System.out.println("Login Here!!!");
					int userId = dao1.loginAsUser();
					if (userId > 0) {
						UserMain.userContent(userId);
					} else {
						System.out.println("Please, enter correct login credentials...");
					}
					break;
					
				default:
					System.out.println("Enter correct choice");
			    }
				
				break;

			default:
				System.out.println("Enter correct choice..........");

			}
			sc.close();
		}
	}
}
