package com.capg.jdbc.dao;

public interface AdminDAO  {
	
	
	
	public int loginAsAdmin(String email,String password);
	public void addMedicine();
	public void updateMedicine();
	public void deleteMedicine();
	public void seeAllUser();
	public void deleteUser();
	
    public void ReplyToUser(int adminId);
    public void seeAllSentMessage(int adminId);

}
