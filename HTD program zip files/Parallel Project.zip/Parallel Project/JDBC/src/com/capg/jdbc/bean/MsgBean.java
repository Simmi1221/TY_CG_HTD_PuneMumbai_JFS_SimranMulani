package com.capg.jdbc.bean;

public class MsgBean {
	
	private int msgId;
	private String inbox;
	
	public int getMsgId() {
		return msgId;
	}
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	public String getInbox() {
		return inbox;
	}
	public void setInbox(String inbox) {
		this.inbox = inbox;
	}
	
	

}
