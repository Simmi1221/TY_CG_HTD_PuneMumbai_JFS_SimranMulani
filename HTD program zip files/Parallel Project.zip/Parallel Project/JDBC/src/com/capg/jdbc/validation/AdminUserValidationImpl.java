package com.capg.jdbc.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminUserValidationImpl implements AdminUserValidation{

	Pattern pat=null;
	Matcher mat=null;
	
	@Override
	public boolean mobileNumValidation(String mobileNum) {
		pat=Pattern.compile("\\d{10}");
		mat=pat.matcher(mobileNum);
		if(mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean emailValidation(String email) {
		pat=Pattern.compile("\\w+\\@\\w+\\.\\w+");
		mat=pat.matcher(email);
		if(mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean passwordvalidation(String password) {
		pat=Pattern.compile("\\w{8,15}");
		mat=pat.matcher(password);
		if(mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean usernameValidation(String username) {
		pat=Pattern.compile("\\w+\\s\\w+\\s\\w+");
		mat=pat.matcher(username);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	
	

}
