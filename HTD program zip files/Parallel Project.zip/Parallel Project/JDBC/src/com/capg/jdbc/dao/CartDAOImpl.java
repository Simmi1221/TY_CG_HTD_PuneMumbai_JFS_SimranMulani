package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capg.jdbc.factory.MedicalFactory;
import com.capg.jdbc.validation.CustomValidation;

public class CartDAOImpl implements CartDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);
	CustomValidation dao3 = null;

	public CartDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void addToCart(int userId) {

		dao3 = MedicalFactory.getCustomValidation();

		while (true) {

			System.out.println("enter medicine/product name to add into cart");
			String productName = sc.nextLine();

			if (dao3.checkProductName(productName)) {

				String query = "select * from product_info where productName=?";
				try (Connection conn = DriverManager.getConnection(dbUrl);
						PreparedStatement pstmt = conn.prepareStatement(query)) {
					pstmt.setString(1, productName);
					try (ResultSet res = pstmt.executeQuery()) {
						if (res.next()) {
							int productId = res.getInt(1);
							String productName1 = res.getString(2);
							double price = res.getDouble(4);

							boolean check = false;
							do {

								try {
									System.out.println("enter quantity of medicine/product");
									int quantity = Integer.parseInt(sc.nextLine());

									if (dao3.quantityValidation(quantity, productName1)) {

										String query1 = "insert into cart_info (productId,productName,price,quantity,userId) values (?,?,?,?,?)";
										try (Connection conn1 = DriverManager.getConnection(dbUrl);
												PreparedStatement pstmt1 = conn.prepareStatement(query1)) {
											pstmt1.setInt(1, productId);
											pstmt1.setString(2, productName1);
											pstmt1.setDouble(3, price);
											pstmt1.setInt(4, quantity);
											pstmt1.setInt(5, userId);

											Integer res1 = pstmt1.executeUpdate();
											if (res1 > 0) {
												System.out.println("Selected product is  added into cart");
												check = true;
												break;
											}
										} catch (Exception e) {
											e.printStackTrace();
										}
									} else {
										System.err.println("Product is out of stock");
									}

								} catch (NumberFormatException e) {
									System.err.println("Enter only number for quantity!!!");
								}

							} while (!check);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			else {
				System.err.println("Entered product is not present!!!");
			}
		}

	}

	@Override
	public void displayAllSelectedItemFromCart(int userId) {
		String query = "select * from cart_info where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			try (ResultSet res = pstmt.executeQuery()) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getDouble(3));
					System.out.println("---------------------");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteItemFromCart(int userId) {

		dao3 = MedicalFactory.getCustomValidation();
		while (true) {
			try {
				System.out.println("enter cart id which you want to delete");
				int cartId = Integer.parseInt(sc.nextLine());

				if (dao3.checkCartId(cartId, userId)) {

					String query = "delete from cart_info where cartId=? and userId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setInt(1, cartId);
						pstmt.setInt(2, userId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Selected item deleted from cart");
							break;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

				} else {
					System.err.println("Entered cart id is not present into your cart!!!");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter only number for cart id!!!");
			}

		}

	}

	@Override
	public double payment(int userId) {
		String query = "select SUM(price*quantity) from cart_info where userId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);

			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				double bill = res.getDouble(1);
				System.out.println("Bill of your products/medicines is " + bill);
				return bill;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
