package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capg.jdbc.factory.MedicalFactory;

public class CartDAOImpl implements CartDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);

	public CartDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded......");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void getIdForAddToCart(int userId) {
		System.out.println("Enter how many medicine/product you want");
		int count = Integer.parseInt(sc.nextLine());
		CartDAO dao = MedicalFactory.getCartInstance();
		for (int i = 1; i <= count; i++) {
			System.out.println("enter medicine/product name to add into cart");
			String medName = sc.nextLine();
			String query = "select * from product_info where medname=?";
			try (Connection conn = DriverManager.getConnection(dbUrl);
					PreparedStatement pstmt = conn.prepareStatement(query)) {
				pstmt.setString(1, medName);
				try (ResultSet res = pstmt.executeQuery()) {
					if (res.next()) {
						int medId = res.getInt(1);
						String selectedMedName = res.getString(2);
						double price = res.getDouble(4);
						dao.addToCart(medId, selectedMedName, price, userId);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void addToCart(int medId, String selectedMedName, double price, int userId) {
		System.out.println("enter quantity of medicine/product");
		int quantity = Integer.parseInt(sc.nextLine());
		String query = "insert into cart_info (medId,selectedMedName,price,quantity,userId) values (?,?,?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, medId);
			pstmt.setString(2, selectedMedName);
			pstmt.setDouble(3, price);
			pstmt.setInt(4, quantity);
			pstmt.setInt(5, userId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("Item added into cart");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void displayAllSelectedItemFromCart(int userId) {
		String query = "select * from cart_info where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			try (ResultSet res = pstmt.executeQuery()) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getDouble(3));
					System.out.println("---------------------");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteItemFromCart() {
		System.out.println("Enter how many item you want to delete");
		int count = Integer.parseInt(sc.nextLine());

		for (int i = 1; i <= count; i++) {

			System.out.println("enter cart id which you want to delete");
			int cartId = Integer.parseInt(sc.nextLine());

			String query = "delete from cart_info where cartId=?";
			try (Connection conn = DriverManager.getConnection(dbUrl);
					PreparedStatement pstmt = conn.prepareStatement(query)) {
				pstmt.setInt(1, cartId);
				Integer res = pstmt.executeUpdate();
				if (res > 0) {
					System.out.println("Selected item deleted from cart");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public double payment(int userId) {
		String query = "select SUM(price*quantity) from cart_info where userId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);

			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				double bill = res.getDouble(1);
				System.out.println("Bill of your products/medicines is " + bill);
				return bill;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
