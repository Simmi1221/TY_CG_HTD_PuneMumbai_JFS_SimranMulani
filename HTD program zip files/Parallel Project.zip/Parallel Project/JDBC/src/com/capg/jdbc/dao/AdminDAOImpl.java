package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdminDAOImpl implements AdminDAO{
	
	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);

	public AdminDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded......");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int loginAsAdmin(String email, String password) {
		String query = "select adminId from admin_info where email=? and password=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				int adminId=res.getInt(1);
				return adminId;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void addMedicine() {
		System.out.println("Enter medicine name");
		String medName = sc.nextLine();
		System.out.println("Enter category of medicine");
		String medCategory = sc.nextLine();
		System.out.println("Enter price of medicine");
		double medPrice = Double.parseDouble(sc.nextLine());
		System.out.println("Enter quantity present in store");
		int quantity = Integer.parseInt(sc.nextLine());
		
		String query = "insert into product_info(medName,medCategory,medPrice,quantity) values(?,?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, medName);
			pstmt.setString(2, medCategory);
			pstmt.setDouble(3, medPrice);
			pstmt.setInt(4, quantity);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("medicine detail inserted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateMedicine() {
		System.out.println("Enter id of medicine which you want to update");
		int medId = Integer.parseInt(sc.nextLine());
		System.out.println("Enter medicine name");
		String medName = sc.nextLine();
		System.out.println("Enter price of medicine");
		double medPrice = Double.parseDouble(sc.nextLine());
		System.out.println("Enter quantity ");
		int quantity = Integer.parseInt(sc.nextLine());
		
		String query = "update product_info set medName=?, medPrice=?, quantity=? where medId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, medName);
			pstmt.setDouble(2, medPrice);
			pstmt.setInt(3, quantity);
			pstmt.setInt(4, medId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("medicine item updated");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteMedicine() {
		System.out.println("Enter id of medicine which you want to delete");
		int medId = Integer.parseInt(sc.nextLine());
		
		String query = "delete from product_info where medId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, medId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("medicine item removed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteUser() {
		System.out.println("enter userid which you want to delete");
		int userId = Integer.parseInt(sc.nextLine());
		
		String query = "delete from users_info where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("user removed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ReplyToUser(int adminId) {
		System.out.println("Enter your name");
		String adminName=sc.nextLine();
		System.out.println("Enter your issue/message");
		String message=sc.nextLine();
		String query = "insert into user_msg (adminId,adminName,inbox) values(?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, adminId);
			pstmt.setString(2, adminName);
			pstmt.setString(3, message);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("message sent");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void seeAllSentMessage(int adminId) {

		String query = "select inbox from user_msg where adminId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, adminId);
			
			ResultSet res = pstmt.executeQuery();
			while (res.next()) {
			  System.out.println("Message Id :"+res.getInt(1));	
		      System.out.println("Message    :"+res.getString(2));
		      System.out.println("-------------------------");
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

}
