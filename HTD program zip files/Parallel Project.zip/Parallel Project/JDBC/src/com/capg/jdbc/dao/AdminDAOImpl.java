package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capg.jdbc.factory.MedicalFactory;
import com.capg.jdbc.validation.CustomValidation;

public class AdminDAOImpl implements AdminDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);
	AdminDAO dao = null;
	CustomValidation dao3 = MedicalFactory.getCustomValidation();

	public AdminDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int loginAsAdmin(String email, String password) {
		String query = "select adminId from admin_info where email=? and password=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				int adminId = res.getInt(1);
				return adminId;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void addMedicine() {

		dao = MedicalFactory.getAdminInstance();
		boolean value = false;

		System.out.println("Enter medicine/product name");
		String productName = sc.nextLine();

		if (!dao3.checkProductName(productName)) {

			System.out.println("Enter category of medicine");
			String category = sc.nextLine();

			do {
				double price = 0;
				try {
					System.out.println("Enter price of medicine");
					price = Double.parseDouble(sc.nextLine());

					System.out.println("Enter quantity present in store");
					int quantity = Integer.parseInt(sc.nextLine());

					String query = "insert into product_info(productName,category,price,quantity) values(?,?,?,?)";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setString(1, productName);
						pstmt.setString(2, category);
						pstmt.setDouble(3, price);
						pstmt.setInt(4, quantity);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Product detail inserted");
							System.out.println("------------------------------------------");
							value = true;
						}

					} catch (Exception e) {
						e.printStackTrace();
					}

				} catch (NumberFormatException e) {
					System.err.println("Enter only number !!!");
				}
			} while (!value);
		} else {
			System.err.println("Product name is already exist!!!");
		}

	}

	@Override
	public void updateMedicine() {

		dao = MedicalFactory.getAdminInstance();
		boolean check = false;

		boolean value = false;
		do {
			try {
				System.out.println("Enter id of medicine which you want to update");
				int productId = Integer.parseInt(sc.nextLine());
				if (dao3.checkProductId(productId)) {

					while (true) {
						System.out.println("Enter medicine name");
						String productName = sc.nextLine();
						do {
							System.out.println("Enter price of medicine");
							double price = Double.parseDouble(sc.nextLine());
							System.out.println("Enter quantity ");
							int quantity = Integer.parseInt(sc.nextLine());

							String query = "update product_info set productName=?, price=?, quantity=? where productId=?";
							try (Connection conn = DriverManager.getConnection(dbUrl);
									PreparedStatement pstmt = conn.prepareStatement(query)) {
								pstmt.setString(1, productName);
								pstmt.setDouble(2, price);
								pstmt.setInt(3, quantity);
								pstmt.setInt(4, productId);
								Integer res = pstmt.executeUpdate();
								if (res > 0) {
									System.out.println("Selected product updated");
									System.out.println("------------------------------------------");
									check = true;
									value = true;
								}
							} catch (Exception e) {
								e.printStackTrace();
							}

						} while (!check);
					}
				} else {
					System.err.println("Entered Product Id is not exist!!!");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter number only for id!!!");
			}

		} while (!value);

	}

	@Override
	public void deleteMedicine() {

		dao = MedicalFactory.getAdminInstance();
		boolean check = false;

		do {
			try {
				System.out.println("Enter id of medicine which you want to delete");
				int productId = Integer.parseInt(sc.nextLine());
				if (dao3.checkProductId(productId)) {

					String query = "delete from product_info where productId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setInt(1, productId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Selected product removed.....");
							System.out.println("------------------------------------------");
							check = true;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

				} else {
					System.err.println("Entered Product Id is not exist!!!");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter number only for id");
			}
		} while (!check);

	}

	@Override
	public void seeAllUser() {
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement stmt = conn.createStatement()) {
			String query = "select * from users_info";
			try (ResultSet res = stmt.executeQuery(query)) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getString(3));
					System.out.println("---------------------");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteUser() {

		dao = MedicalFactory.getAdminInstance();
		boolean check = false;

		do {
			try {
				System.out.println("enter userid which you want to delete");
				int userId = Integer.parseInt(sc.nextLine());
				if (dao3.checkUserId(userId)) {

					String query = "delete from users_info where userId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setInt(1, userId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Selected user removed");
							System.out.println("------------------------------------------");
							check = true;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					System.err.println("Entered user id is not exist!!!");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter number only for id");
			}

		} while (!check);

	}

	@Override
	public void ReplyToUser(int adminId) {

		dao3 = MedicalFactory.getCustomValidation();

		String query = "select username from admin_info where adminId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, adminId);
			try (ResultSet res = pstmt.executeQuery()) {
				while (res.next()) {
					String adminName = res.getString(1);

					while (true) {
						try {
							System.out.println("Enter user id ");
							int userId = Integer.parseInt(sc.nextLine());

							if (dao3.checkUserId(userId)) {

								System.out.println("Enter your issue/message");
								String message = sc.nextLine();
								String query1 = "insert into user_msg (adminId,adminName,inbox,userId) values(?,?,?,?)";
								try (Connection conn1 = DriverManager.getConnection(dbUrl);
										PreparedStatement pstmt1 = conn.prepareStatement(query1)) {
									pstmt1.setInt(1, adminId);
									pstmt1.setString(2, adminName);
									pstmt1.setString(3, message);
									pstmt1.setInt(4, userId);
									Integer res1 = pstmt1.executeUpdate();
									if (res1 > 0) {
										System.out.println("Message sent");
										System.out.println("------------------------------------------");
										break;
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							} else {
								System.err.println("Entered user id does not exist!!!");
							}
						} catch (NumberFormatException e) {
							System.err.println("Enter only number for user id");
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void seeAllSentMessage(int adminId) {

		String query = "select * from user_msg where adminId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, adminId);

			ResultSet res = pstmt.executeQuery();
			while (res.next()) {
				System.out.println("Message Id :" + res.getInt(1));
				System.out.println("Message    :" + res.getString(4));
				System.out.println("-------------------------");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
