package com.capg.jdbc.dao;

public interface UserDAO {
	
	
	public void registerUser(String username,String email,String mobileNum,String password);
	public int loginAsUser();
	public void getOurProfile(int userId);
	public void updateUserProfile(int userId);
	public void getAllMedicineInfo();
	public void sendMessageToAdmin(int userId);
    public void seeAllSentMessages(int userId);

}
