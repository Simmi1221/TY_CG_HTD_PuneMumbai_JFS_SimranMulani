package com.capg.jdbc.controller;

import java.util.Scanner;

import com.capg.jdbc.dao.AdminDAO;
import com.capg.jdbc.dao.CartDAO;
import com.capg.jdbc.dao.UserDAO;
import com.capg.jdbc.factory.MedicalFactory;

public class UserMain {

	public static void userContent(int userId) {

		Scanner sc = new Scanner(System.in);
		while (true) {

			AdminDAO dao = MedicalFactory.getAdminInstance();
			UserDAO dao1 = MedicalFactory.getUserInstance();
			CartDAO dao2 = MedicalFactory.getCartInstance();

			System.out.println("Press 1 to see all medicines/products");
			System.out.println("Press 2 to see all cart items");
			System.out.println("Press 3 to add the medicines/products into cart");
			System.out.println("Press 4 to delete the medicine/product from cart");
			System.out.println("Press 5 to buy order");
			System.out.println("Press 6 to see order list");
			System.out.println("Press 7 to payment ");
			System.out.println("Press 8 to update your profile");
			System.out.println("Press 9 to see all messages");
			System.out.println("Press 10 to send message to admin");
			System.out.println("Press 11 to exit");
			System.out.println("Enter correct choice.....");
			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {

			case 1:
				dao1.getAllMedicineInfo();
				break;

			case 2:
				dao2.displayAllSelectedItemFromCart(userId);
				break;

			case 3:
				dao2.getIdForAddToCart(userId);
				break;

			case 4:
				dao2.deleteItemFromCart();
				break;

			case 5:
				//dao2.buyOrder(userId);
				break;

			case 6:
				//double totalBill = dao2.orderList(userId);
				//System.out.println(totalBill);
				break;

			case 7:
				//dao2.payment(userId, totalBill);
				break;

			case 8:
				dao1.updateUserProfile(userId);
				break;

			case 9:
                dao1.seeAllSentMessages(userId);
				break;

			case 10:
				dao1.sendMessageToAdmin(userId);
				break;

			case 11:
				System.exit(0);

			default:
				System.out.println("Enter correct choice......");

			}

		}
	}

}
