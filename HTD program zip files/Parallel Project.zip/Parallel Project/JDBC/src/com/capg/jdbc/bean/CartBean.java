package com.capg.jdbc.bean;

import lombok.Data;

@Data
public class CartBean {
	
	private int cartId;
	private String selectedMedName;
	private double price;
	private int quantity;

}
