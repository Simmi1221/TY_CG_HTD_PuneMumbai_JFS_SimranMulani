package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capg.jdbc.factory.MedicalFactory;
import com.capg.jdbc.validation.AdminUserValidation;
import com.capg.jdbc.validation.CustomValidation;

public class UserDAOImpl implements UserDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);
	CustomValidation dao3 = null;

	public UserDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void registerUser(String username, String email, String mobileNum, String password) {
		String query = "insert into users_info (username,email,mobileNum,password) values (?,?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setString(2, email);
			pstmt.setString(3, mobileNum);
			pstmt.setString(4, password);
			Integer res = pstmt.executeUpdate();
			while (res > 0) {
				System.out.println("User Account created");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int loginAsUser() {

		dao3 = MedicalFactory.getCustomValidation();

		System.out.println("enter your email");
		String email = sc.nextLine();
		int userId = 0;
		if (dao3.emailValidationForUser(email)) {

			System.out.println("enter your password");
			String password = sc.nextLine();
			String query = "select userId from users_info where email=? and password=?";
			try (Connection conn = DriverManager.getConnection(dbUrl);
					PreparedStatement pstmt = conn.prepareStatement(query)) {
				pstmt.setString(1, email);
				pstmt.setString(2, password);
				ResultSet res = pstmt.executeQuery();
				if (res.next()) {
					userId = res.getInt(1);
					return userId;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} else {
			System.err.println("Your email id is not exist...Please register first");

		}
		return userId;
	}

	@Override
	public void getOurProfile(int userId) {
		String query = "select * from users_info where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getString(3));
					System.out.println(res.getString(4));
					System.out.println(res.getString(5));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateUserProfile(int userId) {

		AdminUserValidation val = MedicalFactory.getValidation();
		dao3 = MedicalFactory.getCustomValidation();

		System.out.println("Enter 1 to update the username");
		System.out.println("Enter 2 to update the email");
		System.out.println("Enter 3 to update the mobile number");
		System.out.println("Enter 4 to update the password");
		System.out.println("enter your choice................");
		String choice = sc.nextLine();
		switch (choice) {

		case "1":
			while (true) {
				System.out.println("Enter username to update");
				String username = sc.nextLine();
				if (val.usernameValidation(username)) {
					String query = "update users_info set username=? where userId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setString(1, username);
						pstmt.setInt(2, userId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Your profile is updated");
							break;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					System.err.println("Enter your full name!!!");
				}
			}

			break;

		case "2":
			while (true) {
				System.out.println("Enter email to update");
				String email = sc.nextLine();
				if (val.emailValidation(email)) {
					boolean isValid = dao3.emailValidationForUser(email);
					System.out.println(isValid);
					if (!isValid) {
						String query = "update users_info set email=? where userId=?";
						try (Connection conn = DriverManager.getConnection(dbUrl);
								PreparedStatement pstmt = conn.prepareStatement(query)) {
							pstmt.setString(1, email);
							pstmt.setInt(2, userId);
							Integer res = pstmt.executeUpdate();
							if (res > 0) {
								System.out.println("Your profile is updated");
								break;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						System.err.println("Entered email is already exist!!!");
					}
				} else {
					System.err.println("Enter valid email id!!!");
				}
			}

			break;

		case "3":
			while (true) {
				System.out.println("Enter mobile number to update");
				String mobileNum = sc.nextLine();
				if (val.mobileNumValidation(mobileNum)) {
					String query = "update users_info set mobileNum=? where userId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setString(1, mobileNum);
						pstmt.setInt(2, userId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Your profile is updated");
							break;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					System.err.println("Enter valid 10 digit mobile number !!!");
				}
			}

			break;

		case "4":
			while (true) {
				System.out.println("Enter password to update");
				String password = sc.nextLine();
				if (val.passwordvalidation(password)) {
					String query = "update users_info set password=? where userId=?";
					try (Connection conn = DriverManager.getConnection(dbUrl);
							PreparedStatement pstmt = conn.prepareStatement(query)) {
						pstmt.setString(1, password);
						pstmt.setInt(2, userId);
						Integer res = pstmt.executeUpdate();
						if (res > 0) {
							System.out.println("Your profile is updated");
							break;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					System.err.println("Enter valid password to update!!!");
				}
			}

			break;

		default:
			System.err.println("Enter only number between 1 to 4");

		}
	}

	@Override
	public void getAllMedicineInfo() {
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement stmt = conn.createStatement()) {
			String query = "select * from product_info";
			try (ResultSet res = stmt.executeQuery(query)) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getString(3));
					System.out.println(res.getDouble(4));
					System.out.println(res.getInt(5));
					System.out.println("---------------------");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void sendMessageToAdmin(int userId) {
		System.out.println("Enter your name");
		String username = sc.nextLine();
		System.out.println("Enter your issue/message");
		String message = sc.nextLine();
		String query = "insert into admin_msg(userId,username,inbox) values(?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			pstmt.setString(2, username);
			pstmt.setString(3, message);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("Message sent");
				System.out.println("--------------------------");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void seeAllSentMessages(int userId) {

		String query = "select * from admin_msg where userId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);

			ResultSet res = pstmt.executeQuery();
			while (res.next()) {

				System.out.println("Message Id     :" + res.getInt(1));
				System.out.println("Message        :" + res.getString(4));
				System.out.println("-------------------------");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
