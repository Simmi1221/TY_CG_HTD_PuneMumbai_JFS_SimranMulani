package com.capg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UserDAOImpl implements UserDAO {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);

	public UserDAOImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded......");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void registerUser(String username, String email, String mobileNum, String password) {
		String query = "insert into users_info (username,email,mobileNum,password) values (?,?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setString(2, email);
			pstmt.setString(3, mobileNum);
			pstmt.setString(4, password);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("User Account created");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int loginAsUser() {
		System.out.println("enter your email");
		String email = sc.nextLine();
		System.out.println("enter your password");
		String password = sc.nextLine();
		String query = "select userId from users_info where email=? and password=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				int userId = res.getInt(1);
				return userId;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public void getOurProfile(int userId) {
		String query = "select * from users_info where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getString(3));
					System.out.println(res.getString(4));
					System.out.println(res.getString(5));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateUserProfile(int userId) {
		System.out.println("enter username to update");
		String username = sc.nextLine();
		System.out.println("enter email to update");
		String email = sc.nextLine();
		System.out.println("enter password to update");
		String password = sc.nextLine();
		System.out.println("enter mobile number to update");
		String mobileNum = sc.nextLine();
		String query = "update users_info set username=?, email=?, password=?,mobileNum=? where userId=?";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setString(2, email);
			pstmt.setString(3, password);
			pstmt.setString(4, mobileNum);
			pstmt.setInt(5, userId);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("Your profile is updated");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void getAllMedicineInfo() {
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement stmt = conn.createStatement()) {
			String query = "select * from product_info";
			try (ResultSet res = stmt.executeQuery(query)) {
				while (res.next()) {
					System.out.println(res.getInt(1));
					System.out.println(res.getString(2));
					System.out.println(res.getString(3));
					System.out.println(res.getDouble(4));
					System.out.println(res.getInt(5));
					System.out.println("---------------------");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void sendMessageToAdmin(int userId) {
		System.out.println("Enter your name");
		String username = sc.nextLine();
		System.out.println("Enter your issue/message");
		String message = sc.nextLine();
		String query = "insert into admin_msg(userId,username,inbox) values(?,?,?)";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			pstmt.setString(2, username);
			pstmt.setString(3, message);
			Integer res = pstmt.executeUpdate();
			if (res > 0) {
				System.out.println("message sent");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void seeAllSentMessages(int userId) {

		String query = "select inbox from admin_msg where userId=? ";
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userId);

			ResultSet res = pstmt.executeQuery();
			while (res.next()) {

				System.out.println(res.getString(1));
				System.out.println("-------------------------");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
