package com.capg.jdbc.validation;

public interface AdminUserValidation {
	public boolean mobileNumValidation(String mobileNum);
	public boolean emailValidation(String email);
	public boolean passwordvalidation(String password);
	public boolean usernameValidation(String username);

}
