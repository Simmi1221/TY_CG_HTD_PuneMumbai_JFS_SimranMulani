package com.capg.jdbc.validation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CustomValidationImpl implements CustomValidation {

	String dbUrl = "jdbc:mysql://localhost:3306/medical?user=root&password=tiger";
	Scanner sc = new Scanner(System.in);

	public CustomValidationImpl() {
		// Load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean emailValidationForAdmin(String email) {
		String query = "select email from admin_info";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (email.equalsIgnoreCase(res.getString(1))) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean emailValidationForUser(String email) {
		String query = "select email from users_info";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (email.equalsIgnoreCase(res.getString(1))) {
						valid = true;
						return valid;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean checkProductName(String productName) {
		String query = "select productName from product_info";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (productName.equalsIgnoreCase(res.getString(1))) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean checkProductId(int productId) {

		String query = "select productId from product_info";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (productId == res.getInt(1)) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean checkUserId(int userId) {

		String query = "select userId from users_info";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (userId == res.getInt(1)) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean checkCartId(int cartId, int userId) {
		String query = "select cartId from cart_info ";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl); Statement pstmt = conn.createStatement()) {
			try (ResultSet res = pstmt.executeQuery(query);) {
				while (res.next()) {
					if (cartId == res.getInt(1)) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

	@Override
	public boolean quantityValidation(int quantity, String productName) {
		String query = "select quantity from product_info where productName=?";
		boolean valid = false;
		try (Connection conn = DriverManager.getConnection(dbUrl);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, productName);
			try (ResultSet res = pstmt.executeQuery()) {
				while (res.next()) {
					if (quantity <= res.getInt(1)) {
						valid = true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return valid;
	}

}
