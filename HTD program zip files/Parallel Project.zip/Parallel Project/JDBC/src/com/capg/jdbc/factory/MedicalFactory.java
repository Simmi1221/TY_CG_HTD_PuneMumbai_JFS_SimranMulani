package com.capg.jdbc.factory;

import com.capg.jdbc.dao.AdminDAO;
import com.capg.jdbc.dao.AdminDAOImpl;
import com.capg.jdbc.dao.CartDAO;
import com.capg.jdbc.dao.CartDAOImpl;
import com.capg.jdbc.dao.UserDAO;
import com.capg.jdbc.dao.UserDAOImpl;
import com.capg.jdbc.validation.AdminUserValidation;
import com.capg.jdbc.validation.AdminUserValidationImpl;

public class MedicalFactory {
	
	private void MedicalFactory() {
	}
	
	public static AdminDAO getAdminInstance() {
		AdminDAO dao=new AdminDAOImpl();
		return dao;
	}
	
	public static UserDAO getUserInstance() {
		UserDAO dao=new UserDAOImpl();
		return dao;
	}
	
	public static CartDAO getCartInstance() {
		CartDAO dao=new CartDAOImpl();
		return dao;
	}
	
	public static AdminUserValidation getValidation() {
		AdminUserValidation dao=new AdminUserValidationImpl();
		return dao;
	}

}
