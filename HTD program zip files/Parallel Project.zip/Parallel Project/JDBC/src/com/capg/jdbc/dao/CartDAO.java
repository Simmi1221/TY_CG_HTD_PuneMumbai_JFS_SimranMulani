package com.capg.jdbc.dao;

public interface CartDAO {
	
	
	public void addToCart(int userId);
	public void displayAllSelectedItemFromCart(int userId);
	public void deleteItemFromCart(int userId);
    public double payment(int userId);

}
