package com.capg.jdbc.dao;

public interface CartDAO {
	
	public void getIdForAddToCart(int userId);
	public void addToCart(int medId,String selectedMedName,double price,int userId);
	public void displayAllSelectedItemFromCart(int userId);
	public void deleteItemFromCart();
    public double payment(int userId);

}
