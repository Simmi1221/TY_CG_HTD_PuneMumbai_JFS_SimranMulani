package com.cg.collection.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.cg.collection.beans.CartInfoBean;
import com.cg.collection.beans.OrderInfoBean;
import com.cg.collection.beans.ProductInfoBean;

public class CartDAOImpl implements CartDAO {

	static List<CartInfoBean> cartList = null;
	static List<OrderInfoBean> orderList = null;

	static {
		cartList = new LinkedList<CartInfoBean>();
		CartInfoBean cartInfoBean = new CartInfoBean(1, 1, 1, "Dcold", "HealthCare", 5, 20);
		CartInfoBean cartInfoBean1 = new CartInfoBean(2, 1, 2, "Sinarest", "HealthCare", 10, 15);
		cartList.add(cartInfoBean);
		cartList.add(cartInfoBean1);

		orderList = new LinkedList<OrderInfoBean>();
		OrderInfoBean orderInfoBean = new OrderInfoBean(1, 1, 1, "Dcold", 5, 10);
		OrderInfoBean orderInfoBean1 = new OrderInfoBean(2, 2, 1, "Sinarest", 10, 20);
		OrderInfoBean orderInfoBean2 = new OrderInfoBean(3, 1, 2, "Dcold", 5, 10);
		OrderInfoBean orderInfoBean3 = new OrderInfoBean(4, 2, 2, "Sinarest", 10, 20);
		orderList.add(orderInfoBean);
		orderList.add(orderInfoBean1);
		orderList.add(orderInfoBean2);
		orderList.add(orderInfoBean3);
	}

	Scanner sc = new Scanner(System.in);

	@Override
	public void addToCart(int userId) {

		boolean check = true;
		while (check) {
			try {
				System.out.println("Enter cart id");
				int cartId = Integer.parseInt(sc.nextLine());
				System.out.println("Enter which product you want to add into cart");
				String prodName = sc.nextLine();

				ProductInfoBean bean = null;
				for (ProductInfoBean list : AdminDAOImpl.productList) {
					if (list.getProductName().equalsIgnoreCase(prodName)) {
						bean = list;
					}
				}
				if (bean != null) {
					System.out.println("Enter quantity that you want");
					int quantity = Integer.parseInt(sc.nextLine());
					CartInfoBean cartInfoBean3 = new CartInfoBean(cartId, userId, bean.getProductId(), prodName,
							bean.getProductCategory(), bean.getPrice(), quantity);
					cartList.add(cartInfoBean3);
					System.out.println("Product added into cart successfully..............");
					System.out.println("-------------------------------------------------------");
					check = false;

				} else {
					System.err.println("product out od stock!!!");

				}

			} catch (NumberFormatException e) {
				System.err.println("Enter numbber only");
			}

		}
	}

	@Override
	public void seeCartItems(int userId) {
		List<CartInfoBean> beanList = new LinkedList<CartInfoBean>();
		for (CartInfoBean list : cartList) {
			if (userId == list.getUserId()) {
				beanList.add(list);
			}
		}
		if (!beanList.isEmpty()) {
			for (CartInfoBean bList : beanList) {
				System.out.println("Cart Id         =" + bList.getCartId());
				System.out.println("Product Id      =" + bList.getProductId());
				System.out.println("Product Name    =" + bList.getProductName());
				System.out.println("Product Category=" + bList.getProductCategory());
				System.out.println("Product Price   =" + bList.getPrice());
				System.out.println("-------------------------------------");
			}
		} else {
			System.out.println("Your cart is empty!!!");
		}

	}

	@Override
	public void deleteFromcart(int userId) {

		System.out.println("Enter cart id which you want to remove from cart");
		int cartId = Integer.parseInt(sc.nextLine());
		CartInfoBean bean = null;
		for (CartInfoBean list : cartList) {
			if (userId == list.getUserId() && cartId == list.getCartId()) {
				bean = list;
			}
		}
		if (bean != null) {
			cartList.remove(bean);
			System.out.println("Selected product is removed from cart.");
		}
	}

	@Override
	public void buyOrder(int userId) {

		System.out.println("Enter how many products you want to buy from cart");
		int count = Integer.parseInt(sc.nextLine());

		for (int i = 1; i <= count; i++) {
			System.out.println("Enter cartId which you want to buy");
			int cartId = Integer.parseInt(sc.nextLine());
			System.out.println("Enter order Id");
			int orderId = Integer.parseInt(sc.nextLine());

			CartInfoBean bean = null;
			if (cartList != null) {
				for (CartInfoBean list : cartList) {
					if (cartId == list.getCartId() && userId == list.getUserId()) {
						bean = list;
						OrderInfoBean orderBean = new OrderInfoBean(orderId, cartId, userId, bean.getProductName(),
								bean.getPrice(), bean.getQuantity());
						orderList.add(orderBean);
						System.out.println("*************Your order is confirm*******************");
					}
				}
			} else {
				System.err.println("Your cart is empty!!!");
			}

		}
	}

	static List<OrderInfoBean> beanList = null;

	@Override
	public double orderList(int userId) {
		beanList = new LinkedList<OrderInfoBean>();
		for (OrderInfoBean list : orderList) {
			if (userId == list.getUserId()) {
				beanList.add(list);
			}
		}
		double totalBill = 0;
		if (!beanList.isEmpty()) {
			for (OrderInfoBean bList : orderList) {
				System.out.println("Order Id      =" + bList.getOrderId());
				System.out.println("Cart Id       =" + bList.getCartId());
				System.out.println("Product name  =" + bList.getProductName());
				double price = bList.getPrice();
				System.out.println("Product price =" + price);
				int quantity = bList.getQuantity();
				System.out.println("Quantity      =" + quantity);
				double bill = price * quantity;
				totalBill = totalBill + bill;
				System.out.println("-------------------------------------");
			}

			System.out.println("Total bill is Rs." + totalBill);
			return totalBill;

		} else {
			System.out.println("Your order list is empty!!!");
		}
		return totalBill;
	}

	@Override
	public void payment(int userId, double totalBill) {

		System.out.println("Your total bill is Rs." + totalBill);
	}

}
