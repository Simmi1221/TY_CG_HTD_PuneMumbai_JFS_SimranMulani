package com.cg.collection.controller;

import java.util.Scanner;

import com.cg.collection.dao.AdminDAO;
import com.cg.collection.dao.CartDAO;
import com.cg.collection.dao.UserDAO;
import com.cg.collection.factory.MedicalFactory;

public class UserMain {

	static double totalBill = 0;

	public static void userContent(int userId) {

		Scanner sc = new Scanner(System.in);
		while (true) {

			AdminDAO dao = MedicalFactory.getAdminInstance();
			UserDAO dao1 = MedicalFactory.getUserInstance();
			CartDAO dao2 = MedicalFactory.getCartInstance();

			System.out.println("Press 1 to see all medicines/products");
			System.out.println("Press 2 to see all cart items");
			System.out.println("Press 3 to add the medicines/products into cart");
			System.out.println("Press 4 to delete the medicine/product from cart");
			System.out.println("Press 5 to buy order");
			System.out.println("Press 6 to see order list");
			System.out.println("Press 7 to payment ");
			System.out.println("Press 8 to update your profile");
			System.out.println("Press 9 to see all messages");
			System.out.println("Press 10 to send message to admin");
			System.out.println("Press 11 to exit");
			System.out.println("Enter correct choice.....");
			String choice = sc.nextLine();
			switch (choice) {

			case "1":
				dao.getAllProducts();
				break;

			case "2":
				dao2.seeCartItems(userId);
				break;

			case "3":
				dao2.addToCart(userId);
				break;

			case "4":
				dao2.deleteFromcart(userId);
				break;

			case "5":
				dao2.buyOrder(userId);
				break;

			case "6":
				totalBill = dao2.orderList(userId);
				System.out.println(totalBill);
				break;

			case "7":
				dao2.payment(userId, totalBill);
				break;

			case "8":
				dao1.updateProfile(userId);
				break;

			case "9":
                dao1.seeAllSentMessages(userId);
				break;

			case "10":
				dao1.sendMessageToAdmin(userId);
				break;

			case "11":
				sc.close();
				System.exit(0);
                break;
                
			default:
				System.err.println("Enter number between 1 to 11 only");

			}

		}
	}

}
