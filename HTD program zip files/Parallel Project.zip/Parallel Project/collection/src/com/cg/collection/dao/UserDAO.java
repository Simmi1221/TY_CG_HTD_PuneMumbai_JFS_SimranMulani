package com.cg.collection.dao;

public interface UserDAO {
	
	public void registerForuser();
	public int loginAsUser(String email,String password);
	public void updateProfile(int userId);
	public void sendMessageToAdmin(int userId);
	public void seeAllSentMessages(int userId);


}
