package com.cg.collection.dao;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.collection.beans.AdminMsgBox;
import com.cg.collection.beans.UserInfoBean;
import com.cg.collection.beans.UserMsgBox;

public class UserDAOImpl implements UserDAO {

	static Set<UserInfoBean> userList = null;
	static List<UserMsgBox> userMessageList=null;
	static {
		userList = new LinkedHashSet<UserInfoBean>();
		UserInfoBean userInfoBean = new UserInfoBean(1, "Safura Mulani", "safura@gmail.com", "9022692499", "safura");
		UserInfoBean userInfoBean2 = new UserInfoBean(2, "Sumayya Mulani", "sumayya@gmail.com", "9004031213","sumayya");
		UserInfoBean userInfoBean3 = new UserInfoBean(3, "Murtuja Mulani", "murtuja@gmail.com", "8788151739","murtuja");
		userList.add(userInfoBean);
		userList.add(userInfoBean2);
		userList.add(userInfoBean3);
		
		userMessageList=new LinkedList<UserMsgBox>();
		UserMsgBox userMsg=new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Order will come within two days.");
		UserMsgBox userMsg1=new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Sorry for late.");
		userMessageList.add(userMsg);
		userMessageList.add(userMsg1);
	}

	Scanner sc = new Scanner(System.in);

	@Override
	public int loginAsUser(String email, String password) {
		int userId = 0;
		for (UserInfoBean list : userList) {
			if (list.getEmail().equalsIgnoreCase(email)) {
				if (list.getPassword().equals(password)) {
					System.out.println("Logged in successfully");
					System.out.println("**********Welcome " + list.getUsername() + " to medical store*********");
					userId = list.getUserId();
					return userId;
				} 
			} 
		}
		return userId;
	}

	@Override
	public void updateProfile(int userId) {
		UserInfoBean bean = null;
		for (UserInfoBean list : userList) {
			if (userId == list.getUserId()) {
				bean = list;
			}
		}
		if (bean != null) {
			System.out.println("Enter username to update");
			String username = sc.nextLine();
			System.out.println("Enter email to update");
			String email = sc.nextLine();
			System.out.println("Enter password to update");
			String password = sc.nextLine();
			bean.setUsername(username);
			bean.setEmail(email);
			bean.setPassword(password);
			System.out.println("Your profile is updated successfully.....");
			System.out.println("User name  :" + bean.getUsername());
			System.out.println("Email id   :" + bean.getEmail());
			System.out.println("Password   :" + bean.getPassword());
		}
	}

	@Override
	public void registerForuser() {
		System.out.println("Enter user id");
		int userId = Integer.parseInt(sc.nextLine());
		System.out.println("Enter user name");
		String username = sc.nextLine();
		System.out.println("Enter email id ");
		String email = sc.nextLine();
		System.out.println("Enter mobile number");
		String mobileNum = sc.nextLine();
		System.out.println("Enter password");
		String password=sc.nextLine();
		
		UserInfoBean userBean=new UserInfoBean(userId, username, email, mobileNum, password);
		userList.add(userBean);
		System.out.println("You are registered successfully......");

	}

	
	@Override
	public void sendMessageToAdmin(int userId) {
		System.out.println("Enter message id");
		int messageId=Integer.parseInt(sc.nextLine());
		System.out.println("Enter message/issue regarding order ");
		String message=sc.nextLine();
		UserInfoBean bean=null;
		for(UserInfoBean user:userList) {
			if(userId==user.getUserId()) {
				bean=user;
			}
		}
		if(bean!=null) {
			AdminMsgBox msg=new AdminMsgBox(messageId, userId, bean.getUsername(), bean.getMobileNum(), message);
			AdminDAOImpl.adminMessageList.add(msg);
            System.out.println("Message sent to admin successfully");
		}
	}

	@Override
	public void seeAllSentMessages(int userId) {

    for(AdminMsgBox msg:AdminDAOImpl.adminMessageList) {
    	if(userId==msg.getUserId()) {
    		System.out.println("Message Id ="+msg.getMessageId());
    		System.out.println("Mssage     ="+msg.getMessage());
    		System.out.println("-----------------------------");
    	}
    }
		
	}
	
	

}
