package com.cg.collection.dao;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.collection.beans.AdminMsgBox;
import com.cg.collection.beans.UserInfoBean;
import com.cg.collection.beans.UserMsgBox;
import com.cg.collection.controller.UserMain;
import com.cg.collection.factory.MedicalFactory;
import com.cg.collection.validation.Validation;

public class UserDAOImpl implements UserDAO {

	public static Set<UserInfoBean> userList = null;
	static List<UserMsgBox> userMessageList = null;
	static {
		userList = new LinkedHashSet<UserInfoBean>();
		UserInfoBean userInfoBean = new UserInfoBean(1, "Safura Mulani", "safuramulani@gmail.com", "9022692499",
				"safura");
		UserInfoBean userInfoBean2 = new UserInfoBean(2, "Sumayya Mulani", "sumayya@gmail.com", "9004031213",
				"sumayya");
		UserInfoBean userInfoBean3 = new UserInfoBean(3, "Murtuja Mulani", "murtuja@gmail.com", "8788151739",
				"murtuja");
		userList.add(userInfoBean);
		userList.add(userInfoBean2);
		userList.add(userInfoBean3);

		userMessageList = new LinkedList<UserMsgBox>();
		UserMsgBox userMsg = new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Order will come within two days.", 1);
		UserMsgBox userMsg1 = new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Sorry for late.", 1);
		userMessageList.add(userMsg);
		userMessageList.add(userMsg1);
	}

	Scanner sc = new Scanner(System.in);
	Validation val = MedicalFactory.getValidation();

	@Override
	public void loginUser() {

		int userId = 0;
		System.out.println("Login Here!!!");
		System.out.println("Enter email id");
		String email1 = sc.nextLine();
		for (UserInfoBean li : UserDAOImpl.userList) {
			if (email1.equalsIgnoreCase(li.getEmail())) {

				System.out.println("Enter password");
				String password1 = sc.nextLine();
				if (li.getPassword().equals(password1)) {
					System.out.println("Logged in successfully");
					System.out.println(
							"**********Welcome " + li.getUsername().toUpperCase() + " to medical store*********");
					userId = li.getUserId();
				} else {
					System.err.println("Enter valid password");
					break;
				}
				if (userId > 0) {

					UserMain.userContent(userId);
					break;
				}
			} else {
				System.err.println("Email Id does not exist!!!");
				break;
			}
		}

	}

	@Override
	public void updateProfile(int userId) {

		UserInfoBean bean = null;
		for (UserInfoBean list : userList) {
			if (userId == list.getUserId()) {
				bean = list;
			}
		}
		if (bean != null) {

			try {
				while (true) {
					System.out.println("Enter user name");
					String username = sc.nextLine();
					if (val.usernameValidation(username)) {
						System.out.println("Enter email id ");
						String email = sc.nextLine();
						if (val.emailValidation(email)) {
							System.out.println("Enter mobile number");
							String mobileNum = sc.nextLine();
							if (val.mobileNumValidation(mobileNum)) {
								System.out.println("Enter password");
								String password = sc.nextLine();
								if (val.passwordValidation(password)) {
									UserInfoBean userBean = new UserInfoBean(userId, username, email, mobileNum,
											password);
									userList.add(userBean);
									System.out.println("Your profile updated successfully......");
									System.out.println("-------------------------------------------");
									break;
								} else {
									System.err.println("enter valid password");
								}

							} else {
								System.err.println("enter valid mobile number");
							}

						} else {
							System.err.println("enter valid email id");
						}
					} else {
						System.err.println("enter valid username");
					}

				}
			} catch (Exception e) {
				System.out.println("Input mismatch");
			}

		}

	}

	@Override
	public void registerForuser() {

		boolean check = true;
		UserInfoBean user = new UserInfoBean();

		while (check) {
			try {
				System.out.println("Enter user id");
				int userId = Integer.parseInt(sc.nextLine());

				while (check) {
					System.out.println("Enter full name");
					String username = sc.nextLine();
					if (val.usernameValidation(username)) {
						user.setUsername(username);
						while (check) {
							System.out.println("Enter email id ");
							String email = sc.nextLine();
							if (val.emailValidation(email)) {
								boolean isValid = false;
								for (UserInfoBean li : userList) {
									if (email.equalsIgnoreCase(li.getEmail())) {
										isValid = true;
									}
								}
								if (!isValid) {

									user.setEmail(email);
									while (check) {
										System.out.println("Enter mobile number");
										String mobileNum = sc.nextLine();
										if (val.mobileNumValidation(mobileNum)) {
											user.setMobileNumber(mobileNum);
											while (check) {
												System.out.println("Enter password");
												String password = sc.nextLine();
												if (val.passwordValidation(password)) {
													user.setPassword(password);
													UserInfoBean userBean = new UserInfoBean(userId, username, email,
															mobileNum, password);
													userList.add(userBean);
													System.out.println("You are registered successfully......");
													System.out.println("-------------------------------------------");
													break;
												} else {
													System.err.println(
															"Enter atleast 5 character or atmost 10 character!!!");
												}

											}
										} else {
											System.err.println("Enter valid mobile number");
										}

									}
								} else {
									System.err.println("Email Id already exist!!!");
								}

							} else {
								System.err.println("Enter valid email id: It should like abc@xyz.com!!!");
							}
						}
					} else {
						System.err.println("Enter full name!!!");
					}

				}
			} catch (NumberFormatException e) {
				System.err.println("Enter only number for id!!!");
			}

		}

	}

	@Override
	public void sendMessageToAdmin(int userId) {

		while (true) {
			try {

				System.out.println("Enter message id");
				int messageId = Integer.parseInt(sc.nextLine());
				System.out.println("Enter message/issue regarding order ");
				String message = sc.nextLine();
				UserInfoBean bean = null;
				for (UserInfoBean user : userList) {
					if (userId == user.getUserId()) {
						bean = user;
					}
				}
				if (bean != null) {
					AdminMsgBox msg = new AdminMsgBox(messageId, userId, bean.getUsername(), bean.getMobileNumber(),
							message);
					AdminDAOImpl.adminMessageList.add(msg);
					System.out.println("Message sent to admin successfully");
					System.out.println("----------------------------------------------");
					break;
				}
			} catch (NumberFormatException e) {
				System.err.println("Enter only number for message id");
			}
		}

	}

	@Override
	public void seeAllSentMessages(int userId) {

		for (AdminMsgBox msg : AdminDAOImpl.adminMessageList) {
			if (userId == msg.getUserId()) {
				System.out.println("Message Id =" + msg.getMessageId());
				System.out.println("Mssage     =" + msg.getMessage());
				System.out.println("-----------------------------");
			}
		}

	}

}
