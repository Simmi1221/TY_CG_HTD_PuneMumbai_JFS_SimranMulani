package com.cg.collection.dao;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.collection.beans.AdminMsgBox;
import com.cg.collection.beans.UserInfoBean;
import com.cg.collection.beans.UserMsgBox;
import com.cg.collection.factory.MedicalFactory;
import com.cg.collection.validation.Validation;

public class UserDAOImpl implements UserDAO {

	static Set<UserInfoBean> userList = null;
	static List<UserMsgBox> userMessageList = null;
	static {
		userList = new LinkedHashSet<UserInfoBean>();
		UserInfoBean userInfoBean = new UserInfoBean(1, "Safura Mulani", "safuramulani@gmail.com", "9022692499",
				"safura");
		UserInfoBean userInfoBean2 = new UserInfoBean(2, "Sumayya Mulani", "sumayya@gmail.com", "9004031213",
				"sumayya");
		UserInfoBean userInfoBean3 = new UserInfoBean(3, "Murtuja Mulani", "murtuja@gmail.com", "8788151739",
				"murtuja");
		userList.add(userInfoBean);
		userList.add(userInfoBean2);
		userList.add(userInfoBean3);

		userMessageList = new LinkedList<UserMsgBox>();
		UserMsgBox userMsg = new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Order will come within two days.", 1);
		UserMsgBox userMsg1 = new UserMsgBox(1, 1, "Simran Mulani", "9359467647", "Sorry for late.", 1);
		userMessageList.add(userMsg);
		userMessageList.add(userMsg1);
	}

	Scanner sc = new Scanner(System.in);
	Validation val = MedicalFactory.getValidation();

	@Override
	public int loginAsUser(String email, String password) {
		int userId = 0;
		for (UserInfoBean list : userList) {
			if (list.getEmail().equalsIgnoreCase(email)) {
				if (list.getPassword().equals(password)) {
					System.out.println("Logged in successfully");
					System.out.println(
							"**********Welcome " + list.getUsername().toUpperCase() + " to medical store*********");
					userId = list.getUserId();
					return userId;
				} else {
					System.err.println("Enter valid password");
					break;
				}
			} else {
				System.err.println("Entered email id does not exist");
				break;
			}
		}
		return userId;
	}

	@Override
	public void updateProfile(int userId) {

		UserInfoBean bean = null;
		for (UserInfoBean list : userList) {
			if (userId == list.getUserId()) {
				bean = list;
			}
		}
		if (bean != null) {

			try {
				while (true) {
					System.out.println("Enter user name");
					String username = sc.nextLine();
					if (val.usernameValidation(username)) {
						System.out.println("Enter email id ");
						String email = sc.nextLine();
						if (val.emailValidation(email)) {
							System.out.println("Enter mobile number");
							String mobileNum = sc.nextLine();
							if (val.mobileNumValidation(mobileNum)) {
								System.out.println("Enter password");
								String password = sc.nextLine();
								if (val.passwordValidation(password)) {
									UserInfoBean userBean = new UserInfoBean(userId, username, email, mobileNum,
											password);
									userList.add(userBean);
									System.out.println("Your profile updated successfully......");
									System.out.println("-------------------------------------------");
									break;
								} else {
									System.err.println("enter valid password");
								}

							} else {
								System.err.println("enter valid mobile number");
							}

						} else {
							System.err.println("enter valid email id");
						}
					} else {
						System.err.println("enter valid username");
					}

				}
			} catch (Exception e) {
				System.out.println("Input mismatch");
			}

		}

	}

	@Override
	public void registerForuser() {

		UserInfoBean user = new UserInfoBean();

		while (true) {
			try {
				System.out.println("Enter user id");
				int userId = Integer.parseInt(sc.nextLine());
				while (true) {
					System.out.println("Enter user name");
					String username = sc.nextLine();
					if (val.usernameValidation(username)) {
						user.setUsername(username);
						System.out.println("Enter email id ");
						String email = sc.nextLine();
						if (val.emailValidation(email)) {
							user.setEmail(email);
							System.out.println("Enter mobile number");
							String mobileNum = sc.nextLine();
							if (val.mobileNumValidation(mobileNum)) {
								user.setMobileNumber(mobileNum);
								System.out.println("Enter password");
								String password = sc.nextLine();
								if (val.passwordValidation(password)) {
									user.setPassword(password);
									UserInfoBean userBean = new UserInfoBean(userId, username, email, mobileNum,
											password);
									userList.add(userBean);
									System.out.println("You are registered successfully......");
									System.out.println("-------------------------------------------");
									break;
								} else {
									System.err.println("enter valid password");
								}

							} else {
								System.err.println("enter valid mobile number");
							}

						} else {
							System.err.println("enter valid email id");
						}
					} else {
						System.err.println("enter valid username");
					}

				}
			} catch (NumberFormatException e) {
				System.err.println("Enter only number for id!!!");
			}

		}

	}

	@Override
	public void sendMessageToAdmin(int userId) {

		while (true) {
			try {

				System.out.println("Enter message id");
				int messageId = Integer.parseInt(sc.nextLine());
				System.out.println("Enter message/issue regarding order ");
				String message = sc.nextLine();
				UserInfoBean bean = null;
				for (UserInfoBean user : userList) {
					if (userId == user.getUserId()) {
						bean = user;
					}
				}
				if (bean != null) {
					AdminMsgBox msg = new AdminMsgBox(messageId, userId, bean.getUsername(), bean.getMobileNumber(),
							message);
					AdminDAOImpl.adminMessageList.add(msg);
					System.out.println("Message sent to admin successfully");
					System.out.println("----------------------------------------------");
					break;
				}
			} catch (NumberFormatException e) {
				System.err.println("Enter only number for message id");
			}
		}

	}

	@Override
	public void seeAllSentMessages(int userId) {

		for (AdminMsgBox msg : AdminDAOImpl.adminMessageList) {
			if (userId == msg.getUserId()) {
				System.out.println("Message Id =" + msg.getMessageId());
				System.out.println("Mssage     =" + msg.getMessage());
				System.out.println("-----------------------------");
			}
		}

	}

}
