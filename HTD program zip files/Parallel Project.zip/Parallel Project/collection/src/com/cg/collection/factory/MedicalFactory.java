package com.cg.collection.factory;

import com.cg.collection.dao.AdminDAO;
import com.cg.collection.dao.AdminDAOImpl;
import com.cg.collection.dao.CartDAO;
import com.cg.collection.dao.CartDAOImpl;
import com.cg.collection.dao.UserDAO;
import com.cg.collection.dao.UserDAOImpl;

public class MedicalFactory {
	
	private void MedicalFactory() {
	}
	
	public static AdminDAO getAdminInstance() {
		AdminDAO dao=new AdminDAOImpl();
		return dao;
	}
	
	public static UserDAO getUserInstance() {
		UserDAO dao=new UserDAOImpl();
		return dao;
	}
	
	public static CartDAO getCartInstance() {
		CartDAO dao=new CartDAOImpl();
		return dao;
	}

}
