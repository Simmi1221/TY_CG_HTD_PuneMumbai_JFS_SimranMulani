package com.cg.collection.controller;

import java.util.Scanner;

import com.cg.collection.dao.AdminDAO;
import com.cg.collection.factory.MedicalFactory;

public class AdminMain {

	public static void adminContent(int adminId) {

		AdminDAO dao = MedicalFactory.getAdminInstance();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("Press 1 to see all medicines/products");
			System.out.println("Press 2 to add the medicines/products");
			System.out.println("Press 3 to update the medicines/products");
			System.out.println("Press 4 to delete the medicine/product ");
			System.out.println("Press 5 to see all users");
			System.out.println("Press 6 to delete the user");
			System.out.println("Press 7 to see all messages");
			System.out.println("Press 8 to send reply to user");
			System.out.println("Press 9 to generate report");
			System.out.println("Press 10 to exit");
			System.out.println("Enter correct choice.....");
			String choice = sc.nextLine();
			switch (choice) {

			case "1":
				dao.getAllProducts();
				break;

			case "2":
				dao.addProduct();
				break;

			case "3":
				dao.updateProduct();
				break;

			case "4":
				dao.deleteProduct();
				break;

			case "5":
				dao.seeAllUser();
				break;

			case "6":
				dao.deleteUser();
				break;

			case "7":
                dao.seeAllSentMessages(adminId);
				break;
				
			case "8":
                dao.sendMessageToUser(adminId);
				break;

			case "9":
				dao.report();
				break;
				
			case "10":
				sc.close();
				System.exit(0);
				break;
				
			default:
				System.err.println("Enter number 1 to 10 only");

			}
		}
	}
}
