package com.cg.collection.beans;

public class AdminMsgBox {

	private int messageId;
	private int userId;
	private String username;
	private String mobileNum;
	private String message;

	// parameterized constructor

	public AdminMsgBox(int messageId, int userId, String username, String mobileNum, String message) {
		super();
		this.messageId = messageId;
		this.userId = userId;
		this.username = username;
		this.mobileNum = mobileNum;
		this.message = message;
	}

	// Getters and Setters

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
