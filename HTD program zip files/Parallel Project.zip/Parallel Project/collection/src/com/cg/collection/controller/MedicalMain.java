package com.cg.collection.controller;

import java.util.Scanner;

import com.cg.collection.dao.AdminDAO;
import com.cg.collection.dao.UserDAO;
import com.cg.collection.factory.MedicalFactory;

public class MedicalMain {

	public static void main(String[] args) {

		while (true) {
			AdminDAO dao = MedicalFactory.getAdminInstance();
			UserDAO dao1 = MedicalFactory.getUserInstance();
			Scanner sc = new Scanner(System.in);

			System.out.println("********Welcome to medical Store********");
			System.out.println("Press 0 for visitor");
			System.out.println("Press 1 to login as admin");
			System.out.println("Press 2 to login as user");
			System.out.println("Enter your choice.........");
			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {

			case 0:
				dao.getAllProducts();
				break;

			case 1:
				System.out.println("Login Here!!!");
				System.out.println("Enter email id");
				String email = sc.nextLine();
				System.out.println("Enter password");
				String password = sc.nextLine();
				int adminId = dao.loginAsAdmin(email, password);
				if (adminId > 0) {
					AdminMain.adminContent(adminId);
				} else {
					System.out.println("Please, enter correct login credentials...");
				}
				break;

			case 2:
				System.out.println("Press R to registration");
			    System.out.println("Press L to login if you are already registered");  
			    System.out.println("enter your choice.............");
			    String choice1=sc.nextLine();
			    switch(choice1) {
			    
			    case "R":
			    	dao1.registerForuser();
			    	
			    case "L":
			    	System.out.println("Login Here!!!");
					System.out.println("Enter email id");
					String email1 = sc.nextLine();
					System.out.println("Enter password");
					String password1 = sc.nextLine();
					int userId = dao1.loginAsUser(email1, password1);
					if (userId > 0) {
						UserMain.userContent(userId);
					} else {
						System.out.println("Please, enter correct login credentials...");
					}
					break;
					
				default:
					System.out.println("Enter correct choice");
			    }
				
				break;

			default:
				System.out.println("Enter correct choice..........");

			}
			sc.close();
		}
	}
}
