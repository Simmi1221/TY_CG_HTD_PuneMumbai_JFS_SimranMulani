package com.cg.collection.validation;

public interface Validation {
	
	public boolean mobileNumValidation(String mobileNum);
	public boolean emailValidation(String email);
	public boolean passwordValidation(String password);
	public boolean usernameValidation(String username);
	public boolean choiceValidation(String choice);

}
