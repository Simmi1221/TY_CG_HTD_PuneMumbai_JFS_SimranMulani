package com.cg.collection.dao;

public interface AdminDAO {
	
	public void loginAsAdmin();
	public void getAllProducts();
	public void addProduct();
	public void deleteProduct();
	public void updateProduct();
	public void seeAllUser();
	public void deleteUser();
	public void sendMessageToUser(int adminId);
	public void seeAllSentMessages(int adminId);
	public void report();

}
