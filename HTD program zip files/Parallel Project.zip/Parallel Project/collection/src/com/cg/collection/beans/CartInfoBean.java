package com.cg.collection.beans;

public class CartInfoBean {

	private int cartId;
	private int userId;
	private int prodId;
	private String prodName;
	private String prodCategory;
	private double price;

	// parameterized constructor

	public CartInfoBean(int cartId, int userId, int prodId, String prodName, String prodCategory, double price) {
		super();
		this.cartId = cartId;
		this.userId = userId;
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodCategory = prodCategory;
		this.price = price;
	}
	// Getters and Setters

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdCategory() {
		return prodCategory;
	}

	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	
}// end of bean class