package com.cg.collection.beans;

public class OrderInfoBean {
	
	private int orderId;
	private int cartId;
	private int userId;
	private String prodName;
	private double price;
	private int quantity;
	
	//parameterized constructor
	
	public OrderInfoBean(int orderId, int cartId, int userId, String prodName, double price, int quantity) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.userId = userId;
		this.prodName = prodName;
		this.price = price;
		this.quantity = quantity;
	}
	
	//Getters and Setters

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}//end of bean class
