package com.cg.collection.dao;

public interface CartDAO {
	
	public void seeCartItems(int userId);
	public void addToCart(int userId);
	public void deleteFromcart(int userId);
	public void buyOrder(int userId);
	public double orderList(int userId);
	public void payment(int userId,double totallBill);

}
