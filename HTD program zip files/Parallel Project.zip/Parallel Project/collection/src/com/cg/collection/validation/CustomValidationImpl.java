package com.cg.collection.validation;

public class CustomValidationImpl implements CustomValidation {

}
