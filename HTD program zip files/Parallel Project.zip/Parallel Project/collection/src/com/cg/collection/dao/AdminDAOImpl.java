package com.cg.collection.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.cg.collection.beans.AdminInfoBean;
import com.cg.collection.beans.AdminMsgBox;
import com.cg.collection.beans.OrderInfoBean;
import com.cg.collection.beans.ProductInfoBean;
import com.cg.collection.beans.UserInfoBean;
import com.cg.collection.beans.UserMsgBox;

public class AdminDAOImpl implements AdminDAO {

	static List<ProductInfoBean> productList = null;
	static AdminInfoBean adminInfoBean = null;
	static List<AdminMsgBox> adminMessageList = null;

	static {

		productList = new LinkedList<ProductInfoBean>();
		ProductInfoBean productInfoBean = new ProductInfoBean(1, "Dcold", "HealthCare", 5, 100);
		ProductInfoBean productInfoBean2 = new ProductInfoBean(2, "Sinarest", "HealthCare", 10, 80);
		ProductInfoBean productInfoBean3 = new ProductInfoBean(3, "Vaseline", "SkinCare", 100, 20);
		ProductInfoBean productInfoBean4 = new ProductInfoBean(4, "Dove", "SkinCare", 250, 30);
		productList.add(productInfoBean);
		productList.add(productInfoBean2);
		productList.add(productInfoBean3);
		productList.add(productInfoBean4);

		adminInfoBean = new AdminInfoBean(1, "Simran Mulani", "simmimulani1221@gmail.com", "simmi1221", "9359467647");

		adminMessageList = new LinkedList<AdminMsgBox>();
		AdminMsgBox userMsg = new AdminMsgBox(1, 1, "Safura Mulani", "9022692499", "Order still not coming?");
		AdminMsgBox userMsg1 = new AdminMsgBox(2, 1, "Safura Mulani", "9022692499", "When my order will come?");
		adminMessageList.add(userMsg);
		adminMessageList.add(userMsg1);
	}

	Scanner sc = new Scanner(System.in);

	@Override
	public int loginAsAdmin(String email, String password) {

		int adminId = 0;

		if (email.equalsIgnoreCase(adminInfoBean.getEmail())) {
			if (password.equals(adminInfoBean.getPassword())) {
				System.out.println("**************Welcome " + adminInfoBean.getUsername().toUpperCase()
						+ " to medical store**************");
				adminId = adminInfoBean.getAdminId();
				return adminId;
			} else {
				System.err.println("Enter valid passowrd");
			}
		} else {
			System.err.println("Entered email id does not exist");
		}
		return adminId;
	}

	@Override
	public void getAllProducts() {

		for (ProductInfoBean li : productList) {
			System.out.println("Product Id      = " + li.getProductId());
			System.out.println("Product name    = " + li.getProductName());
			System.out.println("Product category= " + li.getProductCategory());
			System.out.println("Product price   = " + li.getPrice());
			System.out.println("Product quantity= " + li.getQuantity());
			System.out.println("------------------------------------------");
		}

	}

	@Override
	public void addProduct() {

		boolean check = false;
		do {
			try {
				System.out.println("Enter product id");
				int prodId = Integer.parseInt(sc.nextLine());
				for (ProductInfoBean list : productList) {
					if (prodId != list.getProductId()) {
						System.out.println("Enter product name");
						String prodName = sc.nextLine();
						if (!prodName.equalsIgnoreCase(list.getProductName())) {
							System.out.println("Enter product category");
							String prodCategory = sc.nextLine();
							try {
								System.out.println("Enter price of product");
								double price = Double.parseDouble(sc.nextLine());
								try {
									System.out.println("Enter quantity");
									int quantity = Integer.parseInt(sc.nextLine());

									ProductInfoBean productInfoBean5 = new ProductInfoBean(prodId, prodName,
											prodCategory, price, quantity);
									productList.add(productInfoBean5);
									if (productList != null) {
										System.out.println("Product added successfully....");
										check = true;
										break;
									}

								} catch (NumberFormatException e) {
									System.err.println("Enter only number for quantity!!!");
								}

							} catch (NumberFormatException e) {
								System.err.println("Enter only number for price!!!");
							}
						} else {
							System.err.println("Entered product is alraedy exist in product list!!!");
						}
					} else {
						System.err.println("Product Id is alraedy exist");
					}
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter only number for id!!!");
			}
		} while (!check);

	}

	@Override
	public void deleteProduct() {
		while (true) {
			System.out.println("enter product name  which you want to delete");
			String prodName = sc.nextLine();

			ProductInfoBean bean = null;
			for (ProductInfoBean list : productList) {
				if (list.getProductName().equalsIgnoreCase(prodName)) {
					bean = list;
				}
			}
			if (bean != null) {
				productList.remove(bean);
				System.out.println("Selected product is deleted successfully");
				System.out.println("--------------------------------------------");
				break;
			} else {
				System.err.println("Entered product is not present in product list!!!");
			}
		}
	}

	@Override
	public void updateProduct() {
		while (true) {
			try {
				System.out.println("Enter product id which you want to update");
				int productId = Integer.parseInt(sc.nextLine());

				ProductInfoBean bean = null;
				for (ProductInfoBean list : productList) {
					if (list.getProductId() == productId) {
						bean = list;
					}
				}
				if (bean != null) {

					System.out.println("Enter product name");
					String prodName = sc.nextLine();
					System.out.println("Enter product price");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("Enter product quantity");
					int quantity = Integer.parseInt(sc.nextLine());

					bean.setPrice(price);
					bean.setProductName(prodName);
					bean.setQuantity(quantity);
					System.out.println("Selected product is updated successfully....");
					break;

				} else {
					System.err.println("Entered product id is not present");
				}

			} catch (NumberFormatException e) {
				System.err.println("Enter only number");
			}
		}

	}

	@Override
	public void seeAllUser() {

		for (UserInfoBean li : UserDAOImpl.userList) {
			System.out.println("Product Id      = " + li.getUserId());
			System.out.println("Product name    = " + li.getUsername());
			System.out.println("Product category= " + li.getEmail());
			System.out.println("Product price   = " + li.getMobileNumber());
			System.out.println("------------------------------------------");
		}
	}

	@Override
	public void deleteUser() {
		while (true) {
			try {

				System.out.println("Enter user id which you want to delete");
				int userId = Integer.parseInt(sc.nextLine());

				UserInfoBean bean = null;
				for (UserInfoBean list : UserDAOImpl.userList) {
					if (list.getUserId() == userId) {
						bean = list;
					}
				}
				if (bean != null) {
					UserDAOImpl.userList.remove(bean);
					System.out.println("Selected user is deleted");
					System.out.println("---------------------------------");
					break;
				} else {
					System.err.println("Entered userId is not present!!!");
				}
			} catch (NumberFormatException e) {
				System.err.println("Enter only number for id");
			}
		}

	}

	@Override
	public void sendMessageToUser(int adminId) {
		while (true) {
			try {
				System.out.println("Enter userId");
				int userId = Integer.parseInt(sc.nextLine());
				for (UserInfoBean list : UserDAOImpl.userList) {
					if (userId == list.getUserId()) {

						System.out.println("Enter message id");
						int messageId = Integer.parseInt(sc.nextLine());
						System.out.println("Enter message/issue regarding order ");
						String message = sc.nextLine();

						if (adminId == adminInfoBean.getAdminId()) {
							UserMsgBox msg = new UserMsgBox(messageId, adminId, adminInfoBean.getUsername(),
									adminInfoBean.getMobileNumber(), message, userId);
							UserDAOImpl.userMessageList.add(msg);
							System.out.println("Message sent to user successfully....");
						}
					}
				}

			} catch (NumberFormatException e) {

				System.err.println("Enter only number for user id");
			}

		}
	}

	@Override
	public void seeAllSentMessages(int adminId) {
		for (UserMsgBox msg : UserDAOImpl.userMessageList) {
			if (adminId == msg.getAdminId()) {
				System.out.println("Message Id =" + msg.getMessageId());
				System.out.println("Mssage     =" + msg.getMessage());
				System.out.println("-----------------------------");
			}
		}
	}

	@Override
	public void report() {

		for (OrderInfoBean list : CartDAOImpl.orderList) {
			System.out.println("Order Id      :" + list.getOrderId());
			System.out.println("User Id       :" + list.getUserId());
			System.out.println("Product name  :" + list.getProductName());
			System.out.println("Price         :" + list.getPrice());
			System.out.println("Quantity      :" + list.getQuantity());
			System.out.println("--------------------------------------");
		}
	}

}
