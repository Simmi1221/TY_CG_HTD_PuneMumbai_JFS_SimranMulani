package com.cg.collection.beans;

public class UserMsgBox {

	private int messageId;
	private int adminId;
	private String adminName;
	private String mobileNumber;
	private String message;
	private int userId;

	// parameterized constructor

	public UserMsgBox(int messageId, int adminId, String adminName, String mobileNumber, String message, int userId) {
		super();
		this.messageId = messageId;
		this.adminId = adminId;
		this.adminName = adminName;
		this.mobileNumber = mobileNumber;
		this.message = message;
		this.userId = userId;
	}

	// Getters and Setters

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
}// end of class
