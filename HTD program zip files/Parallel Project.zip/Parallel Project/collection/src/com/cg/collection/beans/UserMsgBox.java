package com.cg.collection.beans;

public class UserMsgBox {

	private int messageId;
	private int adminId;
	private String adminName;
	private String mobileNum;
	private String message;

	// parameterized constructor

	public UserMsgBox(int messageId, int adminId, String adminName, String mobileNum, String message) {
		super();
		this.messageId = messageId;
		this.adminId = adminId;
		this.adminName = adminName;
		this.mobileNum = mobileNum;
		this.message = message;
	}

	// Getters and Setters

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

}
