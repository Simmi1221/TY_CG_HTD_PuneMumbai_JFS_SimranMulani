package com.cg.collection.validation;

public interface CustomValidation {

}
