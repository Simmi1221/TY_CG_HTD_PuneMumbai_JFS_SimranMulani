package com.capgemini.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springrest.beans.MedicalResponse;
import com.capgemini.springrest.beans.OrderInfoBean;
import com.capgemini.springrest.beans.ProductInfoBean;
import com.capgemini.springrest.beans.UserInfoBean;
import com.capgemini.springrest.beans.UserMsgBox;
import com.capgemini.springrest.service.MedicalService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminRestController {

	@Autowired(required = true)
	private MedicalService service;

	int adminId = 0;

	@GetMapping("/loginAsAdmin")
	public MedicalResponse loginAsAdmin(String username, String password) {

		adminId = service.adminAuthenticate(username, password);
		MedicalResponse response = new MedicalResponse();

		if (adminId != 0) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User admin successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to found admin!!!");
		}
		return response;
	} // end of login()

	@GetMapping("/listOfProducts")
	public MedicalResponse listOfProducts() {
		List<ProductInfoBean> productList = service.listOfProducts();
		MedicalResponse response = new MedicalResponse();
		if (productList != null && !productList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Products found.....");
			response.setProductList(productList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
		}

		return response;
	}// End of listOfProducts()

	@PutMapping("/addProduct")
	public MedicalResponse addProduct(@RequestBody ProductInfoBean productInfoBean) {
		boolean isAdded = service.addProduct(productInfoBean);
		MedicalResponse response = new MedicalResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product added successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to add Product!!!");
		}
		return response;
	}// end of addProduct()

	@PostMapping("/updateProduct")
	public MedicalResponse updateProduct(@RequestBody ProductInfoBean productInfoBean) {
		boolean isUpdated = service.updateProduct(productInfoBean);
		MedicalResponse response = new MedicalResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product updated successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to update Product!!!");
		}

		return response;
	}// end of updateProduct()

	@DeleteMapping("/deleteProduct")
	public MedicalResponse deleteProduct(int prodId) {
		boolean isDeleted = service.deleteProduct(prodId);
		MedicalResponse response = new MedicalResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product deleted successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete the Product!!!");
		}
		return response;
	}// End of deleteProduct()

	@GetMapping("/listOfUsers")
	public MedicalResponse ListOfUsers() {

		List<UserInfoBean> userList = service.listOfUser();
		MedicalResponse response = new MedicalResponse();
		if (userList != null && !userList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Users found.....");
			response.setUserList(userList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Users not found.....");
		}
		return response;
	}// End of listOfUsers()

	@DeleteMapping("/deleteUser")
	public MedicalResponse deleteUser(int userId) {
		boolean isDeleted = service.deleteUser(userId);
		MedicalResponse response = new MedicalResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User deleted successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete the User!!!");
		}

		return response;
	}// End of deleteUser()

	@PutMapping("/replyToUser")
	public MedicalResponse replyToUser(String message, int userId) {

		boolean isSent = service.ReplyToUser(adminId, userId, message);
		MedicalResponse response = new MedicalResponse();
		if (isSent) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Message sent to user successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to send the message!!!");
		}

		return response;
	}// end of replyToUser()

	@GetMapping("/seeAllSentMessage")
	public MedicalResponse inboxOfAdmin() {

		List<UserMsgBox> messageList = service.seeAllSentMessage(adminId);
		MedicalResponse response = new MedicalResponse();

		if (messageList != null && !messageList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Messages found successfully.....");
			response.setMessageList(messageList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to found the message!!!");
		}
		return response;
	}// End of inboxOfAdmin()

	@GetMapping("/generateReport")
	public MedicalResponse generateReport() {

		List<OrderInfoBean> orderList = service.generateReport();
		MedicalResponse response = new MedicalResponse();
		if (orderList != null && !orderList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Report generated.....");
			response.setOrderList(orderList);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to generate report!!!");
		}
		return response;

	}// End of generateReport()
}