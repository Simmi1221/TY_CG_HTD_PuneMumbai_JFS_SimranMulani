package com.capgemini.mpt3.beans;

public class StudentResponse {
	
	private int statusCode;
	private String message;
	private String description;
	private StudentInfoBean studentInfo;
	
	//Getters and Setters
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public StudentInfoBean getStudentInfo() {
		return studentInfo;
	}
	public void setStudentInfo(StudentInfoBean studentInfo) {
		this.studentInfo = studentInfo;
	}
	
}//end of class
