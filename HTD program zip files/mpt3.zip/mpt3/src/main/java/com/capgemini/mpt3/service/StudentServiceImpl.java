package com.capgemini.mpt3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.mpt3.beans.StudentInfoBean;
import com.capgemini.mpt3.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao dao;

	@Override
	public StudentInfoBean getStudent(int stdId) {
		if (stdId > 0) {
			return dao.getStudent(stdId);
		} else {
			return null;
		}

	}

	@Override
	public boolean addStudent(StudentInfoBean stdInfo) {
		return dao.addStudent(stdInfo);
	}

	@Override
	public boolean updateStudent(StudentInfoBean stdInfo) {
		return dao.updateStudent(stdInfo);
	}

	@Override
	public boolean deleteStudent(int stdId) {
		return dao.deleteStudent(stdId);
	}

	@Override
	public double aggregateMarks(int stdId) {
		return dao.aggregateMarks(stdId);
	}

}
