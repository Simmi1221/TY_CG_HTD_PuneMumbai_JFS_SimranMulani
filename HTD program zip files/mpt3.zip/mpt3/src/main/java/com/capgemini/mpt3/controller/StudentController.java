package com.capgemini.mpt3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.mpt3.beans.StudentInfoBean;
import com.capgemini.mpt3.beans.StudentResponse;
import com.capgemini.mpt3.service.StudentService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class StudentController {

	@Autowired
	private StudentService service;

	@PutMapping(path = "/addStudent", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })

	public StudentResponse addStudent(@RequestBody StudentInfoBean stdInfo) {
		boolean isAdded = service.addStudent(stdInfo);
		StudentResponse response = new StudentResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Student added successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to add Student!!!");
		}

		return response;
	}// end of addStudent()

	@GetMapping("/getStudent")
	public StudentResponse getStudent(int stdId) {
		StudentInfoBean studentInfo = service.getStudent(stdId);
		StudentResponse response = new StudentResponse();
		if (studentInfo != null) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Student record found.....");
			response.setStudentInfo(studentInfo);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
		}
		return response;
	}// end of getStudent()

	@PostMapping(path = "/updateStudent", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public StudentResponse updateStudent(@RequestBody StudentInfoBean studentInfo) {
		boolean isUpdated = service.updateStudent(studentInfo);
		StudentResponse response = new StudentResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Student record updated successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to update record of  Student!!!");
		}

		return response;
	}//end

	@DeleteMapping(path = "/deleteStudent/{studentId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public StudentResponse deleteStudent(@PathVariable("studentId") int stdId) {
		boolean isDeleted = service.deleteStudent(stdId);
		StudentResponse response = new StudentResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Student record deleted successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete record of  Student!!!");
		}

		return response;
	}//end
	
	@GetMapping("/getAggregate")
	public double getAggregate(int stdId) {
		double agg = service.aggregateMarks(stdId);
		return agg;
	}// end of getStudent()
	
	@GetMapping("/getGrade")
	public String getGrade(int stdId) {
		double agg=service.aggregateMarks(stdId);
		if(agg!=0) {
			if(agg>=9.1) {
				return "A+";
			}if(agg>=8.1 && agg<=9.0) {
				return "A";
			}if(agg>=7.1 && agg<=8.0) {
				return "B";
			}if(agg>=6.1 && agg<=7.0) {
				return "C";
			}if(agg>=5.1 && agg<=6.0) {
				return "D";
			}if(agg>=4.1 && agg<=5.0) {
				return "E";
			}
	}else {
		return "Fail";
	}
		return null;
}
}// end of controller