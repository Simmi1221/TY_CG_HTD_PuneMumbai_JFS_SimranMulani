package com.capgemini.mpt3.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.mpt3.beans.StudentInfoBean;

@Repository
public class StudentDaoImpl implements StudentDao {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public StudentInfoBean getStudent(int stdId) {
		EntityManager em = emf.createEntityManager();
		StudentInfoBean stdInfo = em.find(StudentInfoBean.class, stdId);
		em.close();

		return stdInfo;
	}// end of getStudent()

	@Override
	public boolean addStudent(StudentInfoBean stdInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isAdded = false;
		try {
			tran.begin();
			em.persist(stdInfo);
			tran.commit();
			isAdded = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return isAdded;
	}// end of addStudent()

	@Override
	public boolean updateStudent(StudentInfoBean stdInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isUpdated = false;
		StudentInfoBean stdInfo2 = em.find(StudentInfoBean.class, stdInfo.getStdId());
		if (stdInfo2 != null) {
			if (stdInfo.getEmail() != null) {
				stdInfo2.setEmail(stdInfo.getEmail());
			}
		}
		try {
			tran.begin();
			em.persist(stdInfo2);
			tran.commit();
			isUpdated = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();

		return isUpdated;
	}// end of updateStudent()

	@Override
	public boolean deleteStudent(int stdId) {
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			StudentInfoBean studentInfoBean = entityManager.find(StudentInfoBean.class, stdId);
			entityManager.remove(studentInfoBean);
			tx.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		return isDeleted;
	}// end of deleteStudent()

	@Override
	public double aggregateMarks(int stdId) {
		EntityManager em = emf.createEntityManager();

		String jpql = "select year1Marks+year2Marks+year3Marks+year4Marks/4 from StudentInfoBean where stdId=:id";
		Query query = em.createQuery(jpql);
		query.setParameter("id", stdId);
		double agg = query.getFirstResult();

		return agg;
	}

	
}
