package com.capgemini.mpt3.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_info")
public class StudentInfoBean {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stdId;
	@Column
	private String stdName;
	@Column
	private String email;
	@Column
	private double year1Marks;
	@Column
	private double year2Marks;
	@Column
	private double year3Marks;
	@Column
	private double year4Marks;
	
	//Getters and Setters
	
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getYear1Marks() {
		return year1Marks;
	}
	public void setYear1Marks(double year1Marks) {
		this.year1Marks = year1Marks;
	}
	public double getYear2Marks() {
		return year2Marks;
	}
	public void setYear2Marks(double year2Marks) {
		this.year2Marks = year2Marks;
	}
	public double getYear3Marks() {
		return year3Marks;
	}
	public void setYear3Marks(double year3Marks) {
		this.year3Marks = year3Marks;
	}
	public double getYear4Marks() {
		return year4Marks;
	}
	public void setYear4Marks(double year4Marks) {
		this.year4Marks = year4Marks;
	}
	
}//end of  bean class
