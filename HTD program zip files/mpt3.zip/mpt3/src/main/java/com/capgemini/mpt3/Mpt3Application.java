package com.capgemini.mpt3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mpt3Application {

	public static void main(String[] args) {
		SpringApplication.run(Mpt3Application.class, args);
	}

}
