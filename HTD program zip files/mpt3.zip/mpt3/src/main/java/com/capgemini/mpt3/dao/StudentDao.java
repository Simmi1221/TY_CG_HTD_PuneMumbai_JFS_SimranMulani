package com.capgemini.mpt3.dao;

import com.capgemini.mpt3.beans.StudentInfoBean;

public interface StudentDao {

	public StudentInfoBean getStudent(int stdId);

	public boolean addStudent(StudentInfoBean stdInfo);

	public boolean updateStudent(StudentInfoBean stdInfo);

	public boolean deleteStudent(int stdId);
	
	public double aggregateMarks(int stdId);
	

}
