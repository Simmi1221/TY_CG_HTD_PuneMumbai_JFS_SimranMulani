package com.capgemini.mpt3.service;

import com.capgemini.mpt3.beans.StudentInfoBean;

public interface StudentService {
	
	public StudentInfoBean getStudent(int stdId);

	public boolean addStudent(StudentInfoBean stdInfo);

	public boolean updateStudent(StudentInfoBean stdInfo);

	public boolean deleteStudent(int stdId);
	
	public double aggregateMarks(int stdId);

}
