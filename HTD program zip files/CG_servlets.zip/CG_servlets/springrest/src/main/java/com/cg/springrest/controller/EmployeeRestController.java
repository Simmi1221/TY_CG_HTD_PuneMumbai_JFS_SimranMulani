package com.cg.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springrest.beans.EmployeeInfo;
import com.cg.springrest.beans.EmployeeResponse;
import com.cg.springrest.service.EmployeeService;

//@Controller
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRestController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/getEmployee")
	// @ResponseBody
	public EmployeeResponse getAllEmployees(int empId) {
		EmployeeInfo employeeInfo = service.getEmployee(empId);
		EmployeeResponse response = new EmployeeResponse();
		if (employeeInfo != null) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Employee record found.....");
			response.setEmployeeInfo(employeeInfo);
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
		}
		return response;
	}// end of getAllEmployees()

	@PutMapping(path = "/addEmployee", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = MediaType.APPLICATION_XML_VALUE)
	// @ResponseBody
	public EmployeeResponse addEmployee(@RequestBody EmployeeInfo employeeInfo) {
		boolean isAdded = service.addEmployee(employeeInfo);
		EmployeeResponse response = new EmployeeResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Employee added successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to add Employee!!!");
		}

		return response;
	}// end of addEmployee()

	@DeleteMapping(path = "/deleteEmployee", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public EmployeeResponse deleteEmployee(int empId) {
		boolean isDeleted = service.deleteEmployee(empId);
		EmployeeResponse response = new EmployeeResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Employee record deleted successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete record of  Employee!!!");
		}

		return response;
	}

	@PostMapping(path = "/updateEmployee", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public EmployeeResponse updateEmployee(@RequestBody EmployeeInfo employeeInfo) {
		boolean isUpdated = service.updateEmployee(employeeInfo);
		EmployeeResponse response = new EmployeeResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Employee record updated successfully.....");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDescription("Unable to update record of  Employee!!!");
		}

		return response;
	}

	@GetMapping(path = "/getAllEmployees", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public EmployeeResponse getAllEmployees() {
		List<EmployeeInfo> employeesList = service.getAllEmployees();
		EmployeeResponse response = new EmployeeResponse();
		if (employeesList != null && !employeesList.isEmpty()) {

			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Employee record found.....");
		}else {
			response.setEmployeesList(employeesList);
			response.setStatusCode(401);
			response.setMessage("failed");
		}
		return response;
	}

}// end of controller
