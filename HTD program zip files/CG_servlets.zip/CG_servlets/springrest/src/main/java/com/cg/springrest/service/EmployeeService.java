package com.cg.springrest.service;

import java.util.List;

import com.cg.springrest.beans.EmployeeInfo;

public interface EmployeeService {

	public EmployeeInfo getEmployee(int empId);
	public EmployeeInfo authenticate(int empId, String pwd);
	public boolean  addEmployee(EmployeeInfo empInfo);
	public boolean updateEmployee(EmployeeInfo empInfo);
	public boolean deleteEmployee(int empId);
	public List<EmployeeInfo> getAllEmployees();
}
