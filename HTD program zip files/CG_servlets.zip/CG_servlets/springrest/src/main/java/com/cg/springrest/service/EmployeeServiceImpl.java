package com.cg.springrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springrest.beans.EmployeeInfo;
import com.cg.springrest.dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO dao;
	
	@Override
	public EmployeeInfo getEmployee(int empId) {
       if(empId>0) {		 
		return dao.getEmployee(empId);
       }else {
    	   return null;
       }
       
	}

	@Override
	public EmployeeInfo authenticate(int empId, String pwd) {
		return dao.authenticate(empId, pwd);
	}

	@Override
	public boolean addEmployee(EmployeeInfo empInfo) {
		return dao.addEmployee(empInfo);
	}

	@Override
	public boolean updateEmployee(EmployeeInfo empInfo) {
		return dao.updateEmployee(empInfo);
	}
	
	@Override
	public boolean deleteEmployee(int empId) {
		return dao.deleteEmployee(empId);
	}

	@Override
	public List<EmployeeInfo> getAllEmployees() {
		return dao.getAllEmployees();
	}
	
	

}//end of class
