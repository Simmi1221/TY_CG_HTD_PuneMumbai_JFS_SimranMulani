package com.cg.springrest.beans;

import java.util.List;

public class EmployeeResponse {
	
	private int statusCode;
	private String message;
	private String description;
	private EmployeeInfo employeeInfo;
	private List<EmployeeInfo> employeesList;
	
	//Getters and Setters
	
	public EmployeeInfo getEmployeeInfo() {
		return employeeInfo;
	}
	public void setEmployeeInfo(EmployeeInfo employeeInfo) {
		this.employeeInfo = employeeInfo;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public List<EmployeeInfo> getEmployeesList() {
		return employeesList;
	}
	public void setEmployeesList(List<EmployeeInfo> employeesList) {
		this.employeesList = employeesList;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}//end of class
