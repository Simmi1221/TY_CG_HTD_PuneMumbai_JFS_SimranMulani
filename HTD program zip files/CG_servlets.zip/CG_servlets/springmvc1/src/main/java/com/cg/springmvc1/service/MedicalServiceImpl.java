package com.cg.springmvc1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc1.DAO.MedicalDAO;
import com.cg.springmvc1.beans.AdminMsgBox;
import com.cg.springmvc1.beans.AuthenticateBean;
import com.cg.springmvc1.beans.CartInfoBean;
import com.cg.springmvc1.beans.OrderInfoBean;
import com.cg.springmvc1.beans.ProductInfoBean;
import com.cg.springmvc1.beans.UserInfoBean;
import com.cg.springmvc1.beans.UserMsgBox;

@Service
public class MedicalServiceImpl implements MedicalService{

	@Autowired
	private MedicalDAO dao;
	
	@Override
	public int adminAuthenticate(String username, String password) {
		return dao.adminAuthenticate(username, password);
	}

	@Override
	public boolean addProduct(ProductInfoBean productInfobean) {
		return dao.addProduct(productInfobean);
	}

	@Override
	public boolean updateProduct(ProductInfoBean productInfoBean) {
		return dao.updateProduct(productInfoBean);
	}

	@Override
	public boolean deleteProduct(int prodId) {
		return dao.deleteProduct(prodId);
	}

	@Override
	public List<ProductInfoBean> listOfProducts() {
		return dao.listOfProducts();
	}

	@Override
	public boolean userRegistration(UserInfoBean bean) {
		return dao.userRegistration(bean);
	}

	@Override
	public int userAuthenticate(String username, String password) {
		return dao.userAuthenticate(username, password);
	}

	@Override
	public List<UserInfoBean> listOfUser() {
		return dao.listOfUser();
	}

	@Override
	public boolean updateUserProfile(int userId,UserInfoBean userInfoBean) {
		return dao.updateUserProfile(userId,userInfoBean);
	}
	
	@Override
	public boolean addToCart(int userId, int quantity, String productName, CartInfoBean cartInfoBean) {
		return dao.addToCart(userId, quantity, productName, cartInfoBean);
	}
	
	@Override
	public List<CartInfoBean> listOfSelectedProducts() {
		return dao.listOfSelectedProducts();
	}

	
	@Override
	public boolean deleteFromcart(int cartId) {
		return dao.deleteFromcart(cartId);
	}

	
	@Override
	public double payment(int userId) {
		return dao.payment(userId);
	}

	@Override
	public List<UserMsgBox> seeAllSentMessage(int adminId) {
		return dao.seeAllSentMessage(adminId);
	}

	@Override
	public List<AdminMsgBox> seeAllSentMessages(int userId) {
		return dao.seeAllSentMessages(userId);
	}

	@Override
	public boolean ReplyToUser(int adminId,int userId, String message) {
		return dao.ReplyToUser(adminId,userId, message);
	}

	@Override
	public boolean sendMessageToAdmin(int userId, String message) {
		return dao.sendMessageToAdmin(userId, message);
	}

	@Override
	public boolean placeOrder(int userId) {
		return dao.placeOrder(userId);
	}

	@Override
	public List<OrderInfoBean> generateReport() {
		return dao.generateReport();
	}

}
