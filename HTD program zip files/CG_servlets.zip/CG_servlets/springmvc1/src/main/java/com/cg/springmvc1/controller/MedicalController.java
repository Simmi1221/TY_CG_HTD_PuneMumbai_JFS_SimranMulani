package com.cg.springmvc1.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.cg.springmvc1.beans.AdminMsgBox;
import com.cg.springmvc1.beans.AuthenticateBean;
import com.cg.springmvc1.beans.CartInfoBean;
import com.cg.springmvc1.beans.OrderInfoBean;
import com.cg.springmvc1.beans.ProductInfoBean;
import com.cg.springmvc1.beans.UserInfoBean;
import com.cg.springmvc1.beans.UserMsgBox;
import com.cg.springmvc1.service.MedicalService;

@Controller
public class MedicalController {

	@Autowired(required = true)
	private MedicalService service;

	@GetMapping("/homePage")
	public String displayHome() {
		return "homePage";
	}// end of displayHome()

	@GetMapping("/loginForm")
	public String displayLoginForm() {
		return "loginForm";
	}// end of displayLoginForm()

	int adminId = 0;
	int userId = 0;

	@PostMapping("/login")
	public String login(String username, String password, String alogin, HttpServletRequest req, ModelMap modelMap) {

		if (alogin.equals("administrator")) {

			adminId = service.adminAuthenticate(username, password);

			if (adminId != 0) {
				HttpSession session = req.getSession(true);
				session.setAttribute("adminInfoBean", adminId);
				modelMap.addAttribute("msg","Logged in successfully....");
				return "adminHomePage";
			} else {
				modelMap.addAttribute("msg", "Invalid Credentials!!!");
				return "loginForm";
			}
		} else {
			userId = service.userAuthenticate(username, password);

			if (userId != 0) {
				HttpSession session = req.getSession(true);
				modelMap.addAttribute("msg","Logged in successfully....");
				session.setAttribute("userInfoBean", userId);
				return "userHomePage";
			} else {
				modelMap.addAttribute("msg", "Invalid Credentials!!!");
				return "loginForm";
			}
		}
	} // end of login()

	@GetMapping("/addProductForm")
	public String displayAddProductForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!!");
			return "loginForm";
		} else {
			return "addProductForm";
		}
	}// end of displayAddProductForm()

	@PostMapping("/addProduct")
	public String addProduct(ProductInfoBean productInfoBean, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Plese login First!!!");
			return "loginForm";
		} else {
			if (service.addProduct(productInfoBean)) {
				modelMap.addAttribute("msg", "Product Added Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to add Product!!!");
			}
		}
		return "addProductForm";
	}// end of addProduct()

	@GetMapping("/updateProductForm")
	public String displayUpdateProductForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First...");
			return "loginForm";
		} else {
			return "updateProductForm";
		} // end of displayUpdateProductForm()
	}

	@PostMapping("/updateProduct")
	public String updateProduct(ProductInfoBean productInfoBean, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			return "loginForm";
		} else {
			if (service.updateProduct(productInfoBean)) {
				modelMap.addAttribute("msg", "Product details updated successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to update the details!!!");
			}
		}

		return "updateProductForm";
	}// end of updateProduct()

	@GetMapping("/deleteProductForm")
	public String displayDeleteProductForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			return "deleteProductForm";
		}
	}// End of displayDeleteProductForm()

	@GetMapping("/deleteProduct")
	public String deleteProduct(int prodId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			if (service.deleteProduct(prodId)) {
				modelMap.addAttribute("msg", "Product Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "Product ID " + prodId + " Not Found!");
			}

			return "deleteProductForm";
		}
	}// End of deleteProduct()

	@GetMapping("/listOfProducts")
	public String listOfProducts(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<ProductInfoBean> productsList = service.listOfProducts();
			modelMap.addAttribute("productsList", productsList);

			return "listOfProducts";
		}
	}// End of listOfProducts()

	@GetMapping("/listOfUsers")
	public String ListOfUsers(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<UserInfoBean> usersList = service.listOfUser();
			modelMap.addAttribute("usersList", usersList);

			return "listOfUsers";
		}
	}// End of listOfUsers()

	@GetMapping("/listOfProductsForUser")
	public String listOfProductsForUser(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<ProductInfoBean> productsList = service.listOfProducts();
			modelMap.addAttribute("productsList", productsList);

			return "listOfProductsForUser";
		}
	}// End of listOfProductsForUser()

	@GetMapping("/generateReport")
	public String generateReport(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<OrderInfoBean> orderList = service.generateReport();
			modelMap.addAttribute("orderList", orderList);

			return "report";
		}
	}// End of generateReport()
	
	@GetMapping("/updateUserProfileForm")
	public String displayUpdateUserProfileForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First...");
			return "loginForm";
		} else {
			return "updateUserProfileForm";
		} // end of displayUpdateUserProfileForm()
	}

	@PostMapping("/updateUserProfile")
	public String updateUserProfile(UserInfoBean userInfoBean, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			return "loginForm";
		} else {
			if (service.updateUserProfile(userId, userInfoBean)) {
				modelMap.addAttribute("msg", "User Profile updated successfully");
			} else {
				modelMap.addAttribute("msg", "User not found!!!");
			}
		}

		return "userHomePage";
	}// end of updateUserProfile()

	@GetMapping("/registrationForm")
	public String displayRegistrationForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Register First!!!");
			return "homePage";
		} else {
			return "registrationForm";
		}
	}// end of displayRegistrationForm()

	@PostMapping("/registration")
	public String registration(UserInfoBean bean, ModelMap modelMap) {

		if (service.userRegistration(bean)) {
			modelMap.addAttribute("msg", "Registerd Successfully...");
		} else {
			modelMap.addAttribute("msg", "Unable to regester!!!");
		}
		return "loginForm";
	}// end of registration()

	@GetMapping("/addToCartForm")
	public String displayAddToCartForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!!");
			return "loginForm";
		} else {
			return "addToCartForm";
		}
	}// end of displayAddProductForm()

	@PostMapping("/addToCart")
	public String addToCart(String productName, int quantity, CartInfoBean cartInfoBean, HttpSession session,
			ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First!!!");
			return "homePage";
		} else {
			if (service.addToCart(userId, quantity, productName, cartInfoBean)) {
				modelMap.addAttribute("msg", "Product added into cart Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to add product into cart!!!");
			}
		}
		return "addToCartForm";
	}

	@GetMapping("/displayCart")
	public String listOfSelectedProducts(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<CartInfoBean> productsList = service.listOfSelectedProducts();
			modelMap.addAttribute("productList", productsList);

			return "displayCart";
		}
	}// End of listOfProducts()

	@GetMapping("/cartAction")
	public String displayDeleteFromCartForm(String onClick, HttpSession session, ModelMap modelMap) {
		if (onClick.equals("delete")) {
			if (session.isNew()) {
				// Invalid Session
				modelMap.addAttribute("msg", "Please Login First");
				return "loginForm";

			} else {
				// Valid Session
				return "deleteFromCartForm";
			}
		} else {
			if (session.isNew()) {
				// Invalid Session
				modelMap.addAttribute("msg", "Please Login First");
				return "loginForm";

			} else {
				// Valid Session
				boolean isOrdered=service.placeOrder(userId);
				double bill = service.payment(userId);
				if (bill != 0 && isOrdered) {
					modelMap.addAttribute("bill", bill);
					modelMap.addAttribute("order",isOrdered);
				} else {
					modelMap.addAttribute("msg1", "Please add the product into cart first!!!");
				}

				return "paymentPage";
			}

		}
	}// End of displayDeleteFromCartForm()

	@GetMapping("/deleteFromCart")
	public String deleteFromCart(int cartId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			if (service.deleteFromcart(cartId)) {
				modelMap.addAttribute("msg", "Product Deleted from cart Successfully!");
			} else {
				modelMap.addAttribute("msg", "Product ID " + cartId + " Not Found!");
			}

			return "deleteFromCartForm";
		}
	}// End of deleteProduct()

	@GetMapping("/msgForm")
	public String displayMsgForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!!");
			return "loginForm";
		} else {
			return "msgForm";
		}
	}// end of displayMsgForm()

	@PostMapping("/sendMsgToAdmin")
	public String sendMsgToAdmin(String message, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First!!!");
			return "homePage";
		} else {
			if (service.sendMessageToAdmin(userId, message)) {
				modelMap.addAttribute("msg", "Message send to admin Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to send the message!!!");
			}
		}
		return "msgForm";
	}

	@GetMapping("/inboxForUser")
	public String inboxOfUser(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<AdminMsgBox> messageList = service.seeAllSentMessages(userId);
			modelMap.addAttribute("messageList", messageList);

			return "inboxForUser";
		}
	}// End of inboxOfUser()

	@GetMapping("/msgFormForAdmin")
	public String displayMsgFormForUser(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!!");
			return "loginForm";
		} else {
			return "msgFormForAdmin";
		}
	}// end of displayMsgForm()

	@PostMapping("/replyToUser")
	public String replyToUser(String message, int userId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First!!!");
			return "adminHomePage";
		} else {
			if (service.ReplyToUser(adminId, userId, message)) {
				modelMap.addAttribute("msg", "Message send to user Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to send the message!!!");
			}
		}
		return "msgFormForAdmin";
	}

	@GetMapping("/inboxForAdmin")
	public String inboxOfAdmin(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "loginForm";

		} else {
			// Valid Session
			List<UserMsgBox> messageList = service.seeAllSentMessage(adminId);
			modelMap.addAttribute("messageList", messageList);

			return "inboxForAdmin";
		}
	}// End of inboxOfAdmin()

	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap) {
		session.invalidate();
		modelMap.addAttribute("msg", "Logout Successfully....");
		return "homePage";
	}// end of logout()

}
