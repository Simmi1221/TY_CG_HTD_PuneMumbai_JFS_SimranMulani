package com.cg.springmvc1.DAO;

import java.util.List;

import com.cg.springmvc1.beans.AdminMsgBox;
import com.cg.springmvc1.beans.AuthenticateBean;
import com.cg.springmvc1.beans.CartInfoBean;
import com.cg.springmvc1.beans.OrderInfoBean;
import com.cg.springmvc1.beans.ProductInfoBean;
import com.cg.springmvc1.beans.UserInfoBean;
import com.cg.springmvc1.beans.UserMsgBox;

public interface MedicalDAO {
	
	public int adminAuthenticate(String username,String password);
	public boolean addProduct(ProductInfoBean productInfobean);
	public boolean updateProduct(ProductInfoBean productInfoBean);
	public boolean deleteProduct(int prodId);
	public List<ProductInfoBean> listOfProducts();
	public List<UserInfoBean> listOfUser();
	public boolean ReplyToUser(int adminId,int userId,String message);
	public List<UserMsgBox> seeAllSentMessage(int adminId);
	public List<OrderInfoBean> generateReport();
	
	public boolean userRegistration(UserInfoBean bean);
	public int userAuthenticate(String username ,String password);
	public boolean updateUserProfile(int userId,UserInfoBean userInfoBean);
	public boolean addToCart(int userId,int quantity,String productName,CartInfoBean cartInfoBean);
	public List<CartInfoBean> listOfSelectedProducts();
	public boolean deleteFromcart(int cartId);
	public boolean placeOrder(int userId);
	public double payment(int userId);
	public boolean sendMessageToAdmin(int userId,String message);
	public List<AdminMsgBox> seeAllSentMessages(int userId);
	
	

}
