package com.cg.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.empwebapp.beans.EmployeeInfo;
import com.cg.empwebapp.dao.EmployeeDAO;
import com.cg.empwebapp.dao.EmployeeDAOJpaImpl;

@WebServlet("/updateEmployee")
public class UpdateEmployeeServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession(false);
		if (session != null) {
			// valid session
			// Get the form data
			int empId = Integer.parseInt(req.getParameter("empId"));
			String empName = req.getParameter("empName");
			int age = Integer.parseInt(req.getParameter("age"));
			String password = req.getParameter("password");
			long mobile = Long.parseLong(req.getParameter("mobile"));
			String designation = req.getParameter("designation");
			String gender = req.getParameter("gender");
			double salary = Double.parseDouble(req.getParameter("salary"));

			EmployeeInfo empInfo = new EmployeeInfo();
			empInfo.setEmpId(empId);
			empInfo.setEmpName(empName);
			empInfo.setAge(age);
			empInfo.setPassword(password);
			empInfo.setMobile(mobile);
			empInfo.setDesignation(designation);
			empInfo.setSalary(salary);
			empInfo.setGender(gender);

			
			EmployeeDAO dao = new EmployeeDAOJpaImpl();
			boolean isUpdated = dao.updateEmployee(empInfo);

			out.println("<html>");
			out.println("<body>");
			if (isUpdated) {
				out.println("<h2>Updated Record Successfully....</h2>");
			} else {
				out.println("<h2 style='color:red'>Unable to update employee record!!!!</h2>");
			}
			out.println("</body>");
			out.println("</html>");

		} else {
            //invalid session
			out.println("<html>");
			out.println("<body>");
			out.println("<h2 style ='color:red'> Please Login First!!!</h2>");
			out.println("</body>");
			out.println("</html>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("./LoginForm.html");
			dispatcher.include(req, resp);
		}

	}// end of doPost()


}
