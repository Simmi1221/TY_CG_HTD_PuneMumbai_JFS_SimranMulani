package com.cg.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.empwebapp.beans.EmployeeInfo;
import com.cg.empwebapp.dao.EmployeeDAO;
import com.cg.empwebapp.dao.EmployeeDAOJpaImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get the form data
		int empIdVal = Integer.parseInt(req.getParameter("empId"));
		String password = req.getParameter("password");

		EmployeeDAO dao = new EmployeeDAOJpaImpl();
		EmployeeInfo empInfo = dao.authenticate(empIdVal, password);
 
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		
		RequestDispatcher dispatcher = null;
		if (empInfo != null) {
			// Valid credentials
			HttpSession session = req.getSession(true);
			session.setMaxInactiveInterval(5000);
			session.setAttribute("empInfo", empInfo);
			
			out.println("<h2>Hello...." + empInfo.getEmpName() + "</h2>");
			dispatcher = req.getRequestDispatcher("./homePage.html");
			
		} else {
			// invalid credentials
			out.println("<h2 style='color:red'>Invalid Credentials</h2>");
			dispatcher = req.getRequestDispatcher("./LoginForm.html");
		}
		dispatcher.include(req, resp);
		
		out.println("</body>");
		out.println("</html>");
	}// end of doPost()

}// end of class
