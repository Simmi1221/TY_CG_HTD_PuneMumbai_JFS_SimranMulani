package com.cg.empwebapp.dao;

import com.cg.empwebapp.beans.EmployeeInfo;

public interface EmployeeDAO {

	public EmployeeInfo getEmployee(int empId);
	public EmployeeInfo authenticate(int empId, String pwd);
	public boolean  addEmployee(EmployeeInfo empInfo);
	public boolean updateEmployee(EmployeeInfo empInfo);

}// end of class
