package com.cg.empwebapp.servlets; 

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlet extends HttpServlet {
	
	 public DateServlet() {
		System.out.println("Its instantiation phase......");
	}
	 
	 @Override
	public void init() throws ServletException {
		System.out.println("Is's initialization phase.....");
		super.init();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("It's service phase....");
		Date date = new Date();
		
		ServletContext context=getServletContext();
		String companyNameval=context.getInitParameter("companyName");

		//resp.setHeader("refresh", "1");
		resp.setContentType("text/html");

		PrintWriter out = resp.getWriter();
		out.println("<html>");
		//out.println("<head>");
		//out.println("<meta http-equiv='refresh' content='1'>");//auto reload page after 1 second
		//out.println("</head>");
		out.println("<body>");
		out.println("<h1>Current System Date and Time-<br>");
		out.println(date + "</h1>");
		out.println("<h3>Context param value is- "+ companyNameval +"<h3>");
		out.println("</body>");
		out.println("</html>");
	}// End of doGet
	
	@Override
	public void destroy() {
		System.out.println("it's destroy phase....");
		super.destroy();
	}

}// End of class
