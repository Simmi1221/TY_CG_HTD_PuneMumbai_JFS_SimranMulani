package com.cg.empwebapp.dao;

import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.empwebapp.beans.EmployeeInfo;

public class EmployeeDAOJpaImpl implements EmployeeDAO {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee");

	@Override
	public EmployeeInfo getEmployee(int empId) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employee");
		EntityManager em = emf.createEntityManager();
		EmployeeInfo empInfo = em.find(EmployeeInfo.class, empId);
		em.close();

		return empInfo;
	}// end of getEmployee()

	@Override
	public EmployeeInfo authenticate(int empId, String pwd) {

		EntityManager em = emf.createEntityManager();
		String jpql = "from EmployeeInfo where empId=:empId and password=:pwd";
		Query query = em.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("pwd", pwd);

		EmployeeInfo empInfo = null;
		try {
			empInfo = (EmployeeInfo) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return empInfo;
	}// end of authenticate()

	@Override
	public boolean addEmployee(EmployeeInfo empInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isAdded=false;
		try {
			tran.begin();
			em.persist(empInfo);
			tran.commit();
			isAdded=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
         em.close();
		return isAdded;
	}// end of addEmployee

	@Override
	public boolean updateEmployee(EmployeeInfo empInfo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tran = em.getTransaction();
		boolean isUpdated=false;
			EmployeeInfo empInfo1=em.find(EmployeeInfo.class, empInfo.getEmpId());
			if(empInfo1!=null) {
				if(empInfo.getEmpName()!=null) {
					empInfo1.setEmpName(empInfo.getEmpName());
				}if(empInfo.getAge()!=0) {
					empInfo1.setAge(empInfo.getAge());
				}if(empInfo.getDesignation()!=null) {
					empInfo1.setDesignation(empInfo.getDesignation());
				}if(empInfo.getGender()!=null) {
					empInfo1.setGender(empInfo.getGender());
				}if(empInfo.getMobile()!=0) {
					empInfo1.setMobile(empInfo.getMobile());
				}if(empInfo.getSalary()!=0) {
					empInfo1.setSalary(empInfo.getSalary());
				}
			}
			try {
			tran.begin();
			em.persist(empInfo1);
			tran.commit();
			isUpdated=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
         em.close();
		
		return isUpdated;
	}

}// end of class
