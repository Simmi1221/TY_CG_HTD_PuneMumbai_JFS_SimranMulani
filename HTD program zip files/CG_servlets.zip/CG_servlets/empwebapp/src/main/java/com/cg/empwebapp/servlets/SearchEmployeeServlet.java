package com.cg.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empwebapp.beans.EmployeeInfo;
import com.cg.empwebapp.dao.EmployeeDAO;
import com.cg.empwebapp.dao.EmployeeDAOJpaImpl;

@WebServlet("/searchEmployee")
public class SearchEmployeeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String empIdVal = req.getParameter("empId");
		int empId = Integer.parseInt(empIdVal);

		EmployeeDAO dao = new EmployeeDAOJpaImpl();
		EmployeeInfo emp = dao.getEmployee(empId);

		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		out.println("<html>");
		out.println("<body>");

		if (emp != null) {
			out.println("<h2>Employee_Id " + "Found-<h2>");
			out.println("Employee Name: " + emp.getEmpName());
			out.println("<br>Age: " + emp.getAge());
			out.println("<br>Mobile: " + emp.getMobile());
			out.println("<br>Salary: " + emp.getSalary());
			out.println("<br>Gender: " + emp.getGender());
			out.println("<br>Designation: " + emp.getDesignation());
			out.println("<br>Password: " + emp.getPassword());
		} else {
			// display error msg
			out.println("<h3 style='color:red'> Employee Id " + empId + "Not Found!!!");
		}

		out.println("</html>");
		out.println("</body>");

	}// end of class
}
