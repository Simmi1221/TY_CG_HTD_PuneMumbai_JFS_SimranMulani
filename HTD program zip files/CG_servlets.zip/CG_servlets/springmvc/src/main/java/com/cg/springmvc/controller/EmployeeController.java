package com.cg.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.cg.springmvc.beans.EmployeeInfo;
import com.cg.springmvc.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/empLoginForm")
	public String displayEmpLoginForm() {
		return "employeeLoginForm";
	}// end of displayEmpLoginForm()

	@PostMapping("/empLogin")
	public String empLogin(int empId, String password, ModelMap modelMap, HttpServletRequest req) {
		EmployeeInfo employeeInfo = service.authenticate(empId, password);
		if (employeeInfo != null) {
			HttpSession session = req.getSession(true);
			session.setAttribute("employeeInfo", employeeInfo);
			return "empHomePage";
		} else {
			modelMap.addAttribute("msg", "Invalid Credentials...");
			return "employeeLoginForm";
		}
	}// end of empLogin()

	@GetMapping("/addEmployeeForm")
	public String displayAddEmpForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!!");
			return "employeeLoginForm";
		} else {
			return "addEmployee";
		}
	}// end of displayAddEmpForm()

	@PostMapping("/addEmployee")
	public String addEmployee(EmployeeInfo employeeInfo, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Plese login First!!!");
			return "empLoginForm";
		} else {
			if (service.addEmployee(employeeInfo)) {
				modelMap.addAttribute("msg", "Employee Added Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to add Employee");
			}
		}
		return "addEmployee";
	}// end of addEmployee()

	@GetMapping("/updateEmployeeForm")
	public String displayUpdateEmpForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login First...");
			return "employeeLoginForm";
		} else {
			return "updateEmployee";
		} // end of displayUpdateEmpForm()
	}

	@PostMapping("/updateEmployee")
	public String updateEmployee(EmployeeInfo employeeInfo, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			return "employeeLoginForm";
		} else {
			if (service.updateEmployee(employeeInfo)) {
				modelMap.addAttribute("msg", "Employee details updated successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to update the details");
			}
		}

		return "updateEmployee";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap) {
		session.invalidate();
		modelMap.addAttribute("msg", "Successfully logged out...");
		return "employeeLoginForm";
	}// end of logout()

	@GetMapping("/searchEmployeeForm")
	public String displaySearchEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			// Valid Session
			return "searchEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()
	
	@GetMapping("/searchEmployee")
	public String searchEmployee(int empId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			EmployeeInfo employeeInfoBean = service.getEmployee(empId);
			if (employeeInfoBean != null) {
				modelMap.addAttribute("employeeInfoBean", employeeInfoBean);
			} else {
				modelMap.addAttribute("msg", "Employee ID " + empId + " Not Found!!!");
			}
			
			return "searchEmployeeForm";
		}
	}// End of searchEmployee()
	
	@GetMapping("/deleteEmployeeForm")
	public String displayDeleteEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			// Valid Session
			return "deleteEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()
	
	@GetMapping("/deleteEmployee")
	public String deleteEmployee(int empId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			// Valid Session
			if(service.deleteEmployee(empId)) {
				modelMap.addAttribute("msg", "Employee Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "Employee ID " + empId + " Not Found!");
			}
			
			return "deleteEmployeeForm";
		}
	}// End of searchEmployee()
	
	@GetMapping("/seeAllEmployees")
	public String getAllEmployees(HttpSession session, ModelMap modelMap) {
		
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			// Valid Session
			List<EmployeeInfo> employeesList = service.getAllEmployees();
			modelMap.addAttribute("employeesList", employeesList);
			
			return "displayAllEmployees";
		}
	}// End of getAllEmployees()
	
	@GetMapping("/home")
	public String displayEmpHomePage(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "employeeLoginForm";
		
		} else {
			// Valid Session
			return "empHomePage";
		}
	}// End of displayEmpHomePage()
}// end of class
