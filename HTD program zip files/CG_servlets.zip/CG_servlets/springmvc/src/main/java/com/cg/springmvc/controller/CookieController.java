package com.cg.springmvc.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CookieController {

	@GetMapping("/cookiePage")
	public String displayCookiePage() {

		return "cookiePage";
	}// end of displayCookiePage()
	
	@GetMapping("/createCookie")
	public String createCookie(HttpServletResponse resp,ModelMap modelMap) {
		Cookie cookie=new Cookie("name","Simran");
		resp.addCookie(cookie);
		modelMap.addAttribute("msg","Cookie cerated successfully.....");
		return "cookiePage";
		
	}//end of createCookie
	
	@GetMapping("/readCookie")
	public String raedCookie(@CookieValue(name="name") String name, ModelMap modelMap) {
		modelMap.addAttribute("msg","Cookie value is "+name);
		return "cookiePage";
	}

}// end of class
