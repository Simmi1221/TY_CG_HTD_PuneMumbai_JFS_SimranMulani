package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cg.springcore.annotatio.bean.MessageBean;

@Configuration
public class MessageConfig {
	
	@Bean
	@Scope("prototype")
	public MessageBean messageBean() {
		MessageBean messageBean=new MessageBean();
		messageBean.setMessage("Hello EveryBody....Good Morning.....Have a Nice Day!!!");
		return messageBean;
	}//end of messgeBean()
}//end of class
