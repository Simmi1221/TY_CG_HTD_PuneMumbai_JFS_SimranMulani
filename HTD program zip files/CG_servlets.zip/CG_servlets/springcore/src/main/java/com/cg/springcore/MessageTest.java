package com.cg.springcore;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.beans.MessageBean;

public class MessageTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		//((AbstractApplicationContext)context).registerShutdownHook();-->we can use this method to close the container anywhere in program
		
		MessageBean mb=(MessageBean)context.getBean("messageBean");
		System.out.println(mb.getMessage());
		
		((AbstractApplicationContext)context).close();//this is another way to close the container but we have to use close() after using container object
		
	}//end of main()

}//end of class
