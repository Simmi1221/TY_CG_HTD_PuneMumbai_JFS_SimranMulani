package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.cg.springcore.annotatio.bean.Pet;

@Import(AnimalConfig.class)
@Configuration
public class PetConfig {
	
	@Bean
	public Pet getPet() {
		Pet pet=new Pet();
		pet.setName("Pappu");
		return pet;
		
	}//end of getPet()

}//end of class
