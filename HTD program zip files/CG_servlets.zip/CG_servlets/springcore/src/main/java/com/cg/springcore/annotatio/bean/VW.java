package com.cg.springcore.annotatio.bean;

import com.cg.springcore.interfaces.Engine;

public class VW implements Engine {

	@Override
	public int getCC() {
		return 1300;
	}

	@Override
	public String getType() {
		return "4-stroke diesel";
	}

}
