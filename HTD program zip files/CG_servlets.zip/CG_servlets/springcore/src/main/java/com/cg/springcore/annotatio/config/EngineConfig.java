package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.cg.springcore.annotatio.bean.VW;
import com.cg.springcore.annotatio.bean.iSuzu;
import com.cg.springcore.interfaces.Engine;

@Configuration
public class EngineConfig {
	
	@Bean(name="iSuzu")
	@Primary
	public Engine getISuzu() {
		return new iSuzu();
	}

	@Bean(name="VW")
	public Engine getVW() {
		return new VW();
	}
}//end of class
