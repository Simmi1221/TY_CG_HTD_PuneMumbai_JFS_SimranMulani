package com.cg.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.beans.MobileBean;

public class MobileTest {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("mobileConfig.xml");
		MobileBean mb = context.getBean("mobile", MobileBean.class);

		System.out.println("Brand name : " + mb.getBrandName());
		System.out.println("Model name : " + mb.getModelName());
		System.out.println("Price      : " + mb.getPrice());
		System.out.println("DisplaySize: " + mb.getDisplayBean().getDisplaysize());
		System.out.println("resolution : " + mb.getDisplayBean().getResolution());
		System.out.println("----------------------------------------------------");

		MobileBean mb1 = context.getBean("mobile1", MobileBean.class);

		System.out.println("Brand name : " + mb1.getBrandName());
		System.out.println("Model name : " + mb1.getModelName());
		System.out.println("Price      : " + mb1.getPrice());
		System.out.println("DisplaySize: " + mb1.getDisplayBean().getDisplaysize());
		System.out.println("resolution : " + mb1.getDisplayBean().getResolution());
		System.out.println("----------------------------------------------------");
		
		MobileBean mb2 = context.getBean("mobile2", MobileBean.class);

		System.out.println("Brand name : " + mb2.getBrandName());
		System.out.println("Model name : " + mb2.getModelName());
		System.out.println("Price      : " + mb2.getPrice());
		System.out.println("DisplaySize: " + mb2.getDisplayBean().getDisplaysize());
		System.out.println("resolution : " + mb2.getDisplayBean().getResolution());
	}

}
