package com.cg.springcore.beans;

public class MobileDisplayBean {
	private double displaysize;
	private String resolution;
	
	public double getDisplaysize() {
		return displaysize;
	}
	public void setDisplaysize(double displaysize) {
		this.displaysize = displaysize;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	
	
	

}
