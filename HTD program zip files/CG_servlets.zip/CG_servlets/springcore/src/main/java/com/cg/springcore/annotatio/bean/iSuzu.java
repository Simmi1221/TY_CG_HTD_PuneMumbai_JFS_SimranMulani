package com.cg.springcore.annotatio.bean;

import com.cg.springcore.interfaces.Engine;

public class iSuzu  implements Engine{

	@Override
	public int getCC() {
		return 1700;
	}

	@Override
	public String getType() {
		return "4-stroke Petrol";
	}

}
