package com.cg.springcore;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.beans.EmployeeBean;

public class EmployeeTest2 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		ApplicationContext context=new ClassPathXmlApplicationContext("EmployeeConfig.xml");
		
		EmployeeBean emp1=context.getBean("employee", EmployeeBean.class);
		System.out.print("Enter the employee Id:");
		int empId=Integer.parseInt(sc.nextLine());
		System.out.print("enter the employee name:");
		String name=sc.nextLine();
		
		emp1.setEmpId(empId);
		emp1.setEmpName(name);
		
		EmployeeBean emp2=context.getBean("employee", EmployeeBean.class);
		System.out.print("Enter the employee Id:");
		int empId2=Integer.parseInt(sc.nextLine());
		System.out.print("enter the employee name:");
		String name2=sc.nextLine();
		
		emp2.setEmpId(empId2);
		emp2.setEmpName(name2);
		
		System.out.println(emp1.getEmpId());
		System.out.println(emp1.getEmpName());
		System.out.println(emp2.getEmpId());
		System.out.println(emp2.getEmpName());
		
		
	}//end of main()

}//end of class
