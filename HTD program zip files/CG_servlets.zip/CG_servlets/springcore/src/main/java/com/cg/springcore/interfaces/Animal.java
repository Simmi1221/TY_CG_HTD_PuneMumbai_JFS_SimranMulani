package com.cg.springcore.interfaces;

public interface Animal {
	public void eat();
	public void walk();
	public void speak();

}
