package com.cg.springcore.beans;

public class MessageBean2 {
	
	// constructor
		public MessageBean2() {
			System.out.println("Inside constructor");
		}

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void init() {
		System.out.println("Initializing phase");
	}

	public void destroy() {
		System.out.println("Destroy phase");
	}

}
