package com.cg.springcore.annotatio.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.annotatio.bean.Car;

public class EngineTest {
	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("carConfig.xml");
		Car car=context.getBean("myCar", Car.class);
		
		System.out.println(car.getModelNum());
		System.out.println(car.getModelName());
		System.out.println("Engine details................");
		System.out.println(car.getEngine().getCC());
		System.out.println(car.getEngine().getType());
		
		((AbstractApplicationContext)context).close();
		
	}

}
