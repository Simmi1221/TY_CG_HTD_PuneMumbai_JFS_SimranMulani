package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.cg.springcore.annotatio.bean.Dog;
import com.cg.springcore.annotatio.bean.Panda;

@Configuration
public class AnimalConfig {
	
	@Bean(name ="dog")
	public Dog getDog() {
		return new Dog();
	}
	
	@Bean(name="panda")
	@Primary
	public Panda getPanda() {
		return new Panda();
	}

}//end of class
