package com.cg.springcore.annotatio.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.cg.springcore.annotatio.bean.EmployeeBean;
import com.cg.springcore.annotatio.config.DepartmentConfig;
import com.cg.springcore.annotatio.config.EmployeeConfig;

public class EmplyeeTest {
	
	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class);
		//ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class,DepartmentConfig.class);
		EmployeeBean employeeBean=context.getBean(EmployeeBean.class);
		System.out.println("Employee id id "+employeeBean.getEmpId());
		System.out.println("Employee name is "+employeeBean.getEmpName());
		System.out.println("-----------------------------------------");
		System.out.println("Dept id is "+employeeBean.getDeptBean().getDeptId());
		System.out.println("Dept name is "+employeeBean.getDeptBean().getDeptName());
		
		((AbstractApplicationContext)context).close();
		
	}//end of main()

}//end of class
