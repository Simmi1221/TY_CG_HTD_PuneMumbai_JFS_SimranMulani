package com.cg.springcore.beans;

import com.cg.springcore.interfaces.Animal;

public class Panda  implements Animal {

	@Override
	public void eat() {
		System.out.println("Eating Bamboo");
	}//end of eat()

	@Override
	public void walk() {
		System.out.println("Panda walking....");
	}//end of walk()

	@Override
	public void speak() {
		System.out.println("panda Squeaks");
	}
	//end of speak()
	

}//end of class
