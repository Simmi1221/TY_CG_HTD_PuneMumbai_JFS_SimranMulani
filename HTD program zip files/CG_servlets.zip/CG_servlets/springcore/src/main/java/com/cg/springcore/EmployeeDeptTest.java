package com.cg.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.beans.EmployeeBean;

public class EmployeeDeptTest {

	public static void main(String[] args) {

		//ApplicationContext context = new ClassPathXmlApplicationContext("employeeConfig.xml");
		//ApplicationContext context = new ClassPathXmlApplicationContext("EmployeeConfig2.xml","departmentConfig.xml");
		ApplicationContext context = new ClassPathXmlApplicationContext("EmployeeConfig2.xml");
		
		EmployeeBean eb = context.getBean("employee", EmployeeBean.class);

		System.out.println("Employee Id    = " + eb.getEmpId());
		System.out.println("employee name  = " + eb.getEmpName());
		System.out.println("Dept Id        = " + eb.getDeptBean().getDeptId());
		System.out.println("Dept name      = " + eb.getDeptBean().getDeptName());
		
		((AbstractApplicationContext)context).close();

	}

}
