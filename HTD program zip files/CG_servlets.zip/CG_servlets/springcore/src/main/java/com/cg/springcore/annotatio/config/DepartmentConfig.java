package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.springcore.annotatio.bean.DepartmentBean;

@Configuration
public class DepartmentConfig {
	
	@Bean(name="dev")
	public DepartmentBean getDevDept() {
		DepartmentBean deptBean=new DepartmentBean();
		deptBean.setDeptId(901);
		deptBean.setDeptName("Dev");
		return deptBean;
	}//end of getDevDept()
	
	@Bean(name="test")
	//@Primary
	public DepartmentBean getTestDept() {
		DepartmentBean deptBean=new DepartmentBean();
		deptBean.setDeptId(902);
		deptBean.setDeptName("Test");
		return deptBean;
	}//end of getTestingDept()
	
	@Bean(name="hr")
	public DepartmentBean getHrDept() {
		DepartmentBean deptBean=new DepartmentBean();
		deptBean.setDeptId(903);
		deptBean.setDeptName("HR");
		return deptBean;
	}//end of getHrDept()
	

}//end of class
