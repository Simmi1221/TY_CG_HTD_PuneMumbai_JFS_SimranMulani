package com.cg.springcore.annotatio.bean;

public class MessageBean {
	
	private String message;

	//Getters and Setters
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}//end of class
