package com.cg.springcore.annotatio.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.annotatio.bean.Sports;

public class SportsTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context= new ClassPathXmlApplicationContext("sportsConfig.xml");
		Sports sports=context.getBean("sports", Sports.class);
		
		System.out.println("Sport name    = "+sports.getName());
		System.out.println("SportPlayers  = "+sports.getTotalPlayers());
		System.out.println("Team Info     = "+sports.getTeamInfo());
		
		((AbstractApplicationContext)context).close();
	}

}
