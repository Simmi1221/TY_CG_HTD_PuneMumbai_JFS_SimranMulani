package com.cg.springcore.interfaces;

public interface Engine {
	
	public int getCC();
	public String getType();

}
