package com.cg.springcore.beans;

import com.cg.springcore.interfaces.Animal;

public class Dog implements Animal {

	@Override
	public void eat() {
		System.out.println("eating pedgree");
	}//end of eat()

	@Override
	public void walk() {
		System.out.println("Bow Bow");
	}//eat of walk()

	@Override
	public void speak() {
		System.out.println("Dog is running...");

	}//end of speak()

}//end of class
