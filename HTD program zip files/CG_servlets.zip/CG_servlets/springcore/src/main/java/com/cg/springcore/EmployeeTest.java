package com.cg.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcore.beans.EmployeeBean;

public class EmployeeTest {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		EmployeeBean eb=(EmployeeBean) context.getBean("employee1");
		EmployeeBean eb1=context.getBean("employee2", EmployeeBean.class);//another way to downcast in spring
		System.out.println(eb.getEmpId());
		System.out.println(eb.getEmpName());
		System.out.println(eb1.getEmpId());
		System.out.println(eb1.getEmpName());
		

	}

}
