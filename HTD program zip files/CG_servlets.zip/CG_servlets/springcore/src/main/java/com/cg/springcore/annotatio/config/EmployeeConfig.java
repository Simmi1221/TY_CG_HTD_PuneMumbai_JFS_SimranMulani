package com.cg.springcore.annotatio.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.cg.springcore.annotatio.bean.DepartmentBean;
import com.cg.springcore.annotatio.bean.EmployeeBean;

@Import(DepartmentConfig.class)
@Configuration
public class EmployeeConfig {
	
	@Bean
	public EmployeeBean getEmployeeBean() {
		EmployeeBean employeeBean=new EmployeeBean();
		employeeBean.setEmpId(101);
		employeeBean.setEmpName("Sara");
		return employeeBean;
	}//end of employeeBean()
	
}//end of class
